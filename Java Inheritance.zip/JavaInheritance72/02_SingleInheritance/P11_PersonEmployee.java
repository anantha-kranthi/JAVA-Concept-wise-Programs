/* Program 11: Single inheritance - Person -> Employee */
public class P11_PersonEmployee {
    public static void main(String[] args) {
        Employee emp = new Employee("Ravi Kumar", 30, 55000.0);
        emp.showEmployeeDetails();
    }
}

class Person {
    String name;
    int age;

    Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    void showPersonDetails() {
        System.out.println("Name: " + name + ", Age: " + age);
    }
}

class Employee extends Person {
    double salary;

    Employee(String name, int age, double salary) {
        super(name, age);       // calling Person's constructor
        this.salary = salary;
    }

    void showEmployeeDetails() {
        showPersonDetails();     // inherited method reused
        System.out.println("Salary: " + salary);
    }
}


