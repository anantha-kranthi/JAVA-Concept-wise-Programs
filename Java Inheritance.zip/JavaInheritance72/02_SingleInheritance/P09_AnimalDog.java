/* Program 9: Single inheritance - Animal -> Dog */
public class P09_AnimalDog {
    public static void main(String[] args) {
        Dog dog = new Dog();
        dog.eat();   // inherited from Animal
        dog.bark();  // Dog's own method

        System.out.println("\nSingle inheritance: exactly one superclass (Animal), one subclass (Dog).");
    }
}

class Animal {
    void eat() {
        System.out.println("This animal eats food");
    }
}

class Dog extends Animal {
    void bark() {
        System.out.println("The dog barks: Woof! Woof!");
    }
}


