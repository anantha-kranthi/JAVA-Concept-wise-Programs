/* Program 15: Single inheritance with method overriding - Calculator -> ScientificCalculator */
public class P15_CalculatorScientific {
    public static void main(String[] args) {
        ScientificCalculator sc = new ScientificCalculator();

        double sum = sc.add(5, 3);        // inherited method
        sc.showResult(sum);               // overridden version runs

        double power = sc.power(2, 10);   // own method
        sc.showResult(power);

        System.out.println("\nOverriding lets the subclass change inherited behaviour");
        System.out.println("while still reusing add()/subtract() unchanged.");
    }
}

class Calculator {
    double add(double a, double b) {
        return a + b;
    }

    double subtract(double a, double b) {
        return a - b;
    }

    void showResult(double result) {
        System.out.println("Result: " + result);
    }
}

class ScientificCalculator extends Calculator {
    double power(double base, double exponent) {
        return Math.pow(base, exponent);
    }

    // Overriding showResult to format scientific results differently
    @Override
    void showResult(double result) {
        System.out.printf("Scientific Result: %.4f%n", result);
    }
}


