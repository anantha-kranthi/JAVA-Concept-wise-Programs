/* Program 16: Single inheritance with protected members - Furniture -> Chair */
public class P16_FurnitureChair {
    public static void main(String[] args) {
        Chair chair = new Chair("Wood", 2500.0, 4);
        chair.showChairDetails();
        chair.applySpecialOffer();
        chair.showChairDetails();

        System.out.println("\nprotected members are accessible within the subclass,");
        System.out.println("unlike private members which are completely hidden.");
    }
}

class Furniture {
    protected String material;
    protected double price;

    Furniture(String material, double price) {
        this.material = material;
        this.price = price;
    }

    protected void applyDiscount(double percent) {
        price -= price * percent / 100;
    }
}

class Chair extends Furniture {
    int numberOfLegs;

    Chair(String material, double price, int numberOfLegs) {
        super(material, price);
        this.numberOfLegs = numberOfLegs;
    }

    void showChairDetails() {
        // protected fields 'material' and 'price' are directly usable here
        System.out.println("Material: " + material + ", Legs: " + numberOfLegs
                + ", Price: " + price);
    }

    void applySpecialOffer() {
        applyDiscount(10);   // protected inherited method usable in subclass
    }
}


