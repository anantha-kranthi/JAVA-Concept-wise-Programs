/* Program 10: Single inheritance - Vehicle -> Car */
public class P10_VehicleCar {
    public static void main(String[] args) {
        Car car = new Car();
        car.displaySpeed();   // inherited
        car.displayDoors();   // own
        car.maxSpeed = 180;   // modifying an inherited field
        car.displaySpeed();
    }
}

class Vehicle {
    int maxSpeed = 120;

    void displaySpeed() {
        System.out.println("Maximum speed: " + maxSpeed + " km/h");
    }
}

class Car extends Vehicle {
    int numberOfDoors = 4;

    void displayDoors() {
        System.out.println("Number of doors: " + numberOfDoors);
    }
}


