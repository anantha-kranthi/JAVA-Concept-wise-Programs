/* Program 13: Single inheritance - BankAccount -> SavingsAccount */
public class P13_BankAccountSavings {
    public static void main(String[] args) {
        SavingsAccount sa = new SavingsAccount(10000.0, 5.0);
        sa.showBalance();     // inherited
        sa.deposit(2000.0);   // inherited
        sa.addInterest();     // own method
        sa.showBalance();
    }
}

class BankAccount {
    protected double balance;

    BankAccount(double balance) {
        this.balance = balance;
    }

    void deposit(double amount) {
        balance += amount;
        System.out.println("Deposited " + amount + ", new balance = " + balance);
    }

    void showBalance() {
        System.out.println("Current balance: " + balance);
    }
}

class SavingsAccount extends BankAccount {
    double interestRate;

    SavingsAccount(double balance, double interestRate) {
        super(balance);
        this.interestRate = interestRate;
    }

    void addInterest() {
        double interest = balance * interestRate / 100;
        balance += interest;
        System.out.println("Interest added: " + interest + ", new balance = " + balance);
    }
}


