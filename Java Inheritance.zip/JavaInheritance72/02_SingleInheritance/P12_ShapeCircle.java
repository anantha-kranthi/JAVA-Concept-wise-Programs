/* Program 12: Single inheritance - Shape -> Circle with area calculation */
public class P12_ShapeCircle {
    public static void main(String[] args) {
        Circle circle = new Circle(7.0, "Red");
        circle.describe();       // inherited method
        System.out.printf("Area of circle (radius %.1f) = %.2f%n", circle.radius, circle.calculateArea());
    }
}

class Shape {
    String colour = "Unspecified";

    void describe() {
        System.out.println("This is a shape of colour " + colour);
    }
}

class Circle extends Shape {
    double radius;

    Circle(double radius, String colour) {
        this.radius = radius;
        this.colour = colour;    // inherited field, set via subclass
    }

    double calculateArea() {
        return Math.PI * radius * radius;
    }
}


