/* Program 14: Single inheritance - Bird -> Sparrow (fields and methods combined) */
public class P14_BirdSparrow {
    public static void main(String[] args) {
        Sparrow sparrow = new Sparrow();
        sparrow.fly();     // inherited method, uses inherited+modified field
        sparrow.chirp();   // own method
        System.out.println("canFly (inherited field) = " + sparrow.canFly);
    }
}

class Bird {
    String species = "Generic Bird";
    boolean canFly = true;

    void fly() {
        if (canFly) System.out.println(species + " is flying");
        else System.out.println(species + " cannot fly");
    }
}

class Sparrow extends Bird {
    Sparrow() {
        species = "Sparrow";   // overriding inherited field's value
    }

    void chirp() {
        System.out.println(species + " is chirping: Tweet tweet!");
    }
}


