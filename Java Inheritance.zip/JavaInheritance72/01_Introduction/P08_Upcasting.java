/* Program 8: A subclass object can be assigned to a superclass reference (upcasting) */
public class P08_Upcasting {
    public static void main(String[] args) {
        Manager manager = new Manager();
        manager.name = "Alice";

        // Upcasting: subclass object stored in a superclass reference
        Employee empRef = manager;

        empRef.work();                 // allowed: work() exists in Employee
        // empRef.manage();            // NOT allowed: manage() is unknown to Employee reference type

        System.out.println("\nempRef's declared type is Employee, but the actual object is Manager.");
        System.out.println("Upcasting is always safe and implicit - no cast operator is required.");

        // Downcasting back to access Manager-specific methods
        if (empRef instanceof Manager m) {
            m.manage();
            System.out.println("Downcasting used to regain access to manage().");
        }
    }
}

class Employee {
    String name = "Employee";
    void work() { System.out.println(name + " is working"); }
}

class Manager extends Employee {
    void manage() { System.out.println(name + " is managing a team"); }
}


