/* Program 6: Every class implicitly extends Object */
public class P06_EveryClassExtendsObject {
    public static void main(String[] args) {
        Book book = new Book();
        Magazine mag = new Magazine();

        // toString(), hashCode(), equals(), getClass() all come from Object
        System.out.println("book.toString() default form : " + book.toString());
        System.out.println("book.getClass().getSuperclass() : " + book.getClass().getSuperclass());
        System.out.println("mag.getClass().getSuperclass()  : " + mag.getClass().getSuperclass());

        System.out.println("\nbook instanceof Object : " + (book instanceof Object));
        System.out.println("book.hashCode() : " + book.hashCode());
        System.out.println("book.equals(book) : " + book.equals(book));

        System.out.println("\nEvery class sits at the top of a single-rooted hierarchy under Object,");
        System.out.println("whether or not 'extends Object' is written explicitly.");
    }
}

class Book {
    String title = "Java Basics";
}

// This is equivalent to: class Magazine extends Object
class Magazine extends Object {
    String name = "Tech Weekly";
}


