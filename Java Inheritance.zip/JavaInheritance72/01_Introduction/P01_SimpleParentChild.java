/* Program 1: A simple parent-child class relationship using extends */
public class P01_SimpleParentChild {
    public static void main(String[] args) {
        Child c = new Child();
        c.greet();   // inherited from Parent
        c.show();    // defined in Child

        System.out.println("\nChild IS-A Parent, so it automatically gets Parent's behaviour");
        System.out.println("without rewriting the greet() method.");
    }
}

class Parent {
    void greet() {
        System.out.println("Hello from Parent class");
    }
}

// Child inherits from Parent using the 'extends' keyword
class Child extends Parent {
    void show() {
        System.out.println("Hello from Child class");
    }
}


