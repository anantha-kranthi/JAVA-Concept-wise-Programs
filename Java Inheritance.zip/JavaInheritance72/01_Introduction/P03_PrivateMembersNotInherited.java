/* Program 3: Private members of a superclass are NOT accessible in a subclass */
public class P03_PrivateMembersNotInherited {
    public static void main(String[] args) {
        SavingsAccount sa = new SavingsAccount();
        sa.tryAccess();

        System.out.println("\nConclusion: private members exist in memory for the subclass");
        System.out.println("object too, but are not directly visible/inherited in the subclass code.");
    }
}

class Account {
    private double balance = 5000.0;   // private: hidden from subclasses

    private void showBalance() {
        System.out.println("Balance: " + balance);
    }

    // A public method can still expose private data indirectly
    public void printBalance() {
        showBalance();
    }
}

class SavingsAccount extends Account {
    void tryAccess() {
        // The following two lines would NOT compile if uncommented:
        // System.out.println(balance);   // balance has private access in Account
        // showBalance();                 // showBalance() has private access in Account
        System.out.println("Cannot directly access private members of Account here.");
        System.out.println("We can only reach them through Account's own public method:");
        printBalance();
    }
}


