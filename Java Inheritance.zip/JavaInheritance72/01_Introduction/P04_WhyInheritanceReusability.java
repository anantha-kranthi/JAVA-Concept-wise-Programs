/* Program 4: Code reusability - comparing WITHOUT and WITH inheritance */
public class P04_WhyInheritanceReusability {
    public static void main(String[] args) {
        System.out.println("--- Without inheritance (eat/sleep duplicated in both classes) ---");
        new DogWithoutInheritance().eat();
        new CatWithoutInheritance().eat();

        System.out.println("\n--- With inheritance (eat/sleep written once in Animal) ---");
        Dog d = new Dog("Rex");
        Cat c = new Cat("Whiskers");
        d.eat(); d.sleep(); d.bark();
        c.eat(); c.sleep(); c.meow();

        System.out.println("\nInheritance removed duplicate eat()/sleep() code from Dog and Cat.");
    }
}

// ---------- WITHOUT inheritance: duplicated code ----------
class DogWithoutInheritance {
    String name = "Rex";
    void eat() { System.out.println(name + " is eating"); }
    void sleep() { System.out.println(name + " is sleeping"); }
    void bark() { System.out.println(name + " is barking"); }
}

class CatWithoutInheritance {
    String name = "Whiskers";
    void eat() { System.out.println(name + " is eating"); }   // duplicated
    void sleep() { System.out.println(name + " is sleeping"); } // duplicated
    void meow() { System.out.println(name + " is meowing"); }
}

// ---------- WITH inheritance: common code written once ----------
class Animal {
    String name;
    Animal(String name) { this.name = name; }
    void eat() { System.out.println(name + " is eating"); }
    void sleep() { System.out.println(name + " is sleeping"); }
}

class Dog extends Animal {
    Dog(String name) { super(name); }
    void bark() { System.out.println(name + " is barking"); }
}

class Cat extends Animal {
    Cat(String name) { super(name); }
    void meow() { System.out.println(name + " is meowing"); }
}


