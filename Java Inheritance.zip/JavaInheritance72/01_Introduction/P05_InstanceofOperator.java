/* Program 5: Demonstrating the IS-A relationship using instanceof */
public class P05_InstanceofOperator {
    public static void main(String[] args) {
        Circle circle = new Circle();
        Square square = new Square();
        Shape shapeRef = new Circle();   // superclass reference, subclass object

        System.out.println("circle instanceof Circle : " + (circle instanceof Circle));
        System.out.println("circle instanceof Shape  : " + (circle instanceof Shape)
                + "   (Circle IS-A Shape)");
        Shape squareAsShape = square;   // widen to Shape so the check below is legal
        System.out.println("squareAsShape instanceof Circle : " + (squareAsShape instanceof Circle)
                + "  (Square is NOT a Circle)");
        System.out.println("shapeRef instanceof Circle: " + (shapeRef instanceof Circle)
                + "  (actual object is a Circle)");
        System.out.println("shapeRef instanceof Square: " + (shapeRef instanceof Square));

        // Pattern matching form of instanceof (Java 16+)
        Object obj = new Circle();
        if (obj instanceof Circle c) {
            System.out.println("\nPattern-matched instanceof: obj is a Circle -> " + c);
        }
    }
}

class Shape { }
class Circle extends Shape { }
class Square extends Shape { }


