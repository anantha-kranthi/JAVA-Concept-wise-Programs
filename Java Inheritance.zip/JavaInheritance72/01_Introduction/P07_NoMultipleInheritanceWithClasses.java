/* Program 7: Java does NOT support multiple inheritance with classes.
   The commented-out code below would fail to compile if enabled -
   demonstrated here by describing the compiler error instead. */
public class P07_NoMultipleInheritanceWithClasses {
    public static void main(String[] args) {
        ChildLegal child = new ChildLegal();
        child.skill();          // inherited from Father
        child.motherSkill();    // obtained via composition, not inheritance

        System.out.println("\nJava blocks 'extends Father, Mother' to avoid the classic");
        System.out.println("diamond problem (ambiguity when both parents define the same method).");
        System.out.println("Composition (\"has-a\") is used instead where multiple behaviours are needed.");
    }
}

class Father {
    void skill() { System.out.println("Father: gardening"); }
}

class Mother {
    void skill() { System.out.println("Mother: painting"); }
}

// The following line is ILLEGAL in Java and will not compile:
// class ChildIllegal extends Father, Mother { }
//
// Compiler error: "class ChildIllegal may not extend more than one class"

// A legal workaround: extend one class, and use composition for the other's behaviour
class ChildLegal extends Father {
    Mother motherRef = new Mother();   // composition instead of extending Mother

    void motherSkill() {
        motherRef.skill();
    }
}


