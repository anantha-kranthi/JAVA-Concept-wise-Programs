/* Program 2: A subclass inherits all non-private fields and methods */
public class P02_InheritedFieldsAndMethods {
    public static void main(String[] args) {
        Car car = new Car();

        // 'brand' and 'wheels' come from Vehicle, 'model' is Car's own
        System.out.println("brand  (inherited) : " + car.brand);
        System.out.println("wheels (inherited) : " + car.wheels);
        System.out.println("model  (own field) : " + car.model);

        car.displayInfo();   // inherited method
        car.brand = "Toyota"; // can modify inherited field too
        car.displayInfo();
    }
}

class Vehicle {
    String brand = "Generic";
    int wheels = 4;

    void displayInfo() {
        System.out.println("Brand: " + brand + ", Wheels: " + wheels);
    }
}

class Car extends Vehicle {
    String model = "Sedan";
}


