/* Program 68: A final class cannot be inherited from.
   The illegal subclass is shown only as a comment. */
public class P68_FinalClassPreventsInheritance {
    public static void main(String[] args) {
        ImmutablePoint point = new ImmutablePoint(3, 4);
        point.show();

        ExtendedClass ec = new ExtendedClass();
        ec.show();

        System.out.println("\n'final' on a class (like String or Integer in the JDK) permanently");
        System.out.println("blocks it from ever being extended - it stops the inheritance chain there.");
    }
}

final class ImmutablePoint {
    final int x, y;
    ImmutablePoint(int x, int y) { this.x = x; this.y = y; }
    void show() { System.out.println("Point(" + x + ", " + y + ")"); }
}

// The following would NOT compile if uncommented:
// class ColoredPoint extends ImmutablePoint {  }
// Compiler error: "cannot inherit from final ImmutablePoint"

class RegularClass {
    void show() { System.out.println("A normal, extendable class"); }
}

class ExtendedClass extends RegularClass {   // this is fine - RegularClass is not final
}


