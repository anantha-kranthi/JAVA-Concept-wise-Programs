/* Program 71: Conceptually relating object cleanup order to inheritance,
   demonstrated with explicit cleanup methods (since finalize() is deprecated
   and its timing is not guaranteed by the JVM). */
public class P71_ObjectCleanupOrderConceptual {
    public static void main(String[] args) {
        ChildResource resource = new ChildResource();

        System.out.println("--- Acquiring (construction-like order: top to bottom) ---");
        resource.acquire();

        System.out.println("\n--- Releasing (destruction-like order: bottom to top) ---");
        resource.release();

        System.out.println("\nConceptually, cleanup should mirror construction in reverse:");
        System.out.println("the most-derived part is set up last and torn down first.");
    }
}

class GrandParentResource {
    void acquire() { System.out.println("GrandParentResource acquired"); }
    void release() { System.out.println("GrandParentResource released (cleaned up LAST)"); }
}

class ParentResource extends GrandParentResource {
    @Override
    void acquire() {
        super.acquire();
        System.out.println("ParentResource acquired");
    }
    @Override
    void release() {
        System.out.println("ParentResource released");
        super.release();   // release the parent part after this level's own cleanup
    }
}

class ChildResource extends ParentResource {
    @Override
    void acquire() {
        super.acquire();
        System.out.println("ChildResource acquired (acquired LAST)");
    }
    @Override
    void release() {
        System.out.println("ChildResource released (cleaned up FIRST)");
        super.release();
    }
}


