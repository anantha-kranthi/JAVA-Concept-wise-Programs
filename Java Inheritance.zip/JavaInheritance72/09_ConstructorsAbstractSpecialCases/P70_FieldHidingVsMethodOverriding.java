/* Program 70: Field hiding (variable shadowing) versus method overriding */
public class P70_FieldHidingVsMethodOverriding {
    public static void main(String[] args) {
        Base baseRef = new Derived();

        // Field access is resolved by the REFERENCE TYPE (compile time) - "hiding"
        System.out.println("baseRef.label (field)  = " + baseRef.label + "  <- Base's value!");

        // Method call is resolved by the ACTUAL OBJECT TYPE (run time) - "overriding"
        baseRef.show();                                    // prints Derived's version

        Derived derivedRef = new Derived();
        System.out.println("derivedRef.label        = " + derivedRef.label);

        System.out.println("\nFields are NOT polymorphic (resolved statically by reference type);");
        System.out.println("methods ARE polymorphic (resolved dynamically by actual object type).");
    }
}

class Base {
    String label = "Base label";

    void show() {
        System.out.println("Base show()");
    }
}

class Derived extends Base {
    String label = "Derived label";   // HIDES Base's field

    @Override
    void show() {                     // OVERRIDES Base's method
        System.out.println("Derived show()");
    }
}


