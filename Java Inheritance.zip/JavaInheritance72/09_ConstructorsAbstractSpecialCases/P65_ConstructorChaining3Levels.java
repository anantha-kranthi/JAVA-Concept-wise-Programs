/* Program 65: Constructor chaining across a 3-level inheritance hierarchy with parameters */
public class P65_ConstructorChaining3Levels {
    public static void main(String[] args) {
        new Level3("Start");

        System.out.println("\nEach level forwards (and can modify) the data before");
        System.out.println("calling further up the chain, but execution still finishes top-down.");
    }
}

class Level1 {
    Level1(String msg) {
        System.out.println("Level1 constructor: " + msg);
    }
}

class Level2 extends Level1 {
    Level2(String msg) {
        super(msg + " -> passed through Level2");
        System.out.println("Level2 constructor executed");
    }
}

class Level3 extends Level2 {
    Level3(String msg) {
        super(msg + " -> passed through Level3");
        System.out.println("Level3 constructor executed");
    }
}


