/* Program 67: Constructors are NOT inherited, but can be invoked via super() */
public class P67_ConstructorsNotInherited {
    public static void main(String[] args) {
        Derived derived = new Derived("Hello");

        System.out.println("\nUnlike methods and fields, constructors belong only to their");
        System.out.println("own class. A subclass must define its own constructors, though");
        System.out.println("it can reuse the superclass's constructor logic via super(...).");
    }
}

class Base {
    Base(String message) {
        System.out.println("Base constructor with message: " + message);
    }
}

class Derived extends Base {
    // Derived does NOT automatically get a Base(String) constructor.
    // It must define its own and explicitly forward to Base's constructor.
    Derived(String message) {
        super(message);   // invoking, not inheriting, Base's constructor
        System.out.println("Derived constructor also ran");
    }

    // Without a matching constructor + super() call, this would not compile:
    // Derived d = new Derived("test");  <- needs the constructor above to exist
}


