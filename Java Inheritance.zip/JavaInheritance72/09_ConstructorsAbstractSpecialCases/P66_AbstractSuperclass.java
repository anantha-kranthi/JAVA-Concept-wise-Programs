/* Program 66: Inheritance with an abstract superclass and concrete subclasses */
public class P66_AbstractSuperclass {
    public static void main(String[] args) {
        // Shape shape = new Shape();  // ILLEGAL - cannot instantiate an abstract class

        Shape circle = new Circle(5);
        Shape rectangle = new Rectangle(4, 6);

        circle.showArea();
        rectangle.showArea();

        System.out.println("\nAn abstract class can declare abstract methods (no body) that");
        System.out.println("every concrete subclass MUST implement, while still providing");
        System.out.println("shared concrete methods like showArea().");
    }
}

abstract class Shape {
    abstract double area();       // no body - must be implemented by subclasses

    void showArea() {              // concrete method, inherited as-is
        System.out.printf("Area = %.2f%n", area());
    }
}

class Circle extends Shape {
    double radius;
    Circle(double radius) { this.radius = radius; }
    @Override
    double area() { return Math.PI * radius * radius; }
}

class Rectangle extends Shape {
    double length, width;
    Rectangle(double length, double width) { this.length = length; this.width = width; }
    @Override
    double area() { return length * width; }
}


