/* Program 69: Inheritance combined with instanceof and safe downcasting */
public class P69_InstanceofSafeDowncasting {
    public static void main(String[] args) {
        Animal[] animals = { new Dog(), new Cat(), new Animal() };

        for (Animal animal : animals) {
            animal.eat();

            // Safe downcasting: check with instanceof before casting
            if (animal instanceof Dog dog) {
                dog.bark();
            } else if (animal instanceof Cat cat) {
                cat.meow();
            } else {
                System.out.println("(No special behaviour for a plain Animal)");
            }
            System.out.println();
        }

        // An UNSAFE downcast without checking would throw at runtime:
        Animal justAnAnimal = new Animal();
        try {
            Dog notReallyADog = (Dog) justAnAnimal;   // compiles, but fails at runtime
        } catch (ClassCastException e) {
            System.out.println("Caught expected exception: " + e);
        }
    }
}

class Animal {
    void eat() { System.out.println("Animal eats"); }
}

class Dog extends Animal {
    void bark() { System.out.println("Dog barks"); }
}

class Cat extends Animal {
    void meow() { System.out.println("Cat meows"); }
}


