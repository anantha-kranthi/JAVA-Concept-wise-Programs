/* Program 72: Complete real-world inheritance hierarchy -
   Employee (abstract) -> Manager, Developer, Intern with overridden salary calculation */
public class P72_EmployeeHierarchySalary {
    public static void main(String[] args) {
        // Employee emp = new Employee("X");   // ILLEGAL - Employee is abstract

        Employee[] staff = {
            new Manager("Anitha"),
            new Developer("Rakesh"),
            new Intern("Sneha")
        };

        double totalPayroll = 0;
        for (Employee employee : staff) {
            employee.showSalarySlip();     // each subclass's own calculateSalary() runs
            totalPayroll += employee.calculateSalary();
        }

        System.out.printf("%nTotal payroll = %.2f%n", totalPayroll);
        System.out.println("\nThis combines an abstract superclass, hierarchical inheritance,");
        System.out.println("method overriding and runtime polymorphism in one realistic example.");
    }
}

abstract class Employee {
    String name;
    Employee(String name) { this.name = name; }

    abstract double calculateSalary();   // must be implemented by every subclass

    void showSalarySlip() {
        System.out.printf("%-10s (%-16s) : salary = %.2f%n",
                name, getClass().getSimpleName(), calculateSalary());
    }
}

class Manager extends Employee {
    double baseSalary = 60000;
    double bonus = 15000;
    Manager(String name) { super(name); }
    @Override
    double calculateSalary() { return baseSalary + bonus; }
}

class Developer extends Employee {
    double baseSalary = 50000;
    double overtimePay = 5000;
    Developer(String name) { super(name); }
    @Override
    double calculateSalary() { return baseSalary + overtimePay; }
}

class Intern extends Employee {
    double stipend = 15000;
    Intern(String name) { super(name); }
    @Override
    double calculateSalary() { return stipend; }
}


