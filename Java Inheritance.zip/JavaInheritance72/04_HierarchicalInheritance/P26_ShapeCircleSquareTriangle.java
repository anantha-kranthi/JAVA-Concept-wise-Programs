/* Program 26: Hierarchical inheritance - Shape -> Circle, Square, Triangle */
public class P26_ShapeCircleSquareTriangle {
    public static void main(String[] args) {
        Circle c = new Circle();
        Square s = new Square();
        Triangle t = new Triangle();

        c.info(); System.out.printf("Circle area = %.2f%n%n", c.area());
        s.info(); System.out.println("Square area = " + s.area() + "\n");
        t.info(); System.out.println("Triangle area = " + t.area());
    }
}

class Shape {
    void info() {
        System.out.println("This is a generic shape");
    }
}

class Circle extends Shape {
    double radius = 5;
    double area() { return Math.PI * radius * radius; }
}

class Square extends Shape {
    double side = 4;
    double area() { return side * side; }
}

class Triangle extends Shape {
    double base = 6, height = 3;
    double area() { return 0.5 * base * height; }
}


