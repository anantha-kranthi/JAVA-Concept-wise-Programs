/* Program 32: Hierarchical inheritance - Instrument -> Guitar, Piano, Violin */
public class P32_InstrumentGuitarPianoViolin {
    public static void main(String[] args) {
        Guitar guitar = new Guitar();
        Piano piano = new Piano();
        Violin violin = new Violin();

        guitar.tune(); guitar.play();
        piano.tune(); piano.play();
        violin.tune(); violin.play();
    }
}

class Instrument {
    String category = "String/Percussion/Wind";
    void tune() { System.out.println("Tuning the instrument..."); }
}

class Guitar extends Instrument {
    int strings = 6;
    void play() { System.out.println("Playing guitar with " + strings + " strings"); }
}

class Piano extends Instrument {
    int keys = 88;
    void play() { System.out.println("Playing piano with " + keys + " keys"); }
}

class Violin extends Instrument {
    int strings = 4;
    void play() { System.out.println("Playing violin with " + strings + " strings"); }
}


