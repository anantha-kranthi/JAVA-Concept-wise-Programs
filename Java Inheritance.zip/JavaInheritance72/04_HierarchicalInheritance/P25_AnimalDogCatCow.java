/* Program 25: Hierarchical inheritance - Animal -> Dog, Cat, Cow */
public class P25_AnimalDogCatCow {
    public static void main(String[] args) {
        Dog dog = new Dog();
        Cat cat = new Cat();
        Cow cow = new Cow();

        dog.eat(); dog.bark();
        cat.eat(); cat.meow();
        cow.eat(); cow.moo();

        System.out.println("\nHierarchical inheritance: one superclass (Animal),");
        System.out.println("multiple independent subclasses (Dog, Cat, Cow).");
    }
}

class Animal {
    void eat() {
        System.out.println("Animal eats food");
    }
}

class Dog extends Animal {
    void bark() { System.out.println("Dog barks"); }
}

class Cat extends Animal {
    void meow() { System.out.println("Cat meows"); }
}

class Cow extends Animal {
    void moo() { System.out.println("Cow moos"); }
}


