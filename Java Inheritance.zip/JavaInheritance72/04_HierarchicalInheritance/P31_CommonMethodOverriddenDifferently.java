/* Program 31: Hierarchical inheritance where each subclass overrides a common method differently */
public class P31_CommonMethodOverriddenDifferently {
    public static void main(String[] args) {
        Instrument[] band = { new Guitar(), new Drum(), new Flute() };

        for (Instrument instrument : band) {
            instrument.makeSound();   // same call, different behaviour per subclass
        }

        System.out.println("\nOne method signature (makeSound), three different implementations -");
        System.out.println("hierarchical inheritance combined with overriding gives runtime polymorphism.");
    }
}

class Instrument {
    void makeSound() {
        System.out.println("Instrument makes a generic sound");
    }
}

class Guitar extends Instrument {
    @Override
    void makeSound() { System.out.println("Guitar strums: Strum strum!"); }
}

class Drum extends Instrument {
    @Override
    void makeSound() { System.out.println("Drum beats: Boom boom!"); }
}

class Flute extends Instrument {
    @Override
    void makeSound() { System.out.println("Flute plays: Tweeee!"); }
}


