/* Program 28: Hierarchical inheritance - Vehicle -> Car, Bike, Truck */
public class P28_VehicleCarBikeTruck {
    public static void main(String[] args) {
        Car car = new Car();
        Bike bike = new Bike();
        Truck truck = new Truck();

        car.start(); car.openTrunk();
        bike.start(); bike.kickStart();
        truck.start(); truck.loadCargo();

        System.out.println("\nAll three share start() from Vehicle, but each adds unique behaviour.");
    }
}

class Vehicle {
    void start() {
        System.out.println("Vehicle starts");
    }
}

class Car extends Vehicle {
    void openTrunk() { System.out.println("Car trunk opened"); }
}

class Bike extends Vehicle {
    void kickStart() { System.out.println("Bike kick-started"); }
}

class Truck extends Vehicle {
    void loadCargo() { System.out.println("Truck loaded with cargo"); }
}


