/* Program 30: Processing an array of superclass references pointing to different subclasses */
public class P30_ArrayOfSuperclassRefs {
    public static void main(String[] args) {
        // A single array of the superclass type holds different subclass objects
        Shape[] shapes = { new Circle(), new Square(), new Triangle() };

        double total = 0;
        for (Shape s : shapes) {
            System.out.printf("%-10s area = %.2f%n", s.name, s.area());
            total += s.area();
        }
        System.out.printf("%nTotal area of all shapes = %.2f%n", total);

        System.out.println("\nThis works because Circle, Square and Triangle all IS-A Shape,");
        System.out.println("so each fits into a Shape[] array (hierarchical inheritance in action).");
    }
}

class Shape {
    String name = "Shape";
    double area() { return 0.0; }
}

class Circle extends Shape {
    Circle() { name = "Circle"; }
    double area() { return Math.PI * 5 * 5; }
}

class Square extends Shape {
    Square() { name = "Square"; }
    double area() { return 4 * 4; }
}

class Triangle extends Shape {
    Triangle() { name = "Triangle"; }
    double area() { return 0.5 * 6 * 4; }
}


