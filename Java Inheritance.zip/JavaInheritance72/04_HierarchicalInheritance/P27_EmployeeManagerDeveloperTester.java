/* Program 27: Hierarchical inheritance - Employee -> Manager, Developer, Tester */
public class P27_EmployeeManagerDeveloperTester {
    public static void main(String[] args) {
        Manager m = new Manager("Asha");
        Developer d = new Developer("Rohit");
        Tester t = new Tester("Priya");

        m.showRole(); m.manage();
        d.showRole(); d.code();
        t.showRole(); t.test();
    }
}

class Employee {
    String name;
    Employee(String name) { this.name = name; }
    void showRole() { System.out.println(name + " is an employee"); }
}

class Manager extends Employee {
    Manager(String name) { super(name); }
    void manage() { System.out.println(name + " manages the project"); }
}

class Developer extends Employee {
    Developer(String name) { super(name); }
    void code() { System.out.println(name + " writes code"); }
}

class Tester extends Employee {
    Tester(String name) { super(name); }
    void test() { System.out.println(name + " tests the software"); }
}


