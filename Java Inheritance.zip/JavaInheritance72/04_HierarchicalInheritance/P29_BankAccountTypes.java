/* Program 29: Hierarchical inheritance - BankAccount -> Savings, Current, FixedDeposit */
public class P29_BankAccountTypes {
    public static void main(String[] args) {
        SavingsAccount sa = new SavingsAccount(20000);
        CurrentAccount ca = new CurrentAccount(50000);
        FixedDepositAccount fd = new FixedDepositAccount(100000);

        sa.showBalance(); sa.addInterest();
        ca.showBalance(); ca.showOverdraft();
        fd.showBalance(); fd.showLockIn();
    }
}

class BankAccount {
    double balance;
    BankAccount(double balance) { this.balance = balance; }
    void showBalance() { System.out.println("Balance: " + balance); }
}

class SavingsAccount extends BankAccount {
    SavingsAccount(double balance) { super(balance); }
    void addInterest() {
        balance += balance * 0.04;
        System.out.println("Interest added. New balance: " + balance);
    }
}

class CurrentAccount extends BankAccount {
    double overdraftLimit = 10000;
    CurrentAccount(double balance) { super(balance); }
    void showOverdraft() { System.out.println("Overdraft limit: " + overdraftLimit); }
}

class FixedDepositAccount extends BankAccount {
    int lockInMonths = 12;
    FixedDepositAccount(double balance) { super(balance); }
    void showLockIn() { System.out.println("Locked in for " + lockInMonths + " months"); }
}


