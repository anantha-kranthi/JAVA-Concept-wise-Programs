/* Program 33: Multiple inheritance using two interfaces implemented by one class */
public class P33_TwoInterfaces {
    public static void main(String[] args) {
        Human human = new Human();
        human.walk();
        human.swim();

        System.out.println("\nHuman IS-A Walkable AND IS-A Swimmable at the same time -");
        System.out.println("something a single class hierarchy could never express directly.");
        System.out.println("human instanceof Walkable  : " + (human instanceof Walkable));
        System.out.println("human instanceof Swimmable : " + (human instanceof Swimmable));
    }
}

interface Walkable {
    void walk();
}

interface Swimmable {
    void swim();
}

// A class can implement multiple interfaces, achieving multiple inheritance of type
class Human implements Walkable, Swimmable {
    public void walk() { System.out.println("Human walks on two legs"); }
    public void swim() { System.out.println("Human swims in water"); }
}


