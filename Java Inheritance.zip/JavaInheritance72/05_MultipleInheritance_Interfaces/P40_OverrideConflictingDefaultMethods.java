/* Program 40: Overriding a conflicting default method inherited from two interfaces */
public class P40_OverrideConflictingDefaultMethods {
    public static void main(String[] args) {
        HybridWorker worker = new HybridWorker();
        System.out.println("Designation: " + worker.designation());

        System.out.println("\nWhen two interfaces supply the same default method, the");
        System.out.println("implementing class MUST override it, resolving the ambiguity itself.");
    }
}

interface Employee {
    default String designation() { return "Employee"; }
}

interface Consultant {
    default String designation() { return "Consultant"; }
}

// Both interfaces provide 'designation()' with different defaults - must override explicitly
class HybridWorker implements Employee, Consultant {
    @Override
    public String designation() {
        // Combine both instead of just picking one
        return Employee.super.designation() + " & " + Consultant.super.designation();
    }
}


