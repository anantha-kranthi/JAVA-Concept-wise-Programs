/* Program 39: An interface extending multiple interfaces (interface-to-interface multiple inheritance) */
public class P39_InterfaceExtendingMultipleInterfaces {
    public static void main(String[] args) {
        Document doc = new Document();
        doc.read();
        doc.write();
        doc.readWriteInfo();

        System.out.println("\ninterface ReadWritable extends Readable, Writable  <- legal!");
        System.out.println("class X extends A, B                               <- illegal for classes");
    }
}

interface Readable {
    void read();
}

interface Writable {
    void write();
}

// An interface CAN extend more than one interface (unlike classes)
interface ReadWritable extends Readable, Writable {
    void readWriteInfo();
}

class Document implements ReadWritable {
    public void read() { System.out.println("Reading document"); }
    public void write() { System.out.println("Writing document"); }
    public void readWriteInfo() { System.out.println("This document supports both read and write"); }
}


