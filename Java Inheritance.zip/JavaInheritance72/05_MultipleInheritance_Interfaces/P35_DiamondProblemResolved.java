/* Program 35: Resolving the diamond problem using default methods in interfaces */
public class P35_DiamondProblemResolved {
    public static void main(String[] args) {
        Car car = new Car();
        car.start();

        System.out.println("\nWithout the explicit override, the compiler would report:");
        System.out.println("\"class Car inherits unrelated defaults for start() from Machine and Vehicle\"");
    }
}

interface Machine {
    default void start() {
        System.out.println("Machine: generic start");
    }
}

interface Vehicle {
    default void start() {
        System.out.println("Vehicle: generic start");
    }
}

// Both Machine and Vehicle define start() - this is the "diamond" ambiguity.
// The class MUST override start() itself to resolve it; otherwise it won't compile.
class Car implements Machine, Vehicle {
    @Override
    public void start() {
        // Explicitly choosing which parent's version to use, or writing new logic
        Machine.super.start();     // calling Machine's default explicitly
        Vehicle.super.start();     // calling Vehicle's default explicitly
        System.out.println("Car: engine started with a key turn");
    }
}


