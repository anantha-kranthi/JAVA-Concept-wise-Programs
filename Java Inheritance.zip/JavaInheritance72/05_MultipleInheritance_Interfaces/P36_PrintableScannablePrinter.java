/* Program 36: Multiple inheritance - Printable and Scannable implemented by Printer */
public class P36_PrintableScannablePrinter {
    public static void main(String[] args) {
        Printer printer = new Printer();
        printer.print("Report.pdf");
        printer.scan("Photo.jpg");
        System.out.println();
        printer.copy("Invoice.docx");
    }
}

interface Printable {
    void print(String document);
}

interface Scannable {
    void scan(String document);
}

class Printer implements Printable, Scannable {
    public void print(String document) {
        System.out.println("Printing: " + document);
    }
    public void scan(String document) {
        System.out.println("Scanning: " + document);
    }

    void copy(String document) {
        scan(document);
        print(document);
        System.out.println("Copy complete.");
    }
}


