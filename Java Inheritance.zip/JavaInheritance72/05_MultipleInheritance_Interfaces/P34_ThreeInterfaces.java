/* Program 34: Multiple inheritance using three interfaces implemented by one class */
public class P34_ThreeInterfaces {
    public static void main(String[] args) {
        FileHandler file = new FileHandler();
        file.read();
        file.write();
        file.delete();

        System.out.println("\nOne class combining THREE interface types - this is Java's");
        System.out.println("way of achieving what other languages call multiple inheritance.");
    }
}

interface Readable {
    void read();
}

interface Writable {
    void write();
}

interface Deletable {
    void delete();
}

class FileHandler implements Readable, Writable, Deletable {
    public void read() { System.out.println("Reading file contents"); }
    public void write() { System.out.println("Writing to file"); }
    public void delete() { System.out.println("Deleting the file"); }
}


