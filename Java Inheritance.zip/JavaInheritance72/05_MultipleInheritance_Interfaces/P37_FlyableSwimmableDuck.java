/* Program 37: Multiple inheritance - Flyable and Swimmable implemented by Duck */
public class P37_FlyableSwimmableDuck {
    public static void main(String[] args) {
        Duck duck = new Duck();
        duck.fly();
        duck.swim();
        duck.walk();

        System.out.println("\nA Duck combines flying and swimming abilities from two");
        System.out.println("separate interface types, plus its own walk() behaviour.");
    }
}

interface Flyable {
    void fly();
}

interface Swimmable {
    void swim();
}

class Duck implements Flyable, Swimmable {
    public void fly() { System.out.println("Duck flies short distances"); }
    public void swim() { System.out.println("Duck swims gracefully"); }

    void walk() { System.out.println("Duck waddles on land"); }
}


