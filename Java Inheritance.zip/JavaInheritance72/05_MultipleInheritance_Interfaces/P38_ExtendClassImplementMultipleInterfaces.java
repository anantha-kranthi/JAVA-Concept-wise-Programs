/* Program 38: A class extending one class AND implementing multiple interfaces */
public class P38_ExtendClassImplementMultipleInterfaces {
    public static void main(String[] args) {
        Dog dog = new Dog();
        dog.eat();     // from superclass Animal
        dog.train();   // from interface Trainable
        dog.pet();     // from interface Petable

        System.out.println("\ndog instanceof Animal    : " + (dog instanceof Animal));
        System.out.println("dog instanceof Trainable : " + (dog instanceof Trainable));
        System.out.println("dog instanceof Petable   : " + (dog instanceof Petable));
        System.out.println("\nJava allows ONE class to extend but MANY interfaces to implement.");
    }
}

class Animal {
    String name = "Animal";
    void eat() { System.out.println(name + " eats"); }
}

interface Trainable {
    void train();
}

interface Petable {
    void pet();
}

class Dog extends Animal implements Trainable, Petable {
    Dog() { name = "Dog"; }

    public void train() { System.out.println(name + " is being trained"); }
    public void pet() { System.out.println(name + " enjoys being petted"); }
}


