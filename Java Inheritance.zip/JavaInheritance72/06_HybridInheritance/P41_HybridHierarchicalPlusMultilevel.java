/* Program 41: Hybrid inheritance combining hierarchical and multilevel types
   using classes and an interface.
   Structure: Animal -> Dog -> Puppy (multilevel)
              Animal -> Cat            (hierarchical, sibling of Dog)
              Puppy also implements Trainable (interface-based extra behaviour) */
public class P41_HybridHierarchicalPlusMultilevel {
    public static void main(String[] args) {
        Puppy puppy = new Puppy();
        puppy.eat();    // from Animal (multilevel, grandparent)
        puppy.bark();   // from Dog (multilevel, parent)
        puppy.train();  // from Trainable interface

        Cat cat = new Cat();
        cat.eat();      // hierarchical sibling of Dog, also from Animal
        cat.meow();

        System.out.println("\nHybrid = hierarchical (Dog, Cat under Animal)");
        System.out.println("        + multilevel (Animal -> Dog -> Puppy)");
        System.out.println("        + interface-based extra capability (Trainable).");
    }
}

class Animal {
    void eat() { System.out.println("Animal eats"); }
}

class Dog extends Animal {
    void bark() { System.out.println("Dog barks"); }
}

class Cat extends Animal {
    void meow() { System.out.println("Cat meows"); }
}

interface Trainable {
    void train();
}

class Puppy extends Dog implements Trainable {
    public void train() { System.out.println("Puppy is being trained"); }
}


