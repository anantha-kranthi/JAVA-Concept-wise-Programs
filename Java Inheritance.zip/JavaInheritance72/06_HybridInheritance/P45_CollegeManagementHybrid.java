/* Program 45: Hybrid inheritance in a college management system
   (Person -> Student/Staff hierarchical, plus interfaces for extra roles) */
public class P45_CollegeManagementHybrid {
    public static void main(String[] args) {
        Staff professor = new Staff("Dr. Rao");
        professor.takeClass();

        StudentAthlete athlete = new StudentAthlete("Kavya");
        athlete.attendClass();   // hierarchical: from Student
        athlete.playSport();     // interface: from Sportsperson

        System.out.println("\nStudent and Staff form a hierarchical branch under Person,");
        System.out.println("while StudentAthlete adds an interface-based role on top.");
    }
}

class Person {
    String name;
    Person(String name) { this.name = name; }
}

class Student extends Person {
    Student(String name) { super(name); }
    void attendClass() { System.out.println(name + " attends class"); }
}

class Staff extends Person {
    Staff(String name) { super(name); }
    void takeClass() { System.out.println(name + " takes a class"); }
}

interface Sportsperson {
    void playSport();
}

// A student who is also a sportsperson - hybrid of hierarchical + interface inheritance
class StudentAthlete extends Student implements Sportsperson {
    StudentAthlete(String name) { super(name); }
    public void playSport() { System.out.println(name + " plays basketball"); }
}


