/* Program 47: Hybrid model - Shape -> Polygon -> Rectangle (multilevel),
   with Polygon also implementing Comparable (interface-based) */
public class P47_ShapePolygonRectangleComparable {
    public static void main(String[] args) {
        Rectangle r1 = new Rectangle(4, 5);   // area 20
        Rectangle r2 = new Rectangle(3, 3);   // area 9

        System.out.println("r1 area = " + r1.area);
        System.out.println("r2 area = " + r2.area);
        System.out.println("r1.compareTo(r2) = " + r1.compareTo(r2)
                + "  (positive means r1's area is larger)");

        System.out.println("\nMultilevel chain Shape -> Polygon -> Rectangle,");
        System.out.println("plus Polygon implementing Comparable<Polygon> = hybrid inheritance.");
    }
}

class Shape {
    String name = "Shape";
}

class Polygon extends Shape implements Comparable<Polygon> {
    double area;

    public int compareTo(Polygon other) {
        return Double.compare(this.area, other.area);
    }
}

class Rectangle extends Polygon {
    Rectangle(double length, double width) {
        name = "Rectangle";
        area = length * width;
    }
}


