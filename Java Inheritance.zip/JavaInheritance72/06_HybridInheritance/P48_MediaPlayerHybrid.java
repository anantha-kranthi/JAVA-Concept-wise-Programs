/* Program 48: Hybrid inheritance in a media player system
   (class hierarchy + Playable/Recordable interfaces) */
public class P48_MediaPlayerHybrid {
    public static void main(String[] args) {
        VideoRecorder recorder = new VideoRecorder();
        recorder.powerOn();     // from MediaDevice
        recorder.playAudio();   // from AudioPlayer
        recorder.play();        // from Playable
        recorder.record();      // from Recordable

        System.out.println("\nThis single object mixes a multilevel class chain with");
        System.out.println("two independently implemented interfaces - a hybrid design.");
    }
}

class MediaDevice {
    void powerOn() { System.out.println("Media device powered on"); }
}

class AudioPlayer extends MediaDevice {
    void playAudio() { System.out.println("Playing audio track"); }
}

interface Playable {
    void play();
}

interface Recordable {
    void record();
}

// VideoRecorder: extends AudioPlayer (multilevel: MediaDevice -> AudioPlayer -> VideoRecorder)
// and implements two interfaces (multiple inheritance)
class VideoRecorder extends AudioPlayer implements Playable, Recordable {
    public void play() { System.out.println("Playing video"); }
    public void record() { System.out.println("Recording video"); }
}


