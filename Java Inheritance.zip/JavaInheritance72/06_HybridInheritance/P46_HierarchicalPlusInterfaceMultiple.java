/* Program 46: Hybrid inheritance combining hierarchical class inheritance
   with interface-based multiple inheritance */
public class P46_HierarchicalPlusInterfaceMultiple {
    public static void main(String[] args) {
        SeniorDeveloper senior = new SeniorDeveloper("Manoj");
        senior.work();          // from Employee
        senior.code();          // from Developer
        senior.leadMeeting();   // from TeamLead
        senior.reviewCode();    // from CodeReviewer

        Tester tester = new Tester("Divya");
        tester.work();
        tester.test();
    }
}

class Employee {
    String name;
    Employee(String name) { this.name = name; }
    void work() { System.out.println(name + " is working"); }
}

class Developer extends Employee {
    Developer(String name) { super(name); }
    void code() { System.out.println(name + " writes code"); }
}

class Tester extends Employee {
    Tester(String name) { super(name); }
    void test() { System.out.println(name + " tests code"); }
}

interface TeamLead {
    void leadMeeting();
}

interface CodeReviewer {
    void reviewCode();
}

// SeniorDeveloper: hierarchical (extends Developer, sibling of Tester under Employee)
// + multiple interface inheritance (TeamLead, CodeReviewer)
class SeniorDeveloper extends Developer implements TeamLead, CodeReviewer {
    SeniorDeveloper(String name) { super(name); }
    public void leadMeeting() { System.out.println(name + " leads the sprint meeting"); }
    public void reviewCode() { System.out.println(name + " reviews pull requests"); }
}


