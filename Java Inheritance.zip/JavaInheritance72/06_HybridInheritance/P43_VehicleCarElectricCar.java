/* Program 43: Hybrid inheritance - Vehicle -> Car -> ElectricCar,
   with ElectricCar also implementing an interface */
public class P43_VehicleCarElectricCar {
    public static void main(String[] args) {
        ElectricCar tesla = new ElectricCar();
        tesla.start();          // multilevel: from Vehicle
        tesla.drive();          // multilevel: from Car
        tesla.chargeBattery();  // own method
        tesla.showEmission();   // interface-based multiple inheritance

        System.out.println("\nMultilevel class chain + interface implementation = hybrid inheritance.");
    }
}

class Vehicle {
    void start() { System.out.println("Vehicle starts"); }
}

class Car extends Vehicle {
    void drive() { System.out.println("Car is driven on the road"); }
}

interface EcoFriendly {
    void showEmission();
}

class ElectricCar extends Car implements EcoFriendly {
    public void showEmission() {
        System.out.println("Zero tailpipe emissions");
    }
    void chargeBattery() {
        System.out.println("Charging the battery");
    }
}


