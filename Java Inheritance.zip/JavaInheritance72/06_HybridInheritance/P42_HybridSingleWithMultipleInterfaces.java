/* Program 42: Hybrid inheritance - single class inheritance + multiple interface implementation */
public class P42_HybridSingleWithMultipleInterfaces {
    public static void main(String[] args) {
        Performer performer = new Performer("Lata");
        performer.introduce();  // single inheritance from Person
        performer.sing();       // multiple inheritance via Singer
        performer.dance();      // multiple inheritance via Dancer

        System.out.println("\nSingle class inheritance (Person) combined with multiple");
        System.out.println("interface inheritance (Singer, Dancer) forms a hybrid model.");
    }
}

class Person {
    String name;
    Person(String name) { this.name = name; }
    void introduce() { System.out.println("I am " + name); }
}

interface Singer {
    void sing();
}

interface Dancer {
    void dance();
}

class Performer extends Person implements Singer, Dancer {
    Performer(String name) { super(name); }
    public void sing() { System.out.println(name + " sings a song"); }
    public void dance() { System.out.println(name + " dances gracefully"); }
}


