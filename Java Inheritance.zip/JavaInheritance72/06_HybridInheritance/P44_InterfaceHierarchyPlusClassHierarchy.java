/* Program 44: Hybrid inheritance using an interface hierarchy combined with a class hierarchy */
public class P44_InterfaceHierarchyPlusClassHierarchy {
    public static void main(String[] args) {
        Rectangle rect = new Rectangle(8, 5);
        rect.display();

        System.out.println("\nMeasurable extends Shape2D  (interface hierarchy)");
        System.out.println("Rectangle extends BaseShape implements Measurable  (class hierarchy)");
        System.out.println("Combined, these two hierarchies form a hybrid design.");
    }
}

interface Shape2D {
    double area();
}

interface Measurable extends Shape2D {
    double perimeter();
}

abstract class BaseShape implements Measurable {
    String name;
    BaseShape(String name) { this.name = name; }
    void display() {
        System.out.printf("%s -> area=%.2f, perimeter=%.2f%n", name, area(), perimeter());
    }
}

class Rectangle extends BaseShape {
    double length, width;
    Rectangle(double length, double width) {
        super("Rectangle");
        this.length = length;
        this.width = width;
    }
    public double area() { return length * width; }
    public double perimeter() { return 2 * (length + width); }
}


