/* Program 22: Multilevel inheritance across 4 levels: A -> B -> C -> D */
public class P22_FourLevelChain {
    public static void main(String[] args) {
        D obj = new D();
        obj.methodA();   // level 1
        obj.methodB();   // level 2
        obj.methodC();   // level 3
        obj.methodD();   // level 4 (own)

        System.out.println("\nA D object carries the combined behaviour of A, B, C and D.");
        System.out.println("obj instanceof A : " + (obj instanceof A));
        System.out.println("obj instanceof B : " + (obj instanceof B));
        System.out.println("obj instanceof C : " + (obj instanceof C));
    }
}

class A {
    void methodA() { System.out.println("Method from class A"); }
}

class B extends A {
    void methodB() { System.out.println("Method from class B"); }
}

class C extends B {
    void methodC() { System.out.println("Method from class C"); }
}

class D extends C {
    void methodD() { System.out.println("Method from class D"); }
}


