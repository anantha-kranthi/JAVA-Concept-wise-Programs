/* Program 18: Multilevel inheritance - Vehicle -> Car -> SportsCar */
public class P18_VehicleCarSportsCar {
    public static void main(String[] args) {
        SportsCar ferrari = new SportsCar();
        ferrari.showWheels();          // level 1: Vehicle
        ferrari.showTransmission();    // level 2: Car
        ferrari.showTopSpeed();        // level 3: SportsCar's own

        System.out.println("\nAll three levels of behaviour are available on a SportsCar object.");
    }
}

class Vehicle {
    int wheels = 4;
    void showWheels() {
        System.out.println("Wheels: " + wheels);
    }
}

class Car extends Vehicle {
    String transmission = "Manual";
    void showTransmission() {
        System.out.println("Transmission: " + transmission);
    }
}

class SportsCar extends Car {
    int topSpeed = 300;
    void showTopSpeed() {
        System.out.println("Top speed: " + topSpeed + " km/h");
    }
}


