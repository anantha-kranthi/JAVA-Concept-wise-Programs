/* Program 24: Multilevel inheritance with constructor chaining */
public class P24_ConstructorChainingMultilevel {
    public static void main(String[] args) {
        System.out.println("Creating a Child object:\n");
        new Child();

        System.out.println("\nConstructors always run top-down: the topmost superclass's");
        System.out.println("constructor finishes first, then each level below it in turn.");
    }
}

class GrandParent {
    GrandParent() {
        System.out.println("1. GrandParent constructor executed");
    }
}

class Parent extends GrandParent {
    Parent() {
        super();   // explicit, though implicit call would happen anyway
        System.out.println("2. Parent constructor executed");
    }
}

class Child extends Parent {
    Child() {
        super();
        System.out.println("3. Child constructor executed");
    }
}


