/* Program 21: Multilevel inheritance - Device -> Computer -> Laptop */
public class P21_DeviceComputerLaptop {
    public static void main(String[] args) {
        Laptop laptop = new Laptop();
        laptop.ramGB = 16;
        laptop.batteryPercent = 80;

        laptop.powerOn();                 // from Device
        laptop.install("IDE");            // from Computer
        laptop.showBatteryStatus();       // Laptop's own
        System.out.println("Powered on state (inherited field): " + laptop.poweredOn);
    }
}

class Device {
    boolean poweredOn = false;
    void powerOn() {
        poweredOn = true;
        System.out.println("Device powered on");
    }
}

class Computer extends Device {
    int ramGB;
    void install(String software) {
        System.out.println("Installing " + software + " (RAM: " + ramGB + " GB)");
    }
}

class Laptop extends Computer {
    int batteryPercent;
    void showBatteryStatus() {
        System.out.println("Battery: " + batteryPercent + "%");
    }
}


