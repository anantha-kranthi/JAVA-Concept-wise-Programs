/* Program 17: Multilevel inheritance - Animal -> Mammal -> Dog */
public class P17_AnimalMammalDog {
    public static void main(String[] args) {
        Dog dog = new Dog();
        dog.eat();   // from Animal (grandparent)
        dog.walk();  // from Mammal (parent)
        dog.bark();  // Dog's own

        System.out.println("\nMultilevel inheritance chain: Animal -> Mammal -> Dog");
        System.out.println("Dog inherits from both Mammal and (transitively) Animal.");
    }
}

class Animal {
    void eat() {
        System.out.println("Animal eats food");
    }
}

class Mammal extends Animal {
    void walk() {
        System.out.println("Mammal walks on land");
    }
}

class Dog extends Mammal {
    void bark() {
        System.out.println("Dog barks");
    }
}


