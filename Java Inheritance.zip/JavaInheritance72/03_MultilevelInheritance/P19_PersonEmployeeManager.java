/* Program 19: Multilevel inheritance - Person -> Employee -> Manager */
public class P19_PersonEmployeeManager {
    public static void main(String[] args) {
        Manager manager = new Manager("Sunita Rao", 95000.0, 8);
        manager.showName();       // from Person
        manager.showSalary();     // from Employee
        manager.showTeamSize();   // Manager's own
    }
}

class Person {
    String name;
    Person(String name) { this.name = name; }
    void showName() { System.out.println("Name: " + name); }
}

class Employee extends Person {
    double salary;
    Employee(String name, double salary) {
        super(name);
        this.salary = salary;
    }
    void showSalary() { System.out.println("Salary: " + salary); }
}

class Manager extends Employee {
    int teamSize;
    Manager(String name, double salary, int teamSize) {
        super(name, salary);
        this.teamSize = teamSize;
    }
    void showTeamSize() { System.out.println("Team size: " + teamSize); }
}


