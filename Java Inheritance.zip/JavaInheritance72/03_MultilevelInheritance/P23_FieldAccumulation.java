/* Program 23: Field/method accumulation at each level of a multilevel hierarchy */
public class P23_FieldAccumulation {
    public static void main(String[] args) {
        Level3 obj = new Level3();

        System.out.println("field1 (from Level1) = " + obj.field1);
        System.out.println("field2 (from Level2) = " + obj.field2);
        System.out.println("field3 (from Level3) = " + obj.field3);

        int total = obj.field1 + obj.field2 + obj.field3;
        System.out.println("\nSum of all accumulated fields = " + total);

        System.out.println("\nEach level down the chain adds its own fields");
        System.out.println("on top of everything inherited from levels above it.");
    }
}

class Level1 {
    int field1 = 10;
}

class Level2 extends Level1 {
    int field2 = 20;
}

class Level3 extends Level2 {
    int field3 = 30;
}


