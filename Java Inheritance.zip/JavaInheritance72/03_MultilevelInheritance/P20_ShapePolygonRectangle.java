/* Program 20: Multilevel inheritance - Shape -> Polygon -> Rectangle */
public class P20_ShapePolygonRectangle {
    public static void main(String[] args) {
        Rectangle rect = new Rectangle(10, 5);
        rect.identify();               // from Shape
        System.out.println("Sides: " + rect.sides);   // from Polygon
        System.out.println("Area: " + rect.area());   // Rectangle's own
    }
}

class Shape {
    String name = "Shape";
    void identify() {
        System.out.println("I am a " + name);
    }
}

class Polygon extends Shape {
    int sides;
    Polygon(int sides) {
        this.sides = sides;
        name = "Polygon with " + sides + " sides";
    }
}

class Rectangle extends Polygon {
    double length, width;
    Rectangle(double length, double width) {
        super(4);          // a rectangle always has 4 sides
        this.length = length;
        this.width = width;
        name = "Rectangle";
    }
    double area() { return length * width; }
}


