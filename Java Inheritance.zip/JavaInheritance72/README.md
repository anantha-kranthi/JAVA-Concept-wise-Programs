# 72 Java Programs on Inheritance

A complete, tested set of 72 Java programs covering Inheritance and its
types: Introduction, Single, Multilevel, Hierarchical, Multiple (via
interfaces), Hybrid, the `super` keyword, Overriding & Polymorphism, and
Constructors/Abstract classes/Special cases.

Every program is a standalone file. All 72 were compiled and executed
successfully on OpenJDK 21.

## How to run

With a JDK installed (Java 11 or later):

    javac P01_SimpleParentChild.java
    java P01_SimpleParentChild

Or, with Java 11+, run the source file directly in one step:

    java P01_SimpleParentChild.java

Each file's public class (the one with `main`) matches the file name, but
since several files also declare small helper classes (Parent, Animal,
Dog, etc.) in the same file, the public class is placed FIRST in the file
- this is required for Java's single-file source-launcher mode to find
`main`, and is also good practice for any file containing multiple classes.

## Contents

### 01_Introduction (Programs 1-8)
Basic IS-A relationship, field/method inheritance, private member visibility,
reusability, instanceof, the implicit Object superclass, why classes can't
have two direct superclasses, and upcasting.

### 02_SingleInheritance (Programs 9-16)
One class extends exactly one other: Animal-Dog, Vehicle-Car,
Person-Employee, Shape-Circle, BankAccount-SavingsAccount, Bird-Sparrow,
Calculator-ScientificCalculator, Furniture-Chair.

### 03_MultilevelInheritance (Programs 17-24)
Chains of inheritance (A -> B -> C ...): Animal-Mammal-Dog,
Vehicle-Car-SportsCar, Person-Employee-Manager, Shape-Polygon-Rectangle,
Device-Computer-Laptop, a 4-level chain, field accumulation, and
constructor chaining.

### 04_HierarchicalInheritance (Programs 25-32)
One superclass, many sibling subclasses: Animal->{Dog,Cat,Cow},
Shape->{Circle,Square,Triangle}, Employee->{Manager,Developer,Tester},
Vehicle->{Car,Bike,Truck}, BankAccount->{Savings,Current,FixedDeposit},
array-of-superclass-reference processing, and per-subclass overriding.

### 05_MultipleInheritance_Interfaces (Programs 33-40)
Java's approach to multiple inheritance using interfaces: two and three
interfaces on one class, resolving the diamond problem with default
methods, Printable/Scannable, Flyable/Swimmable, a class extending one
class while implementing many interfaces, interface-extends-interface,
and overriding conflicting default methods.

### 06_HybridInheritance (Programs 41-48)
Combinations of the above types in one design: hierarchical + multilevel,
single + multiple interfaces, multilevel + interface, interface hierarchy
+ class hierarchy, and realistic hybrid systems (college management,
employee roles, shapes with Comparable, a media player).

### 07_SuperKeyword (Programs 49-56)
Using `super` for constructors (with and without arguments), calling an
overridden method's original version, accessing a hidden field, the
implicit no-arg super() call, constructor execution order, the "super()
must be first" rule, and combining super for both a field and a method.

### 08_OverridingPolymorphism (Programs 57-64)
Basic overriding, runtime polymorphism / dynamic dispatch, overriding vs
overloading, covariant return types, access-modifier widening rules,
why `final` methods can't be overridden, why `static` methods are hidden
(not overridden), and the `@Override` annotation.

### 09_ConstructorsAbstractSpecialCases (Programs 65-72)
Constructor chaining across 3 levels, abstract superclasses, why
constructors aren't inherited, why `final` classes can't be extended,
safe downcasting with instanceof, field hiding vs method overriding,
a conceptual cleanup-order example, and a complete real-world Employee/
Manager/Developer/Intern hierarchy with overridden salary calculation.
