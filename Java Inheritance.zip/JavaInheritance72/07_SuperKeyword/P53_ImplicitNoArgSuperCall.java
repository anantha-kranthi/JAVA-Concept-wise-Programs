/* Program 53: Implicit call to the superclass's no-argument constructor */
public class P53_ImplicitNoArgSuperCall {
    public static void main(String[] args) {
        new Derived();

        System.out.println("\nEven with no explicit super() call, Java always invokes the");
        System.out.println("superclass's no-argument constructor first, implicitly.");
    }
}

class Base {
    Base() {
        // No explicit super() written here, but Object's constructor
        // is implicitly called first (since Base has no parent of its own).
        System.out.println("Base constructor executed");
    }
}

class Derived extends Base {
    Derived() {
        // No super() written here either - the compiler inserts an
        // implicit call to Base's no-arg constructor automatically.
        System.out.println("Derived constructor executed");
    }
}


