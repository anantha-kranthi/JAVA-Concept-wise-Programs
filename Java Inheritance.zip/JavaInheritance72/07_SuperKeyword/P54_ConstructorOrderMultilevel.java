/* Program 54: Constructor execution order in a multilevel hierarchy using super */
public class P54_ConstructorOrderMultilevel {
    public static void main(String[] args) {
        System.out.println("Creating a Child object:\n");
        new Child();

        System.out.println("\nExecution always proceeds from the topmost ancestor downward,");
        System.out.println("regardless of how many levels the hierarchy has.");
    }
}

class GrandParent {
    GrandParent() {
        System.out.println("Step 1: GrandParent constructor");
    }
}

class Parent extends GrandParent {
    Parent() {
        super();
        System.out.println("Step 2: Parent constructor");
    }
}

class Child extends Parent {
    Child() {
        super();
        System.out.println("Step 3: Child constructor");
    }
}


