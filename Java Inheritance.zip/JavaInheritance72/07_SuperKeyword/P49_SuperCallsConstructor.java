/* Program 49: Using super to call the immediate superclass's constructor */
public class P49_SuperCallsConstructor {
    public static void main(String[] args) {
        new Derived();

        System.out.println("\nsuper() must refer to the DIRECT superclass's constructor,");
        System.out.println("not any constructor further up the hierarchy.");
    }
}

class Base {
    Base() {
        System.out.println("Base class constructor called");
    }
}

class Derived extends Base {
    Derived() {
        super();   // explicitly calling Base's no-arg constructor
        System.out.println("Derived class constructor called");
    }
}


