/* Program 52: Using super.fieldName to access a superclass field hidden by the subclass */
public class P52_SuperAccessesHiddenField {
    public static void main(String[] args) {
        Car car = new Car();
        car.showTypes();

        System.out.println("\nUnlike methods, fields are NOT polymorphic - they are hidden,");
        System.out.println("not overridden, so 'super.type' is the only way to reach the parent's value.");
    }
}

class Vehicle {
    String type = "Generic Vehicle";
}

class Car extends Vehicle {
    String type = "Car";   // this field HIDES (not overrides) the superclass field

    void showTypes() {
        System.out.println("Subclass field (this.type)  : " + this.type);
        System.out.println("Superclass field (super.type): " + super.type);
    }
}


