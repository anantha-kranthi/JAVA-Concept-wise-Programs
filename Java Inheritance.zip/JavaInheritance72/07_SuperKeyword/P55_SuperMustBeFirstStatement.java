/* Program 55: super() must be the first statement in a constructor.
   This program demonstrates the rule using a comment, since violating
   it causes a compile-time error. */
public class P55_SuperMustBeFirstStatement {
    public static void main(String[] args) {
        new Derived();

        System.out.println("\nRule: super(...) or this(...), if used, must be the very");
        System.out.println("first executable statement inside a constructor.");
    }
}

class Base {
    Base(String msg) {
        System.out.println("Base: " + msg);
    }
}

class Derived extends Base {
    Derived() {
        super("Hello from Derived");   // MUST be the first line - this compiles fine

        // The following would NOT compile if placed BEFORE super(...):
        // int x = 10;
        // super("Hello from Derived");   // ERROR: "call to super must be first statement"

        System.out.println("Derived constructor body continues after super()");
    }
}


