/* Program 50: Using super() to pass arguments to a parameterized superclass constructor */
public class P50_SuperWithArguments {
    public static void main(String[] args) {
        Student student = new Student("Vikram", 20, "Computer Science");
        System.out.println("\nFinal object -> " + student.name + ", " + student.age
                + ", " + student.course);
    }
}

class Person {
    String name;
    int age;

    Person(String name, int age) {
        this.name = name;
        this.age = age;
        System.out.println("Person constructor: " + name + ", " + age);
    }
}

class Student extends Person {
    String course;

    Student(String name, int age, String course) {
        super(name, age);   // passing arguments up to Person's constructor
        this.course = course;
        System.out.println("Student constructor: enrolled in " + course);
    }
}


