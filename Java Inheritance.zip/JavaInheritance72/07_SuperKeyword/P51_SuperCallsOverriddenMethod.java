/* Program 51: Using super.methodName() to call an overridden superclass method */
public class P51_SuperCallsOverriddenMethod {
    public static void main(String[] args) {
        ColorPrinter cp = new ColorPrinter();
        cp.printMessage();

        System.out.println("\nWithout super.printMessage(), the overriding method would");
        System.out.println("completely replace the superclass version instead of extending it.");
    }
}

class Printer {
    void printMessage() {
        System.out.println("Printer: default message");
    }
}

class ColorPrinter extends Printer {
    @Override
    void printMessage() {
        super.printMessage();   // still invoke the original superclass behaviour
        System.out.println("ColorPrinter: message printed in color");
    }
}


