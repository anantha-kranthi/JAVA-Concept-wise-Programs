/* Program 56: Combining super for both a field and a method in the same subclass */
public class P56_SuperForFieldAndMethod {
    public static void main(String[] args) {
        Circle circle = new Circle();
        circle.describe();

        System.out.println("\nsuper.fieldName reaches a hidden field; super.methodName()");
        System.out.println("reaches an overridden method's original implementation.");
    }
}

class Shape {
    String name = "Shape";

    void describe() {
        System.out.println("I am a generic " + name);
    }
}

class Circle extends Shape {
    String name = "Circle";   // hides Shape's 'name' field

    @Override
    void describe() {
        System.out.println("Superclass field via super.name  : " + super.name);
        System.out.println("Subclass field via this.name     : " + this.name);

        super.describe();     // calling the overridden method's original version
        System.out.println("Circle-specific describe() logic executed too");
    }
}


