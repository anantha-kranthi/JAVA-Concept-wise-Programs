/* Program 63: Static methods are HIDDEN, not overridden, in inheritance */
public class P63_StaticMethodsHiddenNotOverridden {
    public static void main(String[] args) {
        Base baseRef = new Derived();

        baseRef.staticMethod();     // calls Base's version! Decided by REFERENCE TYPE (compile time)
        baseRef.instanceMethod();   // calls Derived's version! Decided by OBJECT TYPE (run time)

        System.out.println("\nStatic method calls are resolved at COMPILE time using the");
        System.out.println("reference's declared type - there is no dynamic dispatch for them.");
        System.out.println("Instance method calls are resolved at RUN time using the actual object.");
    }
}

class Base {
    static void staticMethod() {
        System.out.println("Base: static method");
    }

    void instanceMethod() {
        System.out.println("Base: instance method");
    }
}

class Derived extends Base {
    static void staticMethod() {   // this HIDES Base's static method, does not override it
        System.out.println("Derived: static method");
    }

    @Override
    void instanceMethod() {        // this genuinely OVERRIDES
        System.out.println("Derived: instance method");
    }
}


