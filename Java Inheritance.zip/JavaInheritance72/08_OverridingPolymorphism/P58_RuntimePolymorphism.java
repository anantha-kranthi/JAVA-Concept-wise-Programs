/* Program 58: Runtime polymorphism (dynamic method dispatch) with inheritance */
public class P58_RuntimePolymorphism {
    public static void main(String[] args) {
        Shape shapeRef;   // the DECLARED type never changes

        shapeRef = new Circle();
        shapeRef.draw();   // Circle's draw() runs - decided at RUN TIME

        shapeRef = new Square();
        shapeRef.draw();   // Square's draw() runs - decided at RUN TIME

        System.out.println("\nThe JVM looks at the ACTUAL object type, not the reference's");
        System.out.println("declared type, to decide which overridden method body executes.");
        System.out.println("This is called dynamic method dispatch.");
    }
}

class Shape {
    void draw() {
        System.out.println("Drawing a generic shape");
    }
}

class Circle extends Shape {
    @Override
    void draw() { System.out.println("Drawing a circle"); }
}

class Square extends Shape {
    @Override
    void draw() { System.out.println("Drawing a square"); }
}


