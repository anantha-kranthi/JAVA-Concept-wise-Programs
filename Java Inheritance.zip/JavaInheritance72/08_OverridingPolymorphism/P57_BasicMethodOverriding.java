/* Program 57: Basic method overriding between a superclass and a subclass */
public class P57_BasicMethodOverriding {
    public static void main(String[] args) {
        Animal animal = new Animal();
        Cat cat = new Cat();

        animal.sound();   // Animal's own version
        cat.sound();      // Cat's overridden version

        System.out.println("\nOverriding requires: same method name, same parameters,");
        System.out.println("and a compatible return type in the subclass.");
    }
}

class Animal {
    void sound() {
        System.out.println("Animal makes a sound");
    }
}

class Cat extends Animal {
    @Override
    void sound() {
        System.out.println("Cat meows");   // completely replaces Animal's version
    }
}


