/* Program 62: A final method cannot be overridden.
   The illegal override is shown only as a comment. */
public class P62_FinalMethodCannotBeOverridden {
    public static void main(String[] args) {
        Derived d = new Derived();
        d.securityCheck();   // always Base's version - guaranteed by 'final'
        d.normalMethod();    // overridden version runs

        System.out.println("\n'final' on a method locks its implementation permanently");
        System.out.println("across the entire inheritance hierarchy below it.");
    }
}

class Base {
    final void securityCheck() {
        System.out.println("Base: performing a fixed, non-overridable security check");
    }

    void normalMethod() {
        System.out.println("Base: normalMethod (can be overridden)");
    }
}

class Derived extends Base {
    // The following would NOT compile if uncommented:
    // @Override
    // void securityCheck() { System.out.println("Derived: trying to override"); }
    // Compiler error: "securityCheck() in Derived cannot override securityCheck() in Base;
    //                   overridden method is final"

    @Override
    void normalMethod() {
        System.out.println("Derived: normalMethod overridden successfully");
    }
}


