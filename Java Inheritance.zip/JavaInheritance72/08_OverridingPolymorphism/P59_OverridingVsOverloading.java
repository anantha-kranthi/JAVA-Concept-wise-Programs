/* Program 59: Difference between method overriding and method overloading in inheritance */
public class P59_OverridingVsOverloading {
    public static void main(String[] args) {
        Calculator calc = new Calculator();
        System.out.println("Overloading -> add(int,int)      : " + calc.add(2, 3));
        System.out.println("Overloading -> add(double,double): " + calc.add(2.5, 3.5));

        AdvancedCalculator adv = new AdvancedCalculator();
        adv.showType();   // overridden version

        System.out.println("\nOverloading: resolved at COMPILE time (by parameter list), same class.");
        System.out.println("Overriding : resolved at RUN time (by actual object), across classes.");
    }
}

class Calculator {
    // Overloading: same class, same name, DIFFERENT parameter lists
    int add(int a, int b) { return a + b; }
    double add(double a, double b) { return a + b; }

    void showType() {
        System.out.println("This is Calculator");
    }
}

class AdvancedCalculator extends Calculator {
    // Overriding: subclass, SAME signature as the superclass method
    @Override
    void showType() {
        System.out.println("This is AdvancedCalculator (overridden)");
    }
}


