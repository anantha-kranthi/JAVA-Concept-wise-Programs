/* Program 60: Overriding rule - covariant return types */
public class P60_ReturnTypeCovariance {
    public static void main(String[] args) {
        Animal animal = new Animal();
        Animal offspring1 = animal.reproduce();
        System.out.println("offspring1 class: " + offspring1.getClass().getSimpleName());

        Dog dog = new Dog();
        Dog offspring2 = dog.reproduce();   // returns Dog directly, no cast needed
        System.out.println("offspring2 class: " + offspring2.getClass().getSimpleName());

        System.out.println("\nSince Java 5, an overriding method may return a subtype");
        System.out.println("of the type the superclass method declares - this is covariance.");
    }
}

class Animal {
    Animal reproduce() {
        System.out.println("Animal reproduces -> returns an Animal");
        return new Animal();
    }
}

class Dog extends Animal {
    // A narrower (subclass) return type is allowed when overriding - "covariant return"
    @Override
    Dog reproduce() {
        System.out.println("Dog reproduces -> returns a Dog (narrower than Animal)");
        return new Dog();
    }
}


