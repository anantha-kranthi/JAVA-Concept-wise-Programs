/* Program 64: Using the @Override annotation and the compiler check it provides */
public class P64_OverrideAnnotation {
    public static void main(String[] args) {
        Derived d = new Derived();
        d.display(10);

        System.out.println("\n@Override is optional but strongly recommended: it makes the");
        System.out.println("compiler verify that a matching superclass method really exists,");
        System.out.println("catching typos in method name or parameter list immediately.");
    }
}

class Base {
    void display(int x) {
        System.out.println("Base display(int): " + x);
    }
}

class Derived extends Base {
    // Correct override - matches Base's signature exactly
    @Override
    void display(int x) {
        System.out.println("Derived display(int): " + x);
    }

    // The following would trigger a compiler ERROR because of @Override,
    // catching what would otherwise be a silent overloading mistake:
    // @Override
    // void display(int x, int y) { }
    // Error: "method does not override a method from its superclass"
    // (Without @Override, this would silently become an unrelated
    //  overloaded method instead of the intended override - a common bug.)
}


