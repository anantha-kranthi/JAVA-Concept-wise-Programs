/* Program 61: Overriding rule - access modifier cannot be MORE restrictive.
   The illegal case is shown only as a comment, since it would not compile. */
public class P61_AccessModifierRestriction {
    public static void main(String[] args) {
        Base ref = new Derived();
        ref.show();

        System.out.println("\nRule: an overriding method's access level must be the SAME as,");
        System.out.println("or MORE permissive than, the method it overrides - never narrower.");
        System.out.println("(private -> default -> protected -> public, in increasing openness)");
    }
}

class Base {
    protected void show() {
        System.out.println("Base: protected show()");
    }
}

class Derived extends Base {
    // LEGAL: widening access from protected to public
    @Override
    public void show() {
        System.out.println("Derived: public show() - widened access, allowed");
    }

    // ILLEGAL if uncommented: reducing access from protected to private/default
    // @Override
    // private void show() { }   // ERROR: cannot reduce the visibility of the inherited method
}


