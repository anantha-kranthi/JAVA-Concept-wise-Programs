// Assumption: 'var' is resolved to a concrete type at compile time (static typing), not dynamic typing.
public class VarTypeInferenceDemo {
    public static void main(String[] args) {
        var i = 10;
        var d = 3.14;
        var c = 'x';
        var b = true;
        System.out.println(i + " " + d + " " + c + " " + b);
    }
}
