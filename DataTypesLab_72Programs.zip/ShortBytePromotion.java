// Assumption: byte/short arithmetic always promotes to int; result needs an explicit cast to narrow back.
public class ShortBytePromotion {
    public static void main(String[] args) {
        byte b1 = 10, b2 = 20;
        int sum = b1 + b2;
        byte result = (byte) (b1 + b2);
        System.out.println("sum as int: " + sum);
        System.out.println("sum cast back to byte: " + result);
    }
}
