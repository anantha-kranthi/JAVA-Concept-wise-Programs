// Assumption: sizes are JVM spec bit-widths; defaults come from fields (JVM zeroes object memory).
public class PrimitiveSizeDefault {
    byte b; short s; int i; long l; float f; double d; char c; boolean bo;
    public static void main(String[] args) {
        PrimitiveSizeDefault o = new PrimitiveSizeDefault();
        System.out.println("byte: 8 bits, default=" + o.b);
        System.out.println("short: 16 bits, default=" + o.s);
        System.out.println("int: 32 bits, default=" + o.i);
        System.out.println("long: 64 bits, default=" + o.l);
        System.out.println("float: 32 bits, default=" + o.f);
        System.out.println("double: 64 bits, default=" + o.d);
        System.out.println("char: 16 bits, default code point=" + (int) o.c);
        System.out.println("boolean: 1 bit, default=" + o.bo);
    }
}
