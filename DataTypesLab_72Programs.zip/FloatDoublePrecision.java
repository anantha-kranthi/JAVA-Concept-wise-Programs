// Assumption: same fractional value (1/3) computed in both types to expose the precision gap.
public class FloatDoublePrecision {
    public static void main(String[] args) {
        float f = 1f / 3f;
        double d = 1.0 / 3.0;
        System.out.println("float 1/3  = " + f);
        System.out.println("double 1/3 = " + d);
    }
}
