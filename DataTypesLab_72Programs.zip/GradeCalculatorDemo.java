// Assumption: marks/total stored as int is fine, but percentage MUST be computed in double, or it truncates to 0.
public class GradeCalculatorDemo {
    public static void main(String[] args) {
        int marks = 87, total = 120;
        int wrongPercent = marks / total * 100;
        double rightPercent = (double) marks / total * 100;
        System.out.println("wrong (int): " + wrongPercent);
        System.out.println("right (double): " + rightPercent);
    }
}
