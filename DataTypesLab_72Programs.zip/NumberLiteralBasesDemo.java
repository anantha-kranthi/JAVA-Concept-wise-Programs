// Assumption: demonstrating binary, octal, and hex literals all resolving to the same underlying int type.
public class NumberLiteralBasesDemo {
    public static void main(String[] args) {
        int bin = 0b1010;
        int oct = 010;
        int hex = 0x1A;
        System.out.println("binary 0b1010 = " + bin);
        System.out.println("octal 010 = " + oct);
        System.out.println("hex 0x1A = " + hex);
    }
}
