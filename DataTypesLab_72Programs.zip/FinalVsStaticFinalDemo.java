// Assumption: instance final = one copy per object; static final = one shared copy across all objects.
public class FinalVsStaticFinalDemo {
    final int instanceConst = 10;
    static final int CLASS_CONST = 20;
    public static void main(String[] args) {
        FinalVsStaticFinalDemo o1 = new FinalVsStaticFinalDemo();
        System.out.println("instance const (per object): " + o1.instanceConst);
        System.out.println("class const (shared): " + FinalVsStaticFinalDemo.CLASS_CONST);
    }
}
