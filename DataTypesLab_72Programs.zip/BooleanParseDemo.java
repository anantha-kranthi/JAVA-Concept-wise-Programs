// Assumption: Boolean.parseBoolean() only returns true for case-insensitive "true"; everything else is false.
public class BooleanParseDemo {
    public static void main(String[] args) {
        String[] inputs = {"true", "TRUE", "yes", "", "false"};
        for (String s : inputs) {
            System.out.println("\"" + s + "\" -> " + Boolean.parseBoolean(s));
        }
    }
}
