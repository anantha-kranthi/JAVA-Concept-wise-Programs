// Assumption: demonstrating the classic binary floating point representation issue.
public class FloatingPointEquality {
    public static void main(String[] args) {
        double a = 0.1 + 0.2;
        System.out.println("0.1 + 0.2 = " + a);
        System.out.println("equals 0.3? " + (a == 0.3));
    }
}
