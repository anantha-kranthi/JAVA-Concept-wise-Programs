// Assumption: classic mistake -- casting the RESULT of int division vs casting an OPERAND before dividing.
public class IntDivisionInCastDemo {
    public static void main(String[] args) {
        double wrong = (double) (7 / 2);
        double right = (double) 7 / 2;
        System.out.println("wrong: " + wrong);
        System.out.println("right: " + right);
    }
}
