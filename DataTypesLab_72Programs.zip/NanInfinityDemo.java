// Assumption: 0.0/0.0 -> NaN, nonzero/0.0 -> +/-Infinity for floating point, no exception thrown.
public class NanInfinityDemo {
    public static void main(String[] args) {
        double nan = 0.0 / 0.0;
        double posInf = 1.0 / 0.0;
        double negInf = -1.0 / 0.0;
        System.out.println("0.0/0.0 = " + nan + ", isNaN=" + Double.isNaN(nan));
        System.out.println("1.0/0.0 = " + posInf);
        System.out.println("-1.0/0.0 = " + negInf);
    }
}
