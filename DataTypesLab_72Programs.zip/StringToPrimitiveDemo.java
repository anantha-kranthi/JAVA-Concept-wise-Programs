// Assumption: invalid numeric strings should be caught, not left to crash the program.
public class StringToPrimitiveDemo {
    public static void main(String[] args) {
        System.out.println(Integer.parseInt("123"));
        System.out.println(Double.parseDouble("3.14"));
        System.out.println(Boolean.parseBoolean("true"));
        try {
            Integer.parseInt("abc");
        } catch (NumberFormatException e) {
            System.out.println("invalid input caught: " + e.getMessage());
        }
    }
}
