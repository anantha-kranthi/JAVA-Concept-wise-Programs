// Assumption: scientific notation literals are valid for float/double and expand to normal decimals.
public class ScientificNotationDemo {
    public static void main(String[] args) {
        double a = 1.5e3;
        double b = 2.5E-4;
        System.out.println("1.5e3 = " + a);
        System.out.println("2.5E-4 = " + b);
    }
}
