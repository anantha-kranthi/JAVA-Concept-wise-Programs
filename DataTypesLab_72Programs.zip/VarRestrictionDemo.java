// Assumption: 'var' only works for local variables, not fields or method parameters.
// var field; // COMPILE ERROR: 'var' is not allowed here
// static void method(var x) {} // COMPILE ERROR: 'var' not allowed as parameter type
public class VarRestrictionDemo {
    int field = 5;
    public static void main(String[] args) {
        var local = 5;
        System.out.println("local: " + local);
    }
}
