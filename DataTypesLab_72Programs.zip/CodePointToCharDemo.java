// Assumption: valid input is any int within the 16-bit char range (0-65535) for a direct cast.
public class CodePointToCharDemo {
    public static void main(String[] args) {
        int codePoint = 9731;
        char symbol = (char) codePoint;
        System.out.println("code point " + codePoint + " -> " + symbol);
    }
}
