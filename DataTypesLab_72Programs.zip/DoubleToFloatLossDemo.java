// Assumption: loss quantified using absolute difference between double and its float cast.
public class DoubleToFloatLossDemo {
    public static void main(String[] args) {
        double d = 123456789.987654321;
        float f = (float) d;
        System.out.println("original: " + d);
        System.out.println("as float: " + f);
        System.out.println("loss: " + Math.abs(d - f));
    }
}
