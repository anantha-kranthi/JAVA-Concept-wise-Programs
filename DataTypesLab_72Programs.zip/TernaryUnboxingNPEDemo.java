// Assumption: ternary result type unification can force unboxing of the unused null branch, throwing NPE.
public class TernaryUnboxingNPEDemo {
    public static void main(String[] args) {
        Integer a = null;
        boolean condition = false;
        try {
            int result = condition ? 5 : a;
            System.out.println(result);
        } catch (NullPointerException e) {
            System.out.println("caught NPE from ternary unboxing");
        }
    }
}
