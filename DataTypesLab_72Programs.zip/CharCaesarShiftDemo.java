// Assumption: char + int gives int; explicit cast is required to store the shifted result as a char.
public class CharCaesarShiftDemo {
    public static void main(String[] args) {
        char c = 'a';
        int shifted = c + 3;
        char result = (char) shifted;
        System.out.println(c + " shifted by 3 -> " + result);
    }
}
