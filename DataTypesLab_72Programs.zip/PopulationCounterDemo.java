// Assumption: country-scale populations still fit in int, but world population requires long.
public class PopulationCounterDemo {
    public static void main(String[] args) {
        int intPopulation = 1400000000;
        long longPopulation = 8000000000L;
        System.out.println("int population: " + intPopulation);
        System.out.println("long population: " + longPopulation);
    }
}
