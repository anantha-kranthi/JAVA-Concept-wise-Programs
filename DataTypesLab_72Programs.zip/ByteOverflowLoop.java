// Assumption: valid input is any starting byte; loop count fixed at 5 to show wraparound clearly.
public class ByteOverflowLoop {
    public static void main(String[] args) {
        byte b = 125;
        for (int i = 0; i < 5; i++) {
            System.out.println(b);
            b++;
        }
    }
}
