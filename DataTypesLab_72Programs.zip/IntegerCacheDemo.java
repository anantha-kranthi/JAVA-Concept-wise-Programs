// Assumption: Integer caches values -128 to 127; == compares references, .equals() compares value.
public class IntegerCacheDemo {
    public static void main(String[] args) {
        Integer a = 100, b = 100;
        Integer c = 200, d = 200;
        System.out.println("100==100 (cached): " + (a == b));
        System.out.println("200==200 (not cached): " + (c == d));
        System.out.println("200.equals(200): " + c.equals(d));
    }
}
