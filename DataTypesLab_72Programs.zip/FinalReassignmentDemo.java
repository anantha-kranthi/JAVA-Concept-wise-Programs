// Assumption: final locals can be assigned once; reassignment is a compile error, shown as a comment.
public class FinalReassignmentDemo {
    public static void main(String[] args) {
        final int x = 10;
        System.out.println("x: " + x);
        // x = 20; // COMPILE ERROR: cannot assign a value to final variable x
    }
}
