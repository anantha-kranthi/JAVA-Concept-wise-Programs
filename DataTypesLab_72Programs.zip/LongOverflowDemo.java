// Assumption: same wraparound concept as int, but at long's much larger boundary.
public class LongOverflowDemo {
    public static void main(String[] args) {
        long max = Long.MAX_VALUE;
        System.out.println("MAX_VALUE = " + max);
        System.out.println("MAX_VALUE + 1 = " + (max + 1));
    }
}
