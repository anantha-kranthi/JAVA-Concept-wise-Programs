// Assumption: parseInt returns a primitive int; valueOf returns a boxed Integer object.
public class ParseIntVsValueOf {
    public static void main(String[] args) {
        int primitive = Integer.parseInt("42");
        Integer wrapper = Integer.valueOf("42");
        System.out.println("primitive: " + primitive);
        System.out.println("wrapper: " + wrapper);
    }
}
