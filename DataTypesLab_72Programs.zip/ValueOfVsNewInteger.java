// Assumption: Integer.valueOf() may return a cached shared instance for small values.
public class ValueOfVsNewInteger {
    public static void main(String[] args) {
        Integer a = Integer.valueOf(100);
        Integer b = Integer.valueOf(100);
        System.out.println("valueOf same instance? " + (a == b));
    }
}
