// Assumption: printing the four commonly used Integer class constants together.
public class IntegerConstantsDemo {
    public static void main(String[] args) {
        System.out.println("MAX_VALUE: " + Integer.MAX_VALUE);
        System.out.println("MIN_VALUE: " + Integer.MIN_VALUE);
        System.out.println("SIZE (bits): " + Integer.SIZE);
        System.out.println("BYTES: " + Integer.BYTES);
    }
}
