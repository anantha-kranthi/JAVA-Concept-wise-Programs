// Assumption: wrapper class fields default to null, unlike primitive fields which default to 0.
public class WrapperDefaultNullDemo {
    int primitiveField;
    Integer wrapperField;
    public static void main(String[] args) {
        WrapperDefaultNullDemo o = new WrapperDefaultNullDemo();
        System.out.println("primitive default: " + o.primitiveField);
        System.out.println("wrapper default: " + o.wrapperField);
    }
}
