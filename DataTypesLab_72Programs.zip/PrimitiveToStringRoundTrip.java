// Assumption: round-trip (primitive -> String -> primitive) should return the exact original value.
public class PrimitiveToStringRoundTrip {
    public static void main(String[] args) {
        int i = 42;
        String s = String.valueOf(i);
        int back = Integer.parseInt(s);
        System.out.println("original: " + i + ", round-trip: " + back + ", equal: " + (i == back));
    }
}
