// Assumption: demonstrating all common literal bases plus underscore-separated readability.
public class IntegerLiteralFormsDemo {
    public static void main(String[] args) {
        int dec = 1000000;
        int bin = 0b11110100001001000000;
        int oct = 03641100;
        int hex = 0xF4240;
        int readable = 1_000_000;
        System.out.println(dec + " " + bin + " " + oct + " " + hex + " " + readable);
    }
}
