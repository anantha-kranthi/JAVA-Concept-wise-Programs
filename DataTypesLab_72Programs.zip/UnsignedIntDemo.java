// Assumption: comparing plain signed toString() with Integer.toUnsignedString() for the same bit pattern.
public class UnsignedIntDemo {
    public static void main(String[] args) {
        int negative = -1;
        System.out.println("plain toString: " + negative);
        System.out.println("as unsigned: " + Integer.toUnsignedString(negative));
    }
}
