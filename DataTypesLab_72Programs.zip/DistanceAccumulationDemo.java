// Assumption: repeated addition of the same small value in float vs double exposes accumulated rounding error.
public class DistanceAccumulationDemo {
    public static void main(String[] args) {
        float floatTotal = 0f;
        double doubleTotal = 0.0;
        for (int i = 0; i < 100000; i++) {
            floatTotal += 0.1f;
            doubleTotal += 0.1;
        }
        System.out.println("float total: " + floatTotal);
        System.out.println("double total: " + doubleTotal);
    }
}
