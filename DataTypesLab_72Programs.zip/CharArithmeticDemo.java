// Assumption: char+int promotes to int automatically; getting a char back needs an explicit cast.
public class CharArithmeticDemo {
    public static void main(String[] args) {
        char c = 'a';
        int sum = c + 1;
        System.out.println("'a' + 1 as int = " + sum);
        char next = (char) (c + 1);
        System.out.println("'a' + 1 as char = " + next);
    }
}
