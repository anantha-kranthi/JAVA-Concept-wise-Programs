// Assumption: int-only formula truncates the fraction mid-calculation; double formula is correct.
public class TemperatureConverterBug {
    public static void main(String[] args) {
        int celsius = 37;
        int wrongF = celsius * 9 / 5 + 32;
        double rightF = celsius * 9.0 / 5 + 32;
        System.out.println("int version: " + wrongF);
        System.out.println("double version: " + rightF);
    }
}
