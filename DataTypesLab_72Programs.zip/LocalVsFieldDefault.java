// Assumption: fields get JVM defaults; locals need definite assignment before use.
public class LocalVsFieldDefault {
    int fieldInt;
    public static void main(String[] args) {
        LocalVsFieldDefault o = new LocalVsFieldDefault();
        System.out.println("field default: " + o.fieldInt);
        int localInt;
        // System.out.println(localInt); // uncomment: "might not have been initialized"
        localInt = 5;
        System.out.println("local after assignment: " + localInt);
    }
}
