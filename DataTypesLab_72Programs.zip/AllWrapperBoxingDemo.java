// Assumption: demonstrating autoboxing for all 8 wrapper classes in one place.
public class AllWrapperBoxingDemo {
    public static void main(String[] args) {
        Byte by = 1; Short sh = 2; Integer in = 3; Long lo = 4L;
        Float fl = 5.0f; Double du = 6.0; Character ch = 'x'; Boolean bo = true;
        System.out.println(by + " " + sh + " " + in + " " + lo + " " + fl + " " + du + " " + ch + " " + bo);
    }
}
