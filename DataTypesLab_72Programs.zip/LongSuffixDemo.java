// Assumption: 'L' suffix required once the literal exceeds int range; failing code shown as comment only.
// long bad = 10000000000; // COMPILE ERROR: integer number too large
public class LongSuffixDemo {
    public static void main(String[] args) {
        long l = 10000000000L;
        System.out.println("long value: " + l);
    }
}
