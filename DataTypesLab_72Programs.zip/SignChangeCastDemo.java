// Assumption: casting int 200 to byte flips its sign due to wraparound past byte's max (127).
public class SignChangeCastDemo {
    public static void main(String[] args) {
        int i = 200;
        byte b = (byte) i;
        System.out.println("200 as byte = " + b);
    }
}
