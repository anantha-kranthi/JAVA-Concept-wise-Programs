// Assumption: "quantify the loss" means print the exact difference between original and cast value.
public class DoubleToIntLossDemo {
    public static void main(String[] args) {
        double d = 99.987654321;
        int i = (int) d;
        System.out.println("original: " + d);
        System.out.println("as int: " + i);
        System.out.println("loss: " + (d - i));
    }
}
