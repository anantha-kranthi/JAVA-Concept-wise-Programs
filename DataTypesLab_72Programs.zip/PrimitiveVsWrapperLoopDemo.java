// Assumption: repeated boxing/unboxing inside a loop is slower than pure primitive arithmetic.
public class PrimitiveVsWrapperLoopDemo {
    public static void main(String[] args) {
        long start1 = System.nanoTime();
        int sum1 = 0;
        for (int i = 0; i < 1000000; i++) sum1 += i;
        long end1 = System.nanoTime();

        long start2 = System.nanoTime();
        Integer sum2 = 0;
        for (int i = 0; i < 1000000; i++) sum2 += i;
        long end2 = System.nanoTime();

        System.out.println("primitive loop time (ns): " + (end1 - start1));
        System.out.println("wrapper loop time (ns): " + (end2 - start2));
    }
}
