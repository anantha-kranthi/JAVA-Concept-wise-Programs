// Assumption: arithmetic between an Integer and an int auto-unboxes the Integer operand.
public class AutoUnboxingArithmetic {
    public static void main(String[] args) {
        Integer a = 5;
        int b = 3;
        int sum = a + b;
        System.out.println("sum: " + sum);
    }
}
