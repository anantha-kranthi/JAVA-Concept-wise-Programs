// Assumption: (int) cast truncates toward zero; Math.round() rounds to nearest -- shown side by side.
public class RoundVsTruncateDemo {
    public static void main(String[] args) {
        double d = 4.9;
        System.out.println("(int) cast (truncates): " + (int) d);
        System.out.println("Math.round (rounds): " + Math.round(d));
    }
}
