// Assumption: valid input is any mixed alphanumeric string; each character checked individually.
public class CharacterUtilityDemo {
    public static void main(String[] args) {
        String input = "Hello123";
        for (char c : input.toCharArray()) {
            System.out.println(c + " digit=" + Character.isDigit(c)
                    + " letter=" + Character.isLetter(c)
                    + " upper=" + Character.toUpperCase(c));
        }
    }
}
