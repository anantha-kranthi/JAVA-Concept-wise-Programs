// Assumption: valid RGB channel values are 0-255; out-of-range values must be explicitly checked, since int alone won't stop them.
public class RgbColorBoundsDemo {
    public static void main(String[] args) {
        int red = 300;
        if (red < 0 || red > 255) {
            System.out.println("Invalid RGB value: " + red + " (must be 0-255)");
        } else {
            System.out.println("Valid RGB value: " + red);
        }
    }
}
