// Assumption: valid input is uppercase A-Z text; shift wraps safely within the alphabet using modulo 26.
public class CaesarCipherCharDemo {
    public static void main(String[] args) {
        String text = "HELLO";
        int shift = 3;
        StringBuilder encoded = new StringBuilder();
        for (char c : text.toCharArray()) {
            char shifted = (char) ('A' + (c - 'A' + shift) % 26);
            encoded.append(shifted);
        }
        System.out.println("encoded: " + encoded);
    }
}
