// Assumption: casting a long beyond int's range silently drops high-order bits, no exception.
public class LongToIntTruncationDemo {
    public static void main(String[] args) {
        long big = 10000000000L;
        int truncated = (int) big;
        System.out.println("long: " + big);
        System.out.println("as int: " + truncated);
    }
}
