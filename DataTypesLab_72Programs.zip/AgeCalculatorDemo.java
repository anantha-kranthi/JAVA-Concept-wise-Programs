// Assumption: int is the correct type for age -- byte's range (127) would technically fit but int is the safe general choice.
public class AgeCalculatorDemo {
    public static void main(String[] args) {
        int birthYear = 1995;
        int currentYear = 2026;
        int age = currentYear - birthYear;
        System.out.println("Age: " + age);
    }
}
