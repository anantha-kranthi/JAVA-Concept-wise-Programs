// Assumption: unboxing a null Integer in arithmetic throws NullPointerException, caught here.
public class UnboxingNPEDemo {
    public static void main(String[] args) {
        Integer value = null;
        try {
            int x = value + 1;
            System.out.println(x);
        } catch (NullPointerException e) {
            System.out.println("caught NPE from unboxing null Integer");
        }
    }
}
