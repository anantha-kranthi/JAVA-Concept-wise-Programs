// Assumption: valid input is any positive weight in kg; comparing int truncation vs correct double result.
public class UnitConverterDemo {
    public static void main(String[] args) {
        double kg = 70;
        double lbsCorrect = kg * 2.20462;
        int lbsWrong = (int) (kg * 2.20462);
        System.out.println("correct (double): " + lbsCorrect);
        System.out.println("wrong (int): " + lbsWrong);
    }
}
