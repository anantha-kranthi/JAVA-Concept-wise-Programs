// Assumption: int->double widens automatically in a method call; double->int needs an explicit cast.
public class WideningMethodCallDemo {
    public static void main(String[] args) {
        printDouble(5);
        // printInt(5.0); // COMPILE ERROR: possible lossy conversion from double to int
        printInt((int) 5.0);
    }
    static void printDouble(double d) { System.out.println("double: " + d); }
    static void printInt(int i) { System.out.println("int: " + i); }
}
