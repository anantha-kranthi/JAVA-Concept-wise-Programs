// Assumption: shop prices stored as Double values in a Map, tying wrapper types to a real use case.
import java.util.HashMap;
import java.util.Map;
public class ShopPriceMapDemo {
    public static void main(String[] args) {
        Map<String, Double> prices = new HashMap<>();
        prices.put("Rice", 55.5);
        prices.put("Oil", 120.0);
        for (Map.Entry<String, Double> entry : prices.entrySet()) {
            System.out.println(entry.getKey() + ": Rs " + entry.getValue());
        }
    }
}
