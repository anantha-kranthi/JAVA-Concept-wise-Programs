// Assumption: full implicit widening chain byte->short->int->long->float->double, each step automatic.
public class WideningChainDemo {
    public static void main(String[] args) {
        byte b = 10;
        short s = b;
        int i = s;
        long l = i;
        float f = l;
        double d = f;
        System.out.println("byte->short->int->long->float->double: " + d);
    }
}
