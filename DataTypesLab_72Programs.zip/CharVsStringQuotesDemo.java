// Assumption: char literals require single quotes, String literals require double quotes.
// char bad = "A"; // COMPILE ERROR: incompatible types: String cannot be converted to char
public class CharVsStringQuotesDemo {
    public static void main(String[] args) {
        char c = 'A';
        String s = "A";
        System.out.println("char: " + c + ", String: " + s);
    }
}
