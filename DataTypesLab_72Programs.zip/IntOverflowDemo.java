// Assumption: overflow wraps silently (no exception) -- demonstrating that behaviour.
public class IntOverflowDemo {
    public static void main(String[] args) {
        int max = Integer.MAX_VALUE;
        System.out.println("MAX_VALUE = " + max);
        System.out.println("MAX_VALUE + 1 = " + (max + 1));
    }
}
