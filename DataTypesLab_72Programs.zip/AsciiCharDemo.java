// Assumption: valid range is 0-127 (standard ASCII), printed as int->char pairs.
public class AsciiCharDemo {
    public static void main(String[] args) {
        for (int i = 0; i < 128; i++) {
            System.out.println(i + " -> " + (char) i);
        }
    }
}
