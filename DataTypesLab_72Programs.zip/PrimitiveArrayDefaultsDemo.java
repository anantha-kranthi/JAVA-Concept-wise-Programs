// Assumption: freshly created primitive arrays are auto-filled with each type's default value.
import java.util.Arrays;
public class PrimitiveArrayDefaultsDemo {
    public static void main(String[] args) {
        int[] ints = new int[3];
        double[] doubles = new double[3];
        boolean[] bools = new boolean[3];
        char[] chars = new char[3];
        System.out.println("int[]: " + Arrays.toString(ints));
        System.out.println("double[]: " + Arrays.toString(doubles));
        System.out.println("boolean[]: " + Arrays.toString(bools));
        System.out.println("char[] codes: " + (int) chars[0] + "," + (int) chars[1] + "," + (int) chars[2]);
    }
}
