// Assumption: valid Java syntax, but readability drops once more than 2-3 variables share one line.
public class MultipleDeclarationDemo {
    public static void main(String[] args) {
        int a = 1, b = 2, c = 3;
        System.out.println(a + " " + b + " " + c);
    }
}
