// Assumption: default char '\u0000' is distinct from the visible space character ' '.
public class NullCharVsSpace {
    char defChar;
    public static void main(String[] args) {
        NullCharVsSpace o = new NullCharVsSpace();
        char space = ' ';
        System.out.println("default char code: " + (int) o.defChar);
        System.out.println("space char code: " + (int) space);
        System.out.println("equal? " + (o.defChar == space));
    }
}
