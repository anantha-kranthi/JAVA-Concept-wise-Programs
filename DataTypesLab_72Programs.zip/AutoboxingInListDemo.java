// Assumption: List<Integer> only accepts objects, so adding int literals triggers autoboxing.
import java.util.ArrayList;
import java.util.List;
import java.util.Collections;
public class AutoboxingInListDemo {
    public static void main(String[] args) {
        List<Integer> list = new ArrayList<>();
        list.add(3); list.add(1); list.add(2);
        Collections.sort(list);
        System.out.println(list);
    }
}
