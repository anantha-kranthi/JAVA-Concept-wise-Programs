// Assumption: two floats that are "mathematically equal" may still fail direct == due to fp representation.
public class TemperatureLoggerEqualityDemo {
    public static void main(String[] args) {
        float reading1 = 36.6f;
        float reading2 = 36.1f + 0.5f;
        System.out.println("reading1: " + reading1);
        System.out.println("reading2: " + reading2);
        System.out.println("equal? " + (reading1 == reading2));
    }
}
