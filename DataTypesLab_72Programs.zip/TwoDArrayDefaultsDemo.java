// Assumption: a fixed 2x2 int grid is enough to demonstrate default-filled 2D arrays.
public class TwoDArrayDefaultsDemo {
    public static void main(String[] args) {
        int[][] grid = new int[2][2];
        for (int[] row : grid) {
            for (int val : row) System.out.print(val + " ");
            System.out.println();
        }
    }
}
