// Assumption: full explicit narrowing chain double->float->long->int->short->byte, each step needs a cast.
public class NarrowingChainDemo {
    public static void main(String[] args) {
        double d = 1234.5678;
        float f = (float) d;
        long l = (long) f;
        int i = (int) l;
        short s = (short) i;
        byte b = (byte) s;
        System.out.println("double=" + d + " -> float=" + f + " -> long=" + l
                + " -> int=" + i + " -> short=" + s + " -> byte=" + b);
    }
}
