// Assumption: boolean cannot be cast to/from numeric types in Java (unlike C).
// Failing code shown only as a comment since it would not compile:
//   boolean flag = true;
//   int x = (int) flag; // COMPILE ERROR: incompatible types
public class BooleanCastDemo {
    public static void main(String[] args) {
        boolean flag = true;
        System.out.println("boolean value: " + flag);
        System.out.println("Java has no boolean<->numeric cast.");
    }
}
