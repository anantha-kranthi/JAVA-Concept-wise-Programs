// Assumption: Object[] backed by an Integer[] compiles for any Object assignment but fails at runtime.
public class ArrayStoreExceptionDemo {
    public static void main(String[] args) {
        Object[] arr = new Integer[3];
        arr[0] = 10;
        try {
            arr[1] = "hello";
        } catch (ArrayStoreException e) {
            System.out.println("caught: " + e.getMessage());
        }
    }
}
