// Assumption: (char)(int)x and (int)(char)x differ because the char cast truncates to 16 bits first.
public class CastOrderDemo {
    public static void main(String[] args) {
        int x = 321;
        System.out.println("(char)(int) x -> code " + (int) (char) x);
        char c = 'A';
        System.out.println("(int)(char) c -> " + (int) c);
    }
}
