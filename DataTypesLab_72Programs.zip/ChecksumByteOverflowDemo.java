// Assumption: byte wraparound is used here intentionally as part of the checksum algorithm, not treated as a bug.
public class ChecksumByteOverflowDemo {
    public static void main(String[] args) {
        byte checksum = 0;
        String data = "HELLO";
        for (char c : data.toCharArray()) {
            checksum += (byte) c;
        }
        System.out.println("checksum: " + checksum);
    }
}
