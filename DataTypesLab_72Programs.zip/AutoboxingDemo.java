// Assumption: assigning an int literal directly to an Integer variable triggers implicit autoboxing.
public class AutoboxingDemo {
    public static void main(String[] args) {
        Integer boxed = 10;
        System.out.println("boxed: " + boxed);
    }
}
