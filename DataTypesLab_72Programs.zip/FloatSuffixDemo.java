// Assumption: 'f' suffix is mandatory for float literals; failing code shown only as a comment.
// float bad = 3.14; // COMPILE ERROR: incompatible types: possible lossy conversion from double to float
public class FloatSuffixDemo {
    public static void main(String[] args) {
        float f = 3.14f;
        System.out.println("float value: " + f);
    }
}
