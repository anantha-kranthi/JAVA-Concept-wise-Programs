// Assumption: storing money as double risks rounding artifacts; storing as integer paise avoids them.
public class BankBalanceTrackerDemo {
    public static void main(String[] args) {
        double balance = 100.10;
        balance += 0.20;
        System.out.println("double balance: " + balance);

        long paise = 10010;
        paise += 20;
        System.out.println("paise (safe): " + paise + " = Rs " + (paise / 100.0));
    }
}
