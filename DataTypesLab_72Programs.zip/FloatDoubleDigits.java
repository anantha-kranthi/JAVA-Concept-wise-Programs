// Assumption: using a repeating-digit literal to visually expose where each type's precision runs out.
public class FloatDoubleDigits {
    public static void main(String[] args) {
        float f = 1.234567891234f;
        double d = 1.234567891234;
        System.out.println("float  (~7 digits reliable): " + f);
        System.out.println("double (~15 digits reliable): " + d);
    }
}
