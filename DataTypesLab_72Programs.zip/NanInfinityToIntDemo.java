// Assumption: (int) NaN -> 0, (int) Infinity -> Integer.MAX_VALUE, per JLS narrowing conversion rules.
public class NanInfinityToIntDemo {
    public static void main(String[] args) {
        double nan = 0.0 / 0.0;
        double inf = 1.0 / 0.0;
        System.out.println("(int) NaN = " + (int) nan);
        System.out.println("(int) Infinity = " + (int) inf);
    }
}
