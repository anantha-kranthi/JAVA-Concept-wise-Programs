// Assumption: casting int 500 to byte wraps using modulo-256 signed arithmetic.
public class ByteWraparoundDemo {
    public static void main(String[] args) {
        int big = 500;
        byte b = (byte) big;
        System.out.println("500 as byte = " + b);
    }
}
