// Assumption: an unmatched value should print a friendly message via default, not crash or produce no output at all.
public class SwitchUnmatchedCaseDemo {
    public static void main(String[] args) {
        int option = 15;
        switch (option) {
            case 1: System.out.println("Option 1 selected"); break;
            case 2: System.out.println("Option 2 selected"); break;
            default: System.out.println("Option " + option + " is not recognised.");
        }
    }
}
