// Assumption: the while(true) loop has no natural end; a runtime condition inside decides when to stop it.
public class InfiniteLoopInternalBreakDemo {
    public static void main(String[] args) {
        int total = 0;
        int value = 1;
        while (true) {
            total += value;
            if (total > 50) {
                System.out.println("Stopping: total exceeded 50 (total=" + total + ")");
                break;
            }
            value++;
        }
    }
}
