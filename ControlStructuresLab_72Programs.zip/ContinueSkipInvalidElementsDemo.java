// Assumption: negative numbers in the array are treated as invalid and skipped rather than included in the sum.
public class ContinueSkipInvalidElementsDemo {
    public static void main(String[] args) {
        int[] values = {10, -5, 20, -1, 30};
        int sum = 0;
        for (int v : values) {
            if (v < 0) {
                continue;
            }
            sum += v;
        }
        System.out.println("Sum of valid (non-negative) values: " + sum);
    }
}
