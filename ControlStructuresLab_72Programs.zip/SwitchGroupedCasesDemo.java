// Assumption: multiple case labels sharing identical logic are grouped together instead of being repeated.
public class SwitchGroupedCasesDemo {
    public static void main(String[] args) {
        int month = 4;
        switch (month) {
            case 12: case 1: case 2:
                System.out.println("Winter"); break;
            case 3: case 4: case 5:
                System.out.println("Spring"); break;
            case 6: case 7: case 8:
                System.out.println("Summer"); break;
            default:
                System.out.println("Autumn");
        }
    }
}
