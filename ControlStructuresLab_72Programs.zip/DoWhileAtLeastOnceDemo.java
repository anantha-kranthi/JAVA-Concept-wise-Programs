// Assumption: even though the condition is false from the start, the do-while body still runs exactly once.
public class DoWhileAtLeastOnceDemo {
    public static void main(String[] args) {
        int x = 10;
        do {
            System.out.println("This runs at least once, x = " + x);
        } while (x < 5); // condition is false immediately, but body already ran
    }
}
