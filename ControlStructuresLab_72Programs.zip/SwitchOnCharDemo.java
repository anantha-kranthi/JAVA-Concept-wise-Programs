// Assumption: valid input is a single vowel/consonant char; switch matches char literals directly.
public class SwitchOnCharDemo {
    public static void main(String[] args) {
        char grade = 'B';
        switch (grade) {
            case 'A': System.out.println("Excellent"); break;
            case 'B': System.out.println("Good"); break;
            case 'C': System.out.println("Average"); break;
            default: System.out.println("Needs improvement");
        }
    }
}
