// Assumption: even numbers are skipped entirely (not printed), while odd numbers print normally.
public class ContinueStatementDemo {
    public static void main(String[] args) {
        for (int i = 1; i <= 10; i++) {
            if (i % 2 == 0) {
                continue;
            }
            System.out.println(i);
        }
    }
}
