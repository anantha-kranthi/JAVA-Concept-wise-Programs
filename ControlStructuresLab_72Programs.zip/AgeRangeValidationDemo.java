// Assumption: a realistic human age is treated as 0 to 120 inclusive; anything outside that is flagged invalid.
public class AgeRangeValidationDemo {
    public static void main(String[] args) {
        int age = 130;
        if (age >= 0 && age <= 120) {
            System.out.println("Valid age: " + age);
        } else {
            System.out.println("Invalid age: " + age);
        }
    }
}
