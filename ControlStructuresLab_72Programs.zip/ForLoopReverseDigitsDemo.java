// Assumption: valid input is a non-negative integer; a for loop peels off digits from the end and rebuilds them reversed.
public class ForLoopReverseDigitsDemo {
    public static void main(String[] args) {
        int number = 12345;
        int reversed = 0;
        for (int n = number; n > 0; n /= 10) {
            reversed = reversed * 10 + (n % 10);
        }
        System.out.println("Reversed: " + reversed);
    }
}
