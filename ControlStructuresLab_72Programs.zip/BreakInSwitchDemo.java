// Assumption: break here specifically prevents switch fall-through, distinct from break's role in loops.
public class BreakInSwitchDemo {
    public static void main(String[] args) {
        int day = 2;
        switch (day) {
            case 1:
                System.out.println("Monday");
                break;
            case 2:
                System.out.println("Tuesday");
                break; // without this, execution would fall into case 3
            case 3:
                System.out.println("Wednesday");
                break;
        }
    }
}
