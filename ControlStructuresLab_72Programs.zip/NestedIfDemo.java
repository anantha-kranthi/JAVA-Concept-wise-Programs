// Assumption: outer condition gates whether the inner condition is even checked (two-level decision).
public class NestedIfDemo {
    public static void main(String[] args) {
        int age = 25;
        boolean hasLicense = true;
        if (age >= 18) {
            if (hasLicense) {
                System.out.println("Allowed to drive.");
            } else {
                System.out.println("Old enough, but needs a license.");
            }
        } else {
            System.out.println("Too young to drive.");
        }
    }
}
