// Assumption: String matching in switch is case-sensitive, since Java's switch uses String.equals() internally.
public class SwitchOnStringDemo {
    public static void main(String[] args) {
        String fruit = "Mango";
        switch (fruit) {
            case "Apple": System.out.println("Red fruit"); break;
            case "Mango": System.out.println("King of fruits"); break;
            case "Banana": System.out.println("Yellow fruit"); break;
            default: System.out.println("Unknown fruit");
        }
    }
}
