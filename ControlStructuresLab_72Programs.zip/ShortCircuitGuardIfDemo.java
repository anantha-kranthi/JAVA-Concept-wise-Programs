// Assumption: short-circuit && is used deliberately so the division is only attempted when the divisor is nonzero.
public class ShortCircuitGuardIfDemo {
    public static void main(String[] args) {
        int a = 10, b = 0;
        if (b != 0 && (a / b) > 2) {
            System.out.println("Result is greater than 2.");
        } else {
            System.out.println("Skipped safely -- division by zero avoided.");
        }
    }
}
