// Assumption: countdown runs from N down to 1 inclusive, then a separate "liftoff" message prints after the loop.
public class ForLoopCountdownDemo {
    public static void main(String[] args) {
        int n = 5;
        for (int i = n; i >= 1; i--) {
            System.out.println(i);
        }
        System.out.println("Liftoff!");
    }
}
