// Assumption: same false initial condition is used for both loops to make the difference in behaviour visible.
public class WhileVsDoWhileDemo {
    public static void main(String[] args) {
        int a = 10;
        System.out.println("while loop:");
        while (a < 5) {
            System.out.println("this never prints");
        }

        int b = 10;
        System.out.println("do-while loop:");
        do {
            System.out.println("this prints once, even though condition is false");
        } while (b < 5);
    }
}
