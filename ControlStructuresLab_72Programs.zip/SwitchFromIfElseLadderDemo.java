// Assumption: same grading logic as the if-else ladder version, rewritten with switch on marks/10 to show the conversion.
public class SwitchFromIfElseLadderDemo {
    public static void main(String[] args) {
        int marks = 82;
        int band = marks / 10;
        switch (band) {
            case 10: case 9: System.out.println("Grade: A"); break;
            case 8: case 7: System.out.println("Grade: B"); break;
            case 6: case 5: System.out.println("Grade: C"); break;
            default: System.out.println("Grade: F");
        }
    }
}
