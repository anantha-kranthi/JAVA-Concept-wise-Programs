// Assumption: the loop's only job (finding the first power of 2 >= 100) is done entirely in the update expression.
public class ForLoopEmptyBodyDemo {
    public static void main(String[] args) {
        int power;
        for (power = 1; power < 100; power *= 2)
            ; // empty body -- all the work happens in the update clause
        System.out.println("First power of 2 >= 100: " + power);
    }
}
