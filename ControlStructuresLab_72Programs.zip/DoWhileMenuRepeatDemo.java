// Assumption: menu repeats until the user selects the exit option (0); a fixed sequence of choices simulates user input.
public class DoWhileMenuRepeatDemo {
    public static void main(String[] args) {
        int[] simulatedChoices = {1, 2, 0}; // simulated user picks, ending with exit
        int index = 0;
        int choice;
        do {
            choice = simulatedChoices[index++];
            switch (choice) {
                case 1: System.out.println("Showing balance..."); break;
                case 2: System.out.println("Showing transactions..."); break;
                case 0: System.out.println("Exiting menu."); break;
                default: System.out.println("Invalid choice.");
            }
        } while (choice != 0);
    }
}
