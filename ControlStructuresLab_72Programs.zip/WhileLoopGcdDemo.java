// Assumption: Euclidean algorithm implemented with a while loop; inputs are assumed positive integers.
public class WhileLoopGcdDemo {
    public static void main(String[] args) {
        int a = 48, b = 18;
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        System.out.println("GCD: " + a);
    }
}
