// Assumption: modern arrow-syntax switch expression directly returns a value, no break statements needed.
public class SwitchExpressionArrowDemo {
    public static void main(String[] args) {
        int day = 6;
        String type = switch (day) {
            case 6, 7 -> "Weekend";
            default -> "Weekday";
        };
        System.out.println("Day type: " + type);
    }
}
