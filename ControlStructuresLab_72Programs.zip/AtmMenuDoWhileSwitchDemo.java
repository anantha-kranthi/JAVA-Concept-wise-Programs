// Assumption: fixed simulated choices replace live input; menu repeats until "5" (exit) is chosen.
public class AtmMenuDoWhileSwitchDemo {
    public static void main(String[] args) {
        int[] simulatedChoices = {1, 3, 5};
        int index = 0;
        int choice;
        do {
            choice = simulatedChoices[index++];
            switch (choice) {
                case 1: System.out.println("Balance: Rs 10,000"); break;
                case 2: System.out.println("Deposit successful"); break;
                case 3: System.out.println("Withdrawal successful"); break;
                case 4: System.out.println("Mini statement printed"); break;
                case 5: System.out.println("Thank you for banking with us."); break;
                default: System.out.println("Invalid option");
            }
        } while (choice != 5);
    }
}
