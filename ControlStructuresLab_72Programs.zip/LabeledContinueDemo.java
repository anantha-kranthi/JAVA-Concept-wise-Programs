// Assumption: labeled continue skips the REST of the outer loop's current iteration, not just the inner loop's.
public class LabeledContinueDemo {
    public static void main(String[] args) {
        outer:
        for (int i = 1; i <= 3; i++) {
            for (int j = 1; j <= 3; j++) {
                if (j == 2) {
                    continue outer; // skips straight to the next value of i
                }
                System.out.println("i=" + i + ", j=" + j);
            }
        }
    }
}
