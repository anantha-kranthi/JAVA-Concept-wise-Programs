// Assumption: both conditions must be true simultaneously (combined with &&) for the message to print.
public class IfWithLogicalAndDemo {
    public static void main(String[] args) {
        int marks = 85;
        boolean attendanceOk = true;
        if (marks >= 40 && attendanceOk) {
            System.out.println("Eligible to be promoted to the next semester.");
        } else {
            System.out.println("Not eligible for promotion.");
        }
    }
}
