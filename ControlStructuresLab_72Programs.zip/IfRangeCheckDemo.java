// Assumption: valid range is inclusive on both ends (10 to 20); values exactly at the boundary count as valid.
public class IfRangeCheckDemo {
    public static void main(String[] args) {
        int value = 15;
        if (value >= 10 && value <= 20) {
            System.out.println(value + " is within the range 10-20.");
        } else {
            System.out.println(value + " is outside the range 10-20.");
        }
    }
}
