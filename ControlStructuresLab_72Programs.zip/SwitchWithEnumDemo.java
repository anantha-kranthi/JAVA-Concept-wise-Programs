// Assumption: switch on an enum value does not need the enum's class prefix in case labels.
public class SwitchWithEnumDemo {
    enum Day { MON, TUE, WED, THU, FRI, SAT, SUN }
    public static void main(String[] args) {
        Day today = Day.SAT;
        switch (today) {
            case SAT: case SUN: System.out.println("Weekend"); break;
            default: System.out.println("Weekday");
        }
    }
}
