// Assumption: an inverted right-angled triangle pattern, 5 rows tall, decreasing star count per row.
public class PatternPrintingNestedForDemo {
    public static void main(String[] args) {
        int rows = 5;
        for (int i = rows; i >= 1; i--) {
            for (int j = 1; j <= i; j++) {
                System.out.print("* ");
            }
            System.out.println();
        }
    }
}
