// Assumption: zero is treated as its own distinct category, not grouped with positive or negative.
public class PositiveNegativeZeroDemo {
    public static void main(String[] args) {
        int number = -8;
        if (number > 0) {
            System.out.println(number + " is Positive");
        } else if (number < 0) {
            System.out.println(number + " is Negative");
        } else {
            System.out.println(number + " is Zero");
        }
    }
}
