// Assumption: 3 subjects per student, fixed sample data; grade band chosen via switch, remark chosen via if-else.
public class StudentGradeReportDemo {
    public static void main(String[] args) {
        String[] subjects = {"Maths", "Science", "English"};
        int[] marks = {88, 45, 72};

        for (int i = 0; i < subjects.length; i++) {
            int m = marks[i];
            char grade;
            switch (m / 10) {
                case 10: case 9: grade = 'A'; break;
                case 8: case 7: grade = 'B'; break;
                case 6: case 5: grade = 'C'; break;
                default: grade = 'F';
            }

            String remark;
            if (grade == 'A') {
                remark = "Excellent";
            } else if (grade == 'B' || grade == 'C') {
                remark = "Satisfactory";
            } else {
                remark = "Needs Improvement";
            }

            System.out.println(subjects[i] + ": " + m + " marks, Grade " + grade + " (" + remark + ")");
        }
    }
}
