// Assumption: a right-angled triangle pattern of '*' characters, 5 rows tall, row i has i stars.
public class NestedForPatternDemo {
    public static void main(String[] args) {
        int rows = 5;
        for (int i = 1; i <= rows; i++) {
            for (int j = 1; j <= i; j++) {
                System.out.print("* ");
            }
            System.out.println();
        }
    }
}
