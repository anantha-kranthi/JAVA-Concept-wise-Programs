// Assumption: a case needing more than one statement in a switch expression uses a block with yield to return its value.
public class SwitchYieldDemo {
    public static void main(String[] args) {
        int score = 75;
        String result = switch (score / 10) {
            case 10, 9, 8 -> "Pass with Distinction";
            case 7, 6, 5 -> {
                String msg = "Pass";
                yield msg;
            }
            default -> "Fail";
        };
        System.out.println(result);
    }
}
