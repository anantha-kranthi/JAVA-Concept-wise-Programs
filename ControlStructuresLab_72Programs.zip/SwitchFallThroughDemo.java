// Assumption: missing break statements are shown deliberately to demonstrate fall-through, not as a bug.
public class SwitchFallThroughDemo {
    public static void main(String[] args) {
        int n = 2;
        switch (n) {
            case 1: System.out.println("one");
            case 2: System.out.println("two"); // falls through from here
            case 3: System.out.println("three"); // ...and here, since no break stops it
                break;
            case 4: System.out.println("four");
        }
    }
}
