// Assumption: countdown starts at a fixed value and ends at 0 inclusive, then prints a completion message.
public class WhileLoopCountdownTimerDemo {
    public static void main(String[] args) {
        int seconds = 5;
        while (seconds >= 0) {
            System.out.println(seconds);
            seconds--;
        }
        System.out.println("Time's up!");
    }
}
