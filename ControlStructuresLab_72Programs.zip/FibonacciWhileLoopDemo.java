// Assumption: series starts at 0, 1 and generates a fixed count of 10 terms.
public class FibonacciWhileLoopDemo {
    public static void main(String[] args) {
        int count = 10;
        long a = 0, b = 1;
        int printed = 0;
        while (printed < count) {
            System.out.print(a + " ");
            long next = a + b;
            a = b;
            b = next;
            printed++;
        }
        System.out.println();
    }
}
