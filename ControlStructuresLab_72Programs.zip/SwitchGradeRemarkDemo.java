// Assumption: valid grade letters are A-F; anything else is reported as an unrecognised grade.
public class SwitchGradeRemarkDemo {
    public static void main(String[] args) {
        char grade = 'C';
        switch (grade) {
            case 'A': System.out.println("Outstanding"); break;
            case 'B': System.out.println("Very Good"); break;
            case 'C': System.out.println("Satisfactory"); break;
            case 'D': System.out.println("Needs Improvement"); break;
            case 'F': System.out.println("Failed"); break;
            default: System.out.println("Unrecognised grade");
        }
    }
}
