// Assumption: without braces, the else binds to the NEAREST unmatched if, which may not be the intended one.
public class DanglingElseDemo {
    public static void main(String[] args) {
        int a = 5;
        // Dangling-else pitfall: the else below binds to "if (a > 10)", not the outer condition.
        if (a > 0)
            if (a > 10)
                System.out.println("a is greater than 10");
            else
                System.out.println("a is positive but not greater than 10"); // this prints, correctly, for a=5

        // Correct, unambiguous version using braces:
        if (a > 0) {
            if (a > 10) {
                System.out.println("a is greater than 10 (braced)");
            }
        } else {
            System.out.println("a is not positive (braced)");
        }
    }
}
