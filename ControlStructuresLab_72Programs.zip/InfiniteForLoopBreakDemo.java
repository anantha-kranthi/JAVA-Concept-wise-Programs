// Assumption: the for loop header is deliberately left with no terminating condition; break provides the only exit.
public class InfiniteForLoopBreakDemo {
    public static void main(String[] args) {
        int count = 0;
        for (;;) {
            System.out.println("iteration " + count);
            count++;
            if (count >= 5) {
                break;
            }
        }
    }
}
