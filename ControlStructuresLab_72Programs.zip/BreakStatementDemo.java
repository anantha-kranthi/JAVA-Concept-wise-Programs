// Assumption: loop exits the instant the target value is found, rather than continuing through the rest of the range.
public class BreakStatementDemo {
    public static void main(String[] args) {
        for (int i = 1; i <= 10; i++) {
            if (i == 5) {
                System.out.println("Found 5, breaking out.");
                break;
            }
            System.out.println("Checking: " + i);
        }
    }
}
