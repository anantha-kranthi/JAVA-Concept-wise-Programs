// Assumption: table is generated for numbers 1 to 5, each up to 10 -- a fixed but representative size.
public class NestedForMultiplicationTableDemo {
    public static void main(String[] args) {
        for (int i = 1; i <= 5; i++) {
            for (int j = 1; j <= 10; j++) {
                System.out.print(i * j + "\t");
            }
            System.out.println();
        }
    }
}
