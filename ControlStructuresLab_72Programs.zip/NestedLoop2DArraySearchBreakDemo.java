// Assumption: search stops immediately once the target is found anywhere in the 2D array, using a labeled break.
public class NestedLoop2DArraySearchBreakDemo {
    public static void main(String[] args) {
        int[][] grid = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
        int target = 5;
        boolean found = false;

        search:
        for (int row = 0; row < grid.length; row++) {
            for (int col = 0; col < grid[row].length; col++) {
                if (grid[row][col] == target) {
                    System.out.println("Found " + target + " at [" + row + "][" + col + "]");
                    found = true;
                    break search;
                }
            }
        }
        if (!found) {
            System.out.println(target + " not found in the grid.");
        }
    }
}
