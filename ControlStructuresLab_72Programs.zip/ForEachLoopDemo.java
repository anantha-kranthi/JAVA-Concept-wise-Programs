// Assumption: for-each is used purely for reading elements, since it doesn't expose an index to modify the array by position.
public class ForEachLoopDemo {
    public static void main(String[] args) {
        String[] fruits = {"Apple", "Banana", "Mango"};
        for (String fruit : fruits) {
            System.out.println(fruit);
        }
    }
}
