// Assumption: a boolean flag achieves the same early-exit effect as break, useful when break can't reach the right scope.
public class LoopControlWithFlagDemo {
    public static void main(String[] args) {
        boolean keepGoing = true;
        int i = 1;
        while (keepGoing) {
            System.out.println(i);
            if (i == 5) {
                keepGoing = false; // stops the loop on the next condition check, instead of using break
            }
            i++;
        }
    }
}
