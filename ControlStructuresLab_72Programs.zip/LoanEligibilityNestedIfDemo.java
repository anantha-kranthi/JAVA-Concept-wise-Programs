// Assumption: loan eligibility requires age check first, then income check nested inside -- mirroring a real approval flow.
public class LoanEligibilityNestedIfDemo {
    public static void main(String[] args) {
        int age = 30;
        double income = 25000;
        if (age >= 21 && age <= 60) {
            if (income >= 20000) {
                System.out.println("Eligible for the loan.");
            } else {
                System.out.println("Age OK, but income is too low.");
            }
        } else {
            System.out.println("Age is outside the eligible range.");
        }
    }
}
