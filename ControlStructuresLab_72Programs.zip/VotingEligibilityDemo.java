// Assumption: eligible age is 18+; loop keeps asking (simulated with a fixed retry list) until a valid, non-negative age is given.
public class VotingEligibilityDemo {
    public static void main(String[] args) {
        int[] simulatedInputs = {-5, 15, 20}; // simulated retries: invalid, underage, then valid
        int age = -1;
        for (int input : simulatedInputs) {
            if (input < 0) {
                System.out.println(input + " -> Invalid input, please try again.");
                continue;
            }
            age = input;
            if (age >= 18) {
                System.out.println(age + " -> Eligible to vote.");
                break;
            } else {
                System.out.println(age + " -> Not eligible (must retry with a higher age in this simulation).");
            }
        }
    }
}
