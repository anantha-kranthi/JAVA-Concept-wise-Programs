// Assumption: exactly one of two branches always executes -- no case is left unhandled.
public class IfElseDemo {
    public static void main(String[] args) {
        int number = 7;
        if (number % 2 == 0) {
            System.out.println(number + " is Even");
        } else {
            System.out.println(number + " is Odd");
        }
    }
}
