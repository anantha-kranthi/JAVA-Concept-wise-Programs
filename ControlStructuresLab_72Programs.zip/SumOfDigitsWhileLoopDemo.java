// Assumption: valid input is a non-negative integer; digits are extracted and summed using a while loop.
public class SumOfDigitsWhileLoopDemo {
    public static void main(String[] args) {
        int number = 4931;
        int sum = 0;
        int n = number;
        while (n > 0) {
            sum += n % 10;
            n /= 10;
        }
        System.out.println("Sum of digits: " + sum);
    }
}
