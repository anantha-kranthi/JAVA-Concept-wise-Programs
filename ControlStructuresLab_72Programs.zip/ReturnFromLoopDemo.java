// Assumption: return exits the entire method immediately once the target is found, not just the loop.
public class ReturnFromLoopDemo {
    public static void main(String[] args) {
        int[] numbers = {4, 8, 15, 16, 23, 42};
        System.out.println(findFirstOver(numbers, 10));
    }

    static int findFirstOver(int[] numbers, int threshold) {
        for (int n : numbers) {
            if (n > threshold) {
                return n; // exits the method immediately, no loop or break needed
            }
        }
        return -1;
    }
}
