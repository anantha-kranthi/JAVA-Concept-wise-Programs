// Assumption: menu options are fixed (1-4); an unrecognised choice is reported rather than silently ignored.
public class SwitchMenuDrivenDemo {
    public static void main(String[] args) {
        int choice = 2;
        switch (choice) {
            case 1: System.out.println("Add Item"); break;
            case 2: System.out.println("View Cart"); break;
            case 3: System.out.println("Checkout"); break;
            case 4: System.out.println("Exit"); break;
            default: System.out.println("Invalid menu choice");
        }
    }
}
