// Assumption: palindrome check is done on the numeric value directly (via digit reversal), not by converting to a String.
public class PalindromeCheckerForLoopDemo {
    public static void main(String[] args) {
        int number = 12321;
        int reversed = 0;
        for (int n = number; n > 0; n /= 10) {
            reversed = reversed * 10 + (n % 10);
        }
        System.out.println(number + " is palindrome: " + (number == reversed));
    }
}
