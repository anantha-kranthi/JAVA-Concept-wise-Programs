// Assumption: a simple decrementing while loop distinct from the "timer" version -- ends strictly above zero.
public class WhileLoopDecrementCountdownDemo {
    public static void main(String[] args) {
        int n = 8;
        while (n > 0) {
            System.out.println(n);
            n--;
        }
    }
}
