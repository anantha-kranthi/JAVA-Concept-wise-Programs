// Assumption: two variables (i ascending, j descending) are tracked together in one for loop header.
public class ForLoopMultipleInitUpdateDemo {
    public static void main(String[] args) {
        for (int i = 0, j = 10; i < j; i++, j--) {
            System.out.println("i=" + i + ", j=" + j);
        }
    }
}
