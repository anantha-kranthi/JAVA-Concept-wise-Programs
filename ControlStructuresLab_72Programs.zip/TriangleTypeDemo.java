// Assumption: valid input is three positive side lengths; no validity check for whether they can form a real triangle
// (e.g. the triangle inequality) since the question only asks to classify equilateral/isosceles/scalene.
public class TriangleTypeDemo {
    public static void main(String[] args) {
        int a = 5, b = 5, c = 8;
        if (a == b && b == c) {
            System.out.println("Equilateral triangle");
        } else if (a == b || b == c || a == c) {
            System.out.println("Isosceles triangle");
        } else {
            System.out.println("Scalene triangle");
        }
    }
}
