// Assumption: the if-else being replaced has a single simple value per branch, which is what makes ternary suitable here.
public class TernaryReplacingIfElseDemo {
    public static void main(String[] args) {
        int a = 10, b = 20;

        String ifElseResult;
        if (a > b) {
            ifElseResult = "a is greater";
        } else {
            ifElseResult = "b is greater or equal";
        }
        System.out.println("if-else: " + ifElseResult);

        String ternaryResult = (a > b) ? "a is greater" : "b is greater or equal";
        System.out.println("ternary: " + ternaryResult);
    }
}
