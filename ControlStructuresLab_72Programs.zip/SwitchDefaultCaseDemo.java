// Assumption: default acts as the catch-all for any value not explicitly listed, similar to else in if-else.
public class SwitchDefaultCaseDemo {
    public static void main(String[] args) {
        int code = 99;
        switch (code) {
            case 1: System.out.println("Low"); break;
            case 2: System.out.println("Medium"); break;
            default: System.out.println("Unknown code: " + code);
        }
    }
}
