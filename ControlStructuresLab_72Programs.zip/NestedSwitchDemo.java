// Assumption: an inner switch is only reached once the outer switch selects a matching outer case.
public class NestedSwitchDemo {
    public static void main(String[] args) {
        int department = 1, level = 2;
        switch (department) {
            case 1:
                switch (level) {
                    case 1: System.out.println("CSE - Junior"); break;
                    case 2: System.out.println("CSE - Senior"); break;
                    default: System.out.println("CSE - Unknown level");
                }
                break;
            default:
                System.out.println("Unknown department");
        }
    }
}
