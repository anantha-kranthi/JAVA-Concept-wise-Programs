// Assumption: a fixed secret number and a fixed sequence of simulated guesses replace live user input for reproducibility.
public class NumberGuessingGameDemo {
    public static void main(String[] args) {
        int secret = 42;
        int[] guesses = {20, 60, 45, 42};
        for (int guess : guesses) {
            if (guess < secret) {
                System.out.println(guess + " -> Too low");
            } else if (guess > secret) {
                System.out.println(guess + " -> Too high");
            } else {
                System.out.println(guess + " -> Correct!");
                break;
            }
        }
    }
}
