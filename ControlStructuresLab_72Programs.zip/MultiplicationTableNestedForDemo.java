// Assumption: single number's table (up to 10) requested here, distinct from the earlier full 1-5 grid version.
public class MultiplicationTableNestedForDemo {
    public static void main(String[] args) {
        int number = 7;
        for (int i = 1; i <= 10; i++) {
            System.out.println(number + " x " + i + " = " + (number * i));
        }
    }
}
