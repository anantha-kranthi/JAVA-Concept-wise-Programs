// Assumption: custom step is 3; loop prints multiples of the step from 0 up to a fixed limit.
public class ForLoopCustomStepDemo {
    public static void main(String[] args) {
        for (int i = 0; i <= 30; i += 3) {
            System.out.println(i);
        }
    }
}
