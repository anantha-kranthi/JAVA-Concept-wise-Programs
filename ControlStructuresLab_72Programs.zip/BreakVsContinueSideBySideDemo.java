// Assumption: same loop and same trigger value (5) used for both, isolating exactly how break and continue differ.
public class BreakVsContinueSideBySideDemo {
    public static void main(String[] args) {
        System.out.println("Using break:");
        for (int i = 1; i <= 8; i++) {
            if (i == 5) break;
            System.out.println(i);
        }

        System.out.println("Using continue:");
        for (int i = 1; i <= 8; i++) {
            if (i == 5) continue;
            System.out.println(i);
        }
    }
}
