// Assumption: continue skips multiples of 3, while break stops the loop entirely once a value exceeds 20.
public class BreakAndContinueTogetherDemo {
    public static void main(String[] args) {
        for (int i = 1; i <= 30; i++) {
            if (i % 3 == 0) {
                continue;
            }
            if (i > 20) {
                break;
            }
            System.out.println(i);
        }
    }
}
