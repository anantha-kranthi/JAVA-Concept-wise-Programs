// Assumption: N is fixed at 10 for demonstration; loop prints 1 through N inclusive.
public class ForLoopPrint1ToNDemo {
    public static void main(String[] args) {
        int n = 10;
        for (int i = 1; i <= n; i++) {
            System.out.println(i);
        }
    }
}
