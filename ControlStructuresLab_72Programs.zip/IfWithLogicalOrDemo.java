// Assumption: either condition being true (combined with ||) is enough for the message to print.
public class IfWithLogicalOrDemo {
    public static void main(String[] args) {
        boolean isWeekend = false;
        boolean isHoliday = true;
        if (isWeekend || isHoliday) {
            System.out.println("No work today.");
        } else {
            System.out.println("It's a working day.");
        }
    }
}
