// Assumption: a boolean variable is tested directly (if (flag)), not compared explicitly to true/false.
public class IfBooleanDirectDemo {
    public static void main(String[] args) {
        boolean isLoggedIn = true;
        if (isLoggedIn) {
            System.out.println("Welcome back!");
        } else {
            System.out.println("Please log in.");
        }
    }
}
