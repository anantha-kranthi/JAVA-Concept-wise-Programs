// Assumption: 0! is defined as 1; negative input is treated as invalid and reported rather than computed.
public class ForLoopFactorialDemo {
    public static void main(String[] args) {
        int n = 5;
        if (n < 0) {
            System.out.println("Factorial undefined for negative numbers.");
            return;
        }
        long factorial = 1;
        for (int i = 2; i <= n; i++) {
            factorial *= i;
        }
        System.out.println(n + "! = " + factorial);
    }
}
