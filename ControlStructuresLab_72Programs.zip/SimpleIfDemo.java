// Assumption: a single condition (age >= 18) is checked; no output at all if false, per plain "if" semantics.
public class SimpleIfDemo {
    public static void main(String[] args) {
        int age = 20;
        if (age >= 18) {
            System.out.println("You are eligible to vote.");
        }
    }
}
