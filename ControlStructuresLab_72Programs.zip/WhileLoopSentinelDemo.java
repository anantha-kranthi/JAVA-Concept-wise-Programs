// Assumption: -1 is the sentinel value signalling the user wants to stop entering numbers.
import java.util.Scanner;
public class WhileLoopSentinelDemo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int sum = 0;
        System.out.println("Enter numbers (-1 to stop):");
        int num = sc.nextInt();
        while (num != -1) {
            sum += num;
            num = sc.nextInt();
        }
        System.out.println("Sum: " + sum);
    }
}
