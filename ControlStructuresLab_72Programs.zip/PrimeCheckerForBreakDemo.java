// Assumption: numbers less than 2 are not prime; the loop breaks as soon as a factor is found, for efficiency.
public class PrimeCheckerForBreakDemo {
    public static void main(String[] args) {
        int n = 29;
        boolean isPrime = n >= 2;
        for (int i = 2; i * i <= n; i++) {
            if (n % i == 0) {
                isPrime = false;
                break;
            }
        }
        System.out.println(n + " is prime: " + isPrime);
    }
}
