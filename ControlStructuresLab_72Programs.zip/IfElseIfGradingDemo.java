// Assumption: marks out of 100; grade boundaries are >=90 A, >=75 B, >=50 C, else F. Marks outside 0-100 fall through to F.
public class IfElseIfGradingDemo {
    public static void main(String[] args) {
        int marks = 82;
        if (marks >= 90) {
            System.out.println("Grade: A");
        } else if (marks >= 75) {
            System.out.println("Grade: B");
        } else if (marks >= 50) {
            System.out.println("Grade: C");
        } else {
            System.out.println("Grade: F");
        }
    }
}
