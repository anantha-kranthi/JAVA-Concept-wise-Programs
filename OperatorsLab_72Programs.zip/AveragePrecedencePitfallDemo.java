// Assumption: without parentheses, / binds before +, giving a wrong average -- classic beginner mistake.
public class AveragePrecedencePitfallDemo {
    public static void main(String[] args) {
        int a = 10, b = 20, c = 30;
        double wrong = a + b + c / 3;
        double right = (a + b + c) / 3.0;
        System.out.println("wrong: " + wrong);
        System.out.println("right: " + right);
    }
}
