// Assumption: Java does not support chained relational expressions like a < b < c (compile error), shown as a comment.
// boolean bad = (1 < 2 < 3); // COMPILE ERROR: bad operand types for binary operator '<'
public class ChainedRelationalPitfallDemo {
    public static void main(String[] args) {
        int a = 1, b = 2, c = 3;
        boolean correct = (a < b) && (b < c);
        System.out.println("a < b < c (correct form): " + correct);
    }
}
