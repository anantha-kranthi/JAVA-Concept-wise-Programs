// Assumption: unary + is a no-op but valid; unary - negates the operand.
public class UnaryPlusMinusDemo {
    public static void main(String[] args) {
        int a = 5;
        System.out.println("+a = " + (+a));
        System.out.println("-a = " + (-a));
    }
}
