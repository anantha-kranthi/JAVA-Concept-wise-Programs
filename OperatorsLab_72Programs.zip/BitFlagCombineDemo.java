// Assumption: multiple boolean flags can be packed into one int using distinct bit positions, combined with |.
public class BitFlagCombineDemo {
    static final int READ = 1, WRITE = 2, EXECUTE = 4;
    public static void main(String[] args) {
        int permissions = READ | WRITE;
        System.out.println("has READ: " + ((permissions & READ) != 0));
        System.out.println("has WRITE: " + ((permissions & WRITE) != 0));
        System.out.println("has EXECUTE: " + ((permissions & EXECUTE) != 0));
    }
}
