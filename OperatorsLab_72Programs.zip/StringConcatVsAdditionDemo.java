// Assumption: + is overloaded for String concatenation; evaluation order changes the result.
public class StringConcatVsAdditionDemo {
    public static void main(String[] args) {
        System.out.println("5" + 3);
        System.out.println(5 + 3 + "");
        System.out.println("" + 5 + 3);
    }
}
