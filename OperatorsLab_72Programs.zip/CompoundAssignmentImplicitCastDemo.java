// Assumption: compound assignment includes an implicit narrowing cast that plain arithmetic does not.
public class CompoundAssignmentImplicitCastDemo {
    public static void main(String[] args) {
        byte b = 10;
        b += 5; // equivalent to b = (byte)(b + 5)
        System.out.println("b += 5 -> " + b);
        // b = b + 5; // COMPILE ERROR: possible lossy conversion from int to byte
    }
}
