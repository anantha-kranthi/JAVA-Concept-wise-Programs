// Assumption: complex boolean expressions evaluate strictly left to right, respecting precedence and short-circuiting.
public class BooleanExpressionOrderDemo {
    public static void main(String[] args) {
        int a = 5, b = 10, c = 15;
        boolean result = a < b && b < c || a > c;
        System.out.println("a<b && b<c || a>c = " + result);
    }
}
