// Assumption: for a single simple condition, ternary is more compact; multi-statement branches read better as if-else.
public class TernaryVsIfElseReadabilityDemo {
    public static void main(String[] args) {
        int age = 20;

        String ternaryResult = (age >= 18) ? "Adult" : "Minor";
        System.out.println("ternary: " + ternaryResult);

        String ifElseResult;
        if (age >= 18) {
            ifElseResult = "Adult";
        } else {
            ifElseResult = "Minor";
        }
        System.out.println("if-else: " + ifElseResult);
        // Preferred: ternary here -- each branch is a single simple value with no extra logic.
    }
}
