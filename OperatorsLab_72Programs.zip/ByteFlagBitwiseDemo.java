// Assumption: bitwise operators work the same on byte as on int, after Java's automatic promotion to int.
public class ByteFlagBitwiseDemo {
    public static void main(String[] args) {
        byte flags = 0b0000_0101;
        System.out.println("bit 0 set: " + ((flags & 1) != 0));
        System.out.println("bit 1 set: " + ((flags & 2) != 0));
        System.out.println("bit 2 set: " + ((flags & 4) != 0));
    }
}
