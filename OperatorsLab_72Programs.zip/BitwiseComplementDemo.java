// Assumption: ~ flips every bit; for signed ints this equals -(n+1).
public class BitwiseComplementDemo {
    public static void main(String[] args) {
        int a = 5;
        System.out.println("~5 = " + (~a));
    }
}
