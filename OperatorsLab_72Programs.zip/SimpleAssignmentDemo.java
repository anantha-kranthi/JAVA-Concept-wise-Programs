// Assumption: = simply stores the right-hand value into the left-hand variable.
public class SimpleAssignmentDemo {
    public static void main(String[] args) {
        int a;
        a = 10;
        System.out.println("a = " + a);
    }
}
