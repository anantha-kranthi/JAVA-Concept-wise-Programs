// Assumption: = is right-associative, so a chained assignment applies right to left.
public class ChainedAssignmentDemo {
    public static void main(String[] args) {
        int a, b, c;
        a = b = c = 5;
        System.out.println("a=" + a + ", b=" + b + ", c=" + c);
    }
}
