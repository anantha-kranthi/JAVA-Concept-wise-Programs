// Assumption: Java's % keeps the sign of the dividend, unlike mathematical modulo.
public class ModulusNegativeDemo {
    public static void main(String[] args) {
        System.out.println("-7 % 2 = " + (-7 % 2));
        System.out.println("7 % -2 = " + (7 % -2));
        System.out.println("-7 % -2 = " + (-7 % -2));
    }
}
