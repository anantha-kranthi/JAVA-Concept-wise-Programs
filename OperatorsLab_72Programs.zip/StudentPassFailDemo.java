// Assumption: pass requires marks >= 40 in EACH of three subjects, combined using && with short-circuit evaluation.
public class StudentPassFailDemo {
    public static void main(String[] args) {
        int math = 55, science = 38, english = 60;
        boolean passed = math >= 40 && science >= 40 && english >= 40;
        System.out.println("Passed: " + passed);
    }
}
