// Assumption: mixing types in one arithmetic expression promotes everything to the widest type present.
public class MixedTypePromotionDemo {
    public static void main(String[] args) {
        int i = 5;
        long l = 10L;
        float f = 2.5f;
        double d = 1.5;
        double result = i + l + f + d;
        System.out.println("result: " + result);
    }
}
