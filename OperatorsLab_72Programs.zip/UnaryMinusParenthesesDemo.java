// Assumption: unary minus applies only to the immediately following operand unless parentheses group more.
public class UnaryMinusParenthesesDemo {
    public static void main(String[] args) {
        int a = 5, b = 3;
        System.out.println("-a + b = " + (-a + b));
        System.out.println("-(a + b) = " + (-(a + b)));
    }
}
