// Assumption: | compares bits pairwise; result bit is 1 if either operand bit is 1.
public class BitwiseOrDemo {
    public static void main(String[] args) {
        int a = 12, b = 10;
        System.out.println("12 | 10 = " + (a | b));
    }
}
