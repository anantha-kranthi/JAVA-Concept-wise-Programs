// Assumption: demonstrating all 6 relational operators on two sample ints.
public class RelationalOperatorsDemo {
    public static void main(String[] args) {
        int a = 10, b = 20;
        System.out.println("a < b: " + (a < b));
        System.out.println("a > b: " + (a > b));
        System.out.println("a <= b: " + (a <= b));
        System.out.println("a >= b: " + (a >= b));
        System.out.println("a == b: " + (a == b));
        System.out.println("a != b: " + (a != b));
    }
}
