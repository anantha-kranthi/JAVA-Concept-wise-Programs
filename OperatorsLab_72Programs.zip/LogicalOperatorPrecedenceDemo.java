// Assumption: ! binds tighter than &&, which binds tighter than ||.
public class LogicalOperatorPrecedenceDemo {
    public static void main(String[] args) {
        boolean result = true || false && !true;
        System.out.println("true || false && !true = " + result);
    }
}
