// Assumption: ternary operator picks an action based on the current signal color.
public class TrafficSignalSimulationDemo {
    public static void main(String[] args) {
        String signal = "RED";
        String action = signal.equals("RED") ? "STOP" : signal.equals("YELLOW") ? "SLOW DOWN" : "GO";
        System.out.println("Signal: " + signal + " -> Action: " + action);
    }
}
