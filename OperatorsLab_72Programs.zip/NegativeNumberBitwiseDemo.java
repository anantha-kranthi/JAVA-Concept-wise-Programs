// Assumption: negative ints are stored in two's complement, which bitwise operators expose directly.
public class NegativeNumberBitwiseDemo {
    public static void main(String[] args) {
        int a = -5;
        System.out.println("-5 in binary: " + Integer.toBinaryString(a));
        System.out.println("~(-5) = " + (~a));
    }
}
