// Assumption: += on a String performs concatenation, not numeric addition.
public class StringCompoundAssignmentDemo {
    public static void main(String[] args) {
        String s = "Hello";
        s += " World";
        s += "!";
        System.out.println(s);
    }
}
