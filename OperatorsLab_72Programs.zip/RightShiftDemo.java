// Assumption: >> shifts bits right, sign-extending -- equivalent to dividing by 2 per shift for positive numbers.
public class RightShiftDemo {
    public static void main(String[] args) {
        int a = -16;
        System.out.println("-16 >> 2 = " + (a >> 2));
    }
}
