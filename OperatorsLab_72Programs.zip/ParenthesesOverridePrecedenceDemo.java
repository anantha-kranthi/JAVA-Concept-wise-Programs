// Assumption: parentheses force a different, intended evaluation order than default precedence would give.
public class ParenthesesOverridePrecedenceDemo {
    public static void main(String[] args) {
        int a = 2, b = 3, c = 4;
        System.out.println("default: a + b * c = " + (a + b * c));
        System.out.println("forced: (a + b) * c = " + ((a + b) * c));
    }
}
