// Assumption: arithmetic operators bind tighter than relational operators.
public class PrecedenceArithmeticRelationalDemo {
    public static void main(String[] args) {
        boolean result = 2 + 3 > 4;
        System.out.println("2 + 3 > 4 = " + result);
    }
}
