// Assumption: == compares references for wrapper objects outside the cache range; .equals() compares value.
public class WrapperEqualsVsEqualsDemo {
    public static void main(String[] args) {
        Integer a = 1000, b = 1000;
        System.out.println("a == b: " + (a == b));
        System.out.println("a.equals(b): " + a.equals(b));
    }
}
