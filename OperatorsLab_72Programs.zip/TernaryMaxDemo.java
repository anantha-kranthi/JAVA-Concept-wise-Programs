// Assumption: ternary operator chosen over if-else for a simple one-line decision.
public class TernaryMaxDemo {
    public static void main(String[] args) {
        int a = 15, b = 20;
        int max = (a > b) ? a : b;
        System.out.println("max: " + max);
    }
}
