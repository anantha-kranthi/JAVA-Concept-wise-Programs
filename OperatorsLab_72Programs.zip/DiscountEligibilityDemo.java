// Assumption: eligible for a discount if purchase >= 1000 AND customer is a member.
public class DiscountEligibilityDemo {
    public static void main(String[] args) {
        double purchase = 1200;
        boolean isMember = true;
        boolean eligible = purchase >= 1000 && isMember;
        System.out.println("Eligible for discount: " + eligible);
    }
}
