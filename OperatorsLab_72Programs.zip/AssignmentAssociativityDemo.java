// Assumption: assignment operators associate right to left, unlike arithmetic operators.
public class AssignmentAssociativityDemo {
    public static void main(String[] args) {
        int x, y, z;
        x = y = z = 10;
        System.out.println("x=" + x + " y=" + y + " z=" + z);
    }
}
