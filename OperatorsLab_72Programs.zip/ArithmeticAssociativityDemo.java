// Assumption: same-precedence arithmetic operators associate left to right.
public class ArithmeticAssociativityDemo {
    public static void main(String[] args) {
        int result = 20 - 5 - 3;
        System.out.println("20 - 5 - 3 = " + result);
    }
}
