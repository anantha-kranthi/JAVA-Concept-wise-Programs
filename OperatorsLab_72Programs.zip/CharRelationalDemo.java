// Assumption: chars compare by their underlying numeric (Unicode) code point.
public class CharRelationalDemo {
    public static void main(String[] args) {
        char a = 'a', b = 'z';
        System.out.println("'a' < 'z': " + (a < b));
        System.out.println("'a' code: " + (int) a + ", 'z' code: " + (int) b);
    }
}
