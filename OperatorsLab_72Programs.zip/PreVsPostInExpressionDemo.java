// Assumption: pre-increment updates before use in the expression; post-increment updates after.
public class PreVsPostInExpressionDemo {
    public static void main(String[] args) {
        int i = 5;
        int a = ++i;
        int j = 5;
        int b = j++;
        System.out.println("pre-increment: i=" + i + ", a=" + a);
        System.out.println("post-increment: j=" + j + ", b=" + b);
    }
}
