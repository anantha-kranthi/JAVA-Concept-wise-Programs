// Assumption: & compares bits pairwise; result bit is 1 only if both operand bits are 1.
public class BitwiseAndDemo {
    public static void main(String[] args) {
        int a = 12, b = 10;
        System.out.println("12 & 10 = " + (a & b));
    }
}
