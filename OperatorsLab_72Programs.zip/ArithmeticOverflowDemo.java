// Assumption: + wraps silently on overflow, no exception thrown.
public class ArithmeticOverflowDemo {
    public static void main(String[] args) {
        int max = Integer.MAX_VALUE;
        System.out.println("MAX_VALUE + 1 = " + (max + 1));
    }
}
