// Assumption: comparing computed doubles with == can fail due to floating point representation error.
public class DoubleRelationalPitfallDemo {
    public static void main(String[] args) {
        double a = 0.1 + 0.2;
        double b = 0.3;
        System.out.println("a == b: " + (a == b));
        System.out.println("safer check: " + (Math.abs(a - b) < 1e-9));
    }
}
