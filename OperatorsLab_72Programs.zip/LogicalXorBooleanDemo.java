// Assumption: ^ on booleans is exclusive-or: true only when exactly one operand is true.
public class LogicalXorBooleanDemo {
    public static void main(String[] args) {
        System.out.println("true ^ true = " + (true ^ true));
        System.out.println("true ^ false = " + (true ^ false));
        System.out.println("false ^ false = " + (false ^ false));
    }
}
