// Assumption: two int variables can be swapped without a temp variable using repeated XOR.
public class XorSwapDemo {
    public static void main(String[] args) {
        int a = 5, b = 9;
        System.out.println("before: a=" + a + ", b=" + b);
        a = a ^ b;
        b = a ^ b;
        a = a ^ b;
        System.out.println("after: a=" + a + ", b=" + b);
    }
}
