// Assumption: & always evaluates both sides even for booleans; && short-circuits.
public class BitwiseAndVsLogicalAndDemo {
    static boolean sideEffect(String label, boolean value) {
        System.out.println(label + " evaluated");
        return value;
    }
    public static void main(String[] args) {
        System.out.println("Using &&:");
        boolean r1 = sideEffect("left", false) && sideEffect("right", true);
        System.out.println("Using &:");
        boolean r2 = sideEffect("left", false) & sideEffect("right", true);
    }
}
