// Assumption: << shifts bits left, filling with zeros -- equivalent to multiplying by 2 per shift.
public class LeftShiftDemo {
    public static void main(String[] args) {
        int a = 3;
        System.out.println("3 << 2 = " + (a << 2));
    }
}
