// Assumption: operator symbol entered as a char; switch dispatches to the matching arithmetic operator.
public class SimpleCalculatorSwitchDemo {
    public static void main(String[] args) {
        double a = 10, b = 3;
        char op = '/';
        double result;
        switch (op) {
            case '+': result = a + b; break;
            case '-': result = a - b; break;
            case '*': result = a * b; break;
            case '/': result = a / b; break;
            default: throw new IllegalArgumentException("Unknown operator: " + op);
        }
        System.out.println(a + " " + op + " " + b + " = " + result);
    }
}
