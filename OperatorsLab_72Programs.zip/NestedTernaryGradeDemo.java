// Assumption: nested ternary expressions chain multiple conditions, though readability drops fast beyond 2 levels.
public class NestedTernaryGradeDemo {
    public static void main(String[] args) {
        int marks = 72;
        String grade = (marks >= 90) ? "A" : (marks >= 75) ? "B" : (marks >= 50) ? "C" : "F";
        System.out.println("grade: " + grade);
    }
}
