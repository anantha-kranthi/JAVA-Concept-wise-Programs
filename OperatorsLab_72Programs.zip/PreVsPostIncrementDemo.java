// Assumption: pre-increment returns the updated value; post-increment returns the value before updating.
public class PreVsPostIncrementDemo {
    public static void main(String[] args) {
        int i = 5;
        System.out.println("i++ = " + (i++));
        System.out.println("i now = " + i);
        int j = 5;
        System.out.println("++j = " + (++j));
    }
}
