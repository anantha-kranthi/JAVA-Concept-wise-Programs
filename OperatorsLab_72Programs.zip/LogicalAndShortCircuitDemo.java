// Assumption: && stops evaluating the right side once the left side is false.
public class LogicalAndShortCircuitDemo {
    public static void main(String[] args) {
        int[] arr = {};
        if (arr.length > 0 && arr[0] == 1) {
            System.out.println("first element is 1");
        } else {
            System.out.println("short-circuited safely, no ArrayIndexOutOfBoundsException");
        }
    }
}
