// Assumption: a valid RGB color requires all three channels within 0-255, combined with && across relational checks.
public class RgbValidationDemo {
    public static void main(String[] args) {
        int r = 255, g = 300, b = 0;
        boolean valid = (r >= 0 && r <= 255) && (g >= 0 && g <= 255) && (b >= 0 && b <= 255);
        System.out.println("Valid RGB: " + valid);
    }
}
