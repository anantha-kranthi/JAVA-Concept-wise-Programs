// Assumption: short-circuit && is used deliberately to guard against division by zero.
public class ShortCircuitGuardDemo {
    public static void main(String[] args) {
        int a = 10, b = 0;
        if (b != 0 && a / b > 1) {
            System.out.println("division result > 1");
        } else {
            System.out.println("guarded: division skipped safely when b is 0");
        }
    }
}
