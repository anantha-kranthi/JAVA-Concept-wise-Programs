// Assumption: | always evaluates both sides; || short-circuits once the left side is true.
public class BitwiseOrVsLogicalOrDemo {
    static boolean sideEffect(String label, boolean value) {
        System.out.println(label + " evaluated");
        return value;
    }
    public static void main(String[] args) {
        System.out.println("Using ||:");
        boolean r1 = sideEffect("left", true) || sideEffect("right", false);
        System.out.println("Using |:");
        boolean r2 = sideEffect("left", true) | sideEffect("right", false);
    }
}
