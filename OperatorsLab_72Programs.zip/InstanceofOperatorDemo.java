// Assumption: instanceof checks the runtime type of an object reference before an unsafe cast.
public class InstanceofOperatorDemo {
    public static void main(String[] args) {
        Object obj = "Hello";
        if (obj instanceof String) {
            String s = (String) obj;
            System.out.println("length: " + s.length());
        }
        Object num = 42;
        System.out.println("num instanceof String: " + (num instanceof String));
    }
}
