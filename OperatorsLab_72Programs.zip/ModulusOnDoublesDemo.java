// Assumption: % is also valid on floating point types, giving the floating point remainder.
public class ModulusOnDoublesDemo {
    public static void main(String[] args) {
        double d = 7.5 % 2.0;
        System.out.println("7.5 % 2.0 = " + d);
    }
}
