// Assumption: using i++ vs ++i as an array index changes which element is accessed -- a classic pitfall.
public class IncrementInArrayIndexDemo {
    public static void main(String[] args) {
        int[] arr = {10, 20, 30, 40};
        int i = 0;
        System.out.println("arr[i++] = " + arr[i++]);
        System.out.println("i is now: " + i);
        int j = 0;
        System.out.println("arr[++j] = " + arr[++j]);
    }
}
