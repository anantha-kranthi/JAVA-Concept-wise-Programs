// Assumption: same two numbers divided as int vs double to show / behaves differently per type.
public class IntVsDoubleDivision {
    public static void main(String[] args) {
        System.out.println("int: 7 / 2 = " + (7 / 2));
        System.out.println("double: 7.0 / 2 = " + (7.0 / 2));
    }
}
