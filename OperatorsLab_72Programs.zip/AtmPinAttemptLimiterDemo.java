// Assumption: user gets up to 3 attempts; loop combines relational, logical, and increment operators together.
public class AtmPinAttemptLimiterDemo {
    public static void main(String[] args) {
        int correctPin = 1234;
        int[] attempts = {1111, 2222, 1234};
        int attemptCount = 0;
        boolean success = false;

        while (attemptCount < attempts.length && attemptCount < 3 && !success) {
            success = (attempts[attemptCount] == correctPin);
            attemptCount++;
        }

        System.out.println("Attempts used: " + attemptCount + ", Access granted: " + success);
    }
}
