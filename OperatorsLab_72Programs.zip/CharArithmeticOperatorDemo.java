// Assumption: arithmetic operators on char operands promote both to int automatically.
public class CharArithmeticOperatorDemo {
    public static void main(String[] args) {
        char a = 'A', b = 'B';
        int sum = a + b;
        System.out.println("'A' + 'B' = " + sum);
    }
}
