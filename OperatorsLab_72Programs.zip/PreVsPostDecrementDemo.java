// Assumption: same concept as increment, applied to decrement operators.
public class PreVsPostDecrementDemo {
    public static void main(String[] args) {
        int i = 5;
        System.out.println("i-- = " + (i--));
        System.out.println("i now = " + i);
        int j = 5;
        System.out.println("--j = " + (--j));
    }
}
