// Assumption: || stops evaluating the right side once the left side is true.
public class LogicalOrShortCircuitDemo {
    public static void main(String[] args) {
        int x = 5;
        if (x > 0 || 10 / 0 == 0) {
            System.out.println("short-circuited safely: x is positive");
        }
    }
}
