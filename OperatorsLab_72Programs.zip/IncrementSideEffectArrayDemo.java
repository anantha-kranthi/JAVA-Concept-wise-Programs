// Assumption: using arr[i]++ updates the array element in place; i itself remains unchanged.
public class IncrementSideEffectArrayDemo {
    public static void main(String[] args) {
        int[] counts = new int[5];
        int i = 2;
        counts[i]++;
        System.out.println("counts[2] = " + counts[2] + ", i = " + i);
    }
}
