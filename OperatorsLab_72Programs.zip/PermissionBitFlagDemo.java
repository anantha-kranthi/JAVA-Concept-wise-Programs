// Assumption: file permission system using bitwise OR to grant and bitwise AND to check individual access flags.
public class PermissionBitFlagDemo {
    static final int READ = 1, WRITE = 2, EXECUTE = 4;
    public static void main(String[] args) {
        int userPermissions = READ | EXECUTE;
        System.out.println("Can read: " + ((userPermissions & READ) != 0));
        System.out.println("Can write: " + ((userPermissions & WRITE) != 0));
        System.out.println("Can execute: " + ((userPermissions & EXECUTE) != 0));
    }
}
