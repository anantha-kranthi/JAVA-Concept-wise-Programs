// Assumption: == binds tighter than & in Java, so bitwise expressions with equality need explicit parentheses.
public class PrecedenceBitwiseEqualityDemo {
    public static void main(String[] args) {
        int flags = 5;
        // boolean wrong = flags & 1 == 1; // COMPILE ERROR: == binds first, giving incompatible types
        boolean right = (flags & 1) == 1;
        System.out.println("bit 0 set: " + right);
    }
}
