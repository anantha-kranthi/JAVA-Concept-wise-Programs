// Assumption: ^ compares bits pairwise; result bit is 1 only when the operand bits differ.
public class BitwiseXorDemo {
    public static void main(String[] args) {
        int a = 12, b = 10;
        System.out.println("12 ^ 10 = " + (a ^ b));
    }
}
