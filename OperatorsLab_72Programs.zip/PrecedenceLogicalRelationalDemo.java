// Assumption: relational operators bind tighter than logical operators.
public class PrecedenceLogicalRelationalDemo {
    public static void main(String[] args) {
        boolean result = 5 > 3 && 2 < 4;
        System.out.println("5>3 && 2<4 = " + result);
    }
}
