// Assumption: unary and ternary operators are right-associative in Java.
public class UnaryTernaryAssociativityDemo {
    public static void main(String[] args) {
        boolean a = true, b = false;
        String result = a ? "A" : b ? "B" : "C";
        System.out.println("result: " + result);
    }
}
