// Assumption: shifting and masking extracts specific bytes/bits from a packed int value.
public class BitMaskExtractDemo {
    public static void main(String[] args) {
        int packed = 0xAABBCCDD;
        int byte1 = (packed >> 24) & 0xFF;
        int byte2 = (packed >> 16) & 0xFF;
        int byte3 = (packed >> 8) & 0xFF;
        int byte4 = packed & 0xFF;
        System.out.printf("bytes: %02X %02X %02X %02X%n", byte1, byte2, byte3, byte4);
    }
}
