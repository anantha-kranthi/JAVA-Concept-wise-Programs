// Assumption: the last bit of a number determines parity; n & 1 isolates it.
public class EvenOddUsingBitwiseAnd {
    public static void main(String[] args) {
        int n = 15;
        System.out.println(n + " is " + ((n & 1) == 0 ? "Even" : "Odd"));
    }
}
