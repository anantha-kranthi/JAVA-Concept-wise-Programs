// Assumption: bitwise operators also have compound assignment forms: &=, |=, ^=, <<=, >>=, >>>=.
public class CompoundBitwiseAssignmentDemo {
    public static void main(String[] args) {
        int a = 12;
        a &= 10; System.out.println("a &= 10 -> " + a);
        a |= 3;  System.out.println("a |= 3 -> " + a);
        a ^= 5;  System.out.println("a ^= 5 -> " + a);
        a <<= 2; System.out.println("a <<= 2 -> " + a);
        a >>= 1; System.out.println("a >>= 1 -> " + a);
        a >>>= 1; System.out.println("a >>>= 1 -> " + a);
    }
}
