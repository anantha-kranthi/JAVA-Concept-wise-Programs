// Assumption: a positive power of two has exactly one set bit, so n & (n-1) equals zero for it.
public class PowerOfTwoCheckDemo {
    public static void main(String[] args) {
        int[] values = {16, 18, 1, 0};
        for (int n : values) {
            boolean isPower = n > 0 && (n & (n - 1)) == 0;
            System.out.println(n + " is power of two: " + isPower);
        }
    }
}
