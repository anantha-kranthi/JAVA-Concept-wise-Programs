// Assumption: shifting left by n multiplies by 2^n; shifting right by n divides by 2^n (for positive ints).
public class ShiftMultiplyDivideDemo {
    public static void main(String[] args) {
        int a = 5;
        System.out.println("5 << 3 (5*8) = " + (a << 3));
        int b = 40;
        System.out.println("40 >> 3 (40/8) = " + (b >> 3));
    }
}
