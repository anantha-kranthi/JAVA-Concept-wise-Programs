// Assumption: >>> shifts bits right filling with zeros regardless of sign, unlike >> which sign-extends.
public class UnsignedRightShiftDemo {
    public static void main(String[] args) {
        int a = -16;
        System.out.println("-16 >> 2  (signed): " + (a >> 2));
        System.out.println("-16 >>> 2 (unsigned): " + (a >>> 2));
    }
}
