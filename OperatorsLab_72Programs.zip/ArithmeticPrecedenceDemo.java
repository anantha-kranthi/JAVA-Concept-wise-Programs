// Assumption: * and / bind tighter than + and -, evaluated left to right within the same level.
public class ArithmeticPrecedenceDemo {
    public static void main(String[] args) {
        int result = 2 + 3 * 4 - 6 / 2;
        System.out.println("2 + 3*4 - 6/2 = " + result);
    }
}
