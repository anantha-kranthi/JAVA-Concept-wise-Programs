// Assumption: ! inverts a boolean value.
public class LogicalNotDemo {
    public static void main(String[] args) {
        boolean isRaining = false;
        System.out.println("isRaining: " + isRaining);
        System.out.println("!isRaining: " + !isRaining);
    }
}
