// Assumption: when ternary branches have different numeric types, Java unifies the result to the wider type.
public class TernaryTypeUnificationDemo {
    public static void main(String[] args) {
        boolean condition = true;
        double result = condition ? 5 : 3.5;
        System.out.println("result: " + result);
    }
}
