/* Program 69: Reading elements into a 3D array
   Sample input:  2 2 2
                  1 2 3 4 5 6 7 8                           */
import java.util.Scanner;

public class P69_Input3DArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of blocks: ");
        int blocks = sc.nextInt();
        System.out.print("Enter number of rows: ");
        int rows = sc.nextInt();
        System.out.print("Enter number of columns: ");
        int cols = sc.nextInt();

        int[][][] arr = new int[blocks][rows][cols];

        System.out.println("Enter " + (blocks * rows * cols) + " elements:");
        for (int i = 0; i < blocks; i++) {
            for (int j = 0; j < rows; j++) {
                for (int k = 0; k < cols; k++) {
                    arr[i][j][k] = sc.nextInt();
                }
            }
        }

        System.out.println("\nThe 3D array you entered:");
        for (int i = 0; i < blocks; i++) {
            System.out.println("Block " + i + ":");
            for (int j = 0; j < rows; j++) {
                for (int k = 0; k < cols; k++) {
                    System.out.printf("%6d", arr[i][j][k]);
                }
                System.out.println();
            }
            System.out.println();
        }

        System.out.println("Element at [0][0][0] = " + arr[0][0][0]);
        System.out.println("Element at last position = "
                + arr[blocks - 1][rows - 1][cols - 1]);

        sc.close();
    }
}
