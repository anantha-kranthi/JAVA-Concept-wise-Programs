/* Program 68: Declaring, initializing and displaying a 3D array */
import java.util.Arrays;

public class P68_Declare3DArray {
    public static void main(String[] args) {
        // A 3D array is an array of 2D arrays: [blocks][rows][columns]
        int[][][] cube = {
            {   // block 0
                {1, 2, 3},
                {4, 5, 6}
            },
            {   // block 1
                {7, 8, 9},
                {10, 11, 12}
            }
        };

        System.out.println("Dimensions: " + cube.length + " blocks x "
                + cube[0].length + " rows x " + cube[0][0].length + " columns");
        System.out.println("Total elements = "
                + (cube.length * cube[0].length * cube[0][0].length));

        for (int i = 0; i < cube.length; i++) {
            System.out.println("\nBlock " + i + ":");
            for (int j = 0; j < cube[i].length; j++) {
                for (int k = 0; k < cube[i][j].length; k++) {
                    System.out.printf("%5d", cube[i][j][k]);
                }
                System.out.println();
            }
        }

        System.out.println("\ncube[1][0][2] = " + cube[1][0][2]);
        System.out.println("deepToString  : " + Arrays.deepToString(cube));

        // Allocate with new and fill programmatically
        int[][][] auto = new int[2][3][4];
        int v = 1;
        for (int i = 0; i < 2; i++)
            for (int j = 0; j < 3; j++)
                for (int k = 0; k < 4; k++)
                    auto[i][j][k] = v++;
        System.out.println("\nA 2x3x4 array filled 1..24:");
        System.out.println(Arrays.deepToString(auto));
    }
}
