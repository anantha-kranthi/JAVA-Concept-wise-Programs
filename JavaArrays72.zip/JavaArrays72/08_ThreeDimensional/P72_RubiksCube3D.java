/* Program 72: Representing a 3x3x3 Rubik's-cube-like structure with a 3D array */
public class P72_RubiksCube3D {
    public static void main(String[] args) {
        // Each cell holds a colour code for one small cube (cubie)
        char[][][] cube = new char[3][3][3];
        char[] colours = {'W', 'Y', 'R', 'O', 'B', 'G'};  // White Yellow Red Orange Blue Green

        int c = 0;
        for (int layer = 0; layer < 3; layer++) {
            for (int row = 0; row < 3; row++) {
                for (int col = 0; col < 3; col++) {
                    cube[layer][row][col] = colours[c % colours.length];
                    c++;
                }
            }
        }

        String[] layerNames = {"TOP layer", "MIDDLE layer", "BOTTOM layer"};
        for (int layer = 0; layer < 3; layer++) {
            System.out.println(layerNames[layer] + " (cube[" + layer + "]):");
            System.out.println("  +---+---+---+");
            for (int row = 0; row < 3; row++) {
                System.out.print("  |");
                for (int col = 0; col < 3; col++) {
                    System.out.print(" " + cube[layer][row][col] + " |");
                }
                System.out.println("\n  +---+---+---+");
            }
            System.out.println();
        }

        System.out.println("Total cubies = 3 x 3 x 3 = "
                + (cube.length * cube[0].length * cube[0][0].length));
        System.out.println("Centre cubie cube[1][1][1] = " + cube[1][1][1]
                + "  (invisible in a real cube)");
        System.out.println("Corner cubie cube[0][0][0] = " + cube[0][0][0]);

        // Count how many cubies carry each colour
        System.out.println("\nColour distribution:");
        for (char colour : colours) {
            int count = 0;
            for (char[][] layer : cube)
                for (char[] row : layer)
                    for (char cell : row)
                        if (cell == colour) count++;
            System.out.println("  " + colour + " : " + count + " cubie(s)");
        }

        // Rotate the top layer 90 degrees clockwise
        char[][] top = cube[0];
        char[][] rotated = new char[3][3];
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                rotated[j][2 - i] = top[i][j];
        cube[0] = rotated;

        System.out.println("\nTOP layer after a 90 degree clockwise turn:");
        System.out.println("  +---+---+---+");
        for (int row = 0; row < 3; row++) {
            System.out.print("  |");
            for (int col = 0; col < 3; col++) System.out.print(" " + cube[0][row][col] + " |");
            System.out.println("\n  +---+---+---+");
        }
    }
}
