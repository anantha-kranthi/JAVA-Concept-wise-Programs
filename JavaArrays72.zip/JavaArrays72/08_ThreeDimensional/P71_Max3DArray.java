/* Program 71: Finding the maximum and minimum element in a 3D array */
public class P71_Max3DArray {
    public static void main(String[] args) {
        int[][][] arr = {
            {
                {23, 67, 12},
                {89, 4, 55}
            },
            {
                {71, 38, 95},
                {16, 42, 8}
            }
        };

        int max = arr[0][0][0], min = arr[0][0][0];
        int mi = 0, mj = 0, mk = 0;
        int ni = 0, nj = 0, nk = 0;

        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                for (int k = 0; k < arr[i][j].length; k++) {
                    if (arr[i][j][k] > max) {
                        max = arr[i][j][k]; mi = i; mj = j; mk = k;
                    }
                    if (arr[i][j][k] < min) {
                        min = arr[i][j][k]; ni = i; nj = j; nk = k;
                    }
                }
            }
        }

        System.out.println("The 3D array:");
        for (int i = 0; i < arr.length; i++) {
            System.out.println("Block " + i + ":");
            for (int[] row : arr[i]) {
                for (int v : row) System.out.printf("%6d", v);
                System.out.println();
            }
        }

        System.out.println("\nMaximum : " + max + " at [" + mi + "][" + mj + "][" + mk + "]");
        System.out.println("Minimum : " + min + " at [" + ni + "][" + nj + "][" + nk + "]");
        System.out.println("Range   : " + (max - min));

        System.out.println("\nMaximum in each block:");
        for (int i = 0; i < arr.length; i++) {
            int blockMax = arr[i][0][0];
            for (int[] row : arr[i]) for (int v : row) if (v > blockMax) blockMax = v;
            System.out.println("  Block " + i + " -> " + blockMax);
        }
    }
}
