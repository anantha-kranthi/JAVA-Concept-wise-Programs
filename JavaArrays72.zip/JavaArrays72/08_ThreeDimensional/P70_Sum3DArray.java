/* Program 70: Sum of all elements in a 3D array */
public class P70_Sum3DArray {
    public static void main(String[] args) {
        // Sales data: [store][month][week]
        int[][][] sales = {
            {   // Store 0
                {120, 135, 110, 145},   // month 0
                {150, 160, 155, 170}    // month 1
            },
            {   // Store 1
                {200, 190, 210, 205},
                {180, 175, 195, 188}
            },
            {   // Store 2
                { 90, 105,  95, 100},
                {110, 120, 115, 125}
            }
        };

        int grandTotal = 0;
        System.out.println("Weekly sales by store and month:\n");

        for (int store = 0; store < sales.length; store++) {
            int storeTotal = 0;
            System.out.println("Store " + store + ":");
            for (int month = 0; month < sales[store].length; month++) {
                int monthTotal = 0;
                System.out.print("  Month " + month + " : ");
                for (int week = 0; week < sales[store][month].length; week++) {
                    System.out.printf("%5d", sales[store][month][week]);
                    monthTotal += sales[store][month][week];
                }
                System.out.println("   month total = " + monthTotal);
                storeTotal += monthTotal;
            }
            System.out.println("  Store " + store + " total = " + storeTotal + "\n");
            grandTotal += storeTotal;
        }

        int count = sales.length * sales[0].length * sales[0][0].length;
        System.out.println("Grand total across all stores = " + grandTotal);
        System.out.printf("Average per week = %.2f (over %d readings)%n",
                (double) grandTotal / count, count);
    }
}
