/* Program 67: Sorting each row of a jagged array individually */
import java.util.Arrays;

public class P67_SortJaggedRows {
    public static void main(String[] args) {
        int[][] jagged = {
            {50, 10, 30},
            {9, 7},
            {100, 25, 75, 50, 5},
            {42}
        };

        System.out.println("Before sorting:");
        display(jagged);

        for (int[] row : jagged) {
            Arrays.sort(row);          // each row is an independent array object
        }

        System.out.println("\nAfter sorting each row ascending:");
        display(jagged);

        // Sorting rows by their length instead of their contents
        int[][] byLength = {{1, 2, 3}, {4}, {5, 6, 7, 8, 9}, {10, 11}};
        System.out.println("\nRows before ordering by length:");
        display(byLength);
        Arrays.sort(byLength, (r1, r2) -> r1.length - r2.length);
        System.out.println("\nRows ordered by length:");
        display(byLength);

        // Sorting rows by their sum
        int[][] bySum = {{10, 10}, {1}, {5, 5, 5, 5}, {100}};
        Arrays.sort(bySum, (r1, r2) -> total(r1) - total(r2));
        System.out.println("\nRows ordered by row sum:");
        for (int[] row : bySum) {
            System.out.println("  " + Arrays.toString(row) + "  sum=" + total(row));
        }
    }

    static int total(int[] row) {
        int s = 0;
        for (int v : row) s += v;
        return s;
    }

    static void display(int[][] a) {
        for (int i = 0; i < a.length; i++) {
            System.out.println("  row " + i + ": " + Arrays.toString(a[i]));
        }
    }
}
