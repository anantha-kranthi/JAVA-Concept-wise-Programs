/* Program 65: Finding the rows with the most and fewest elements */
public class P65_LongestRowJagged {
    public static void main(String[] args) {
        int[][] jagged = {
            {1, 2},
            {3, 4, 5, 6, 7},
            {8},
            {9, 10, 11},
            {12, 13, 14, 15, 16}
        };

        System.out.println("The jagged array:");
        for (int i = 0; i < jagged.length; i++) {
            System.out.print("  row " + i + " (" + jagged[i].length + "): ");
            for (int v : jagged[i]) System.out.print(v + " ");
            System.out.println();
        }

        int longest = 0, shortest = 0, totalCells = 0;
        for (int i = 0; i < jagged.length; i++) {
            if (jagged[i].length > jagged[longest].length) longest = i;
            if (jagged[i].length < jagged[shortest].length) shortest = i;
            totalCells += jagged[i].length;
        }

        System.out.println("\nLongest row  : row " + longest
                + " with " + jagged[longest].length + " elements");
        System.out.println("Shortest row : row " + shortest
                + " with " + jagged[shortest].length + " elements");
        System.out.printf("Average row length : %.2f%n",
                (double) totalCells / jagged.length);

        // Report every row that ties for the maximum length
        System.out.print("All rows of maximum length : ");
        for (int i = 0; i < jagged.length; i++) {
            if (jagged[i].length == jagged[longest].length) System.out.print("row " + i + "  ");
        }
        System.out.println();
    }
}
