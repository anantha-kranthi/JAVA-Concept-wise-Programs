/* Program 63: Reading a jagged array from the user
   Sample input:  3
                  2
                  10 20
                  3
                  30 40 50
                  1
                  60                                       */
import java.util.Scanner;

public class P63_InputJaggedArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("How many rows? ");
        int rows = sc.nextInt();
        int[][] jagged = new int[rows][];

        for (int i = 0; i < rows; i++) {
            System.out.print("Number of elements in row " + i + ": ");
            int cols = sc.nextInt();
            jagged[i] = new int[cols];

            System.out.println("Enter " + cols + " element(s) for row " + i + ":");
            for (int j = 0; j < cols; j++) {
                jagged[i][j] = sc.nextInt();
            }
        }

        System.out.println("\nThe jagged array you entered:");
        for (int i = 0; i < jagged.length; i++) {
            System.out.print("Row " + i + " (" + jagged[i].length + " elements): ");
            int rowSum = 0;
            for (int j = 0; j < jagged[i].length; j++) {
                System.out.print(jagged[i][j] + " ");
                rowSum += jagged[i][j];
            }
            System.out.println("  [sum = " + rowSum + "]");
        }

        sc.close();
    }
}
