/* Program 64: Sum of all elements in a jagged array */
public class P64_JaggedArraySum {
    public static void main(String[] args) {
        int[][] jagged = {
            {10, 20, 30},
            {40},
            {50, 60},
            {70, 80, 90, 100}
        };

        int grandTotal = 0, totalElements = 0;

        System.out.println("Row | Elements              | Count | Sum  | Average");
        System.out.println("----+-----------------------+-------+------+--------");
        for (int i = 0; i < jagged.length; i++) {
            int rowSum = 0;
            StringBuilder sb = new StringBuilder();
            for (int j = 0; j < jagged[i].length; j++) {
                rowSum += jagged[i][j];
                sb.append(jagged[i][j]).append(" ");
            }
            grandTotal += rowSum;
            totalElements += jagged[i].length;
            System.out.printf(" %-2d | %-21s | %-5d | %-4d | %.2f%n",
                    i, sb.toString().trim(), jagged[i].length, rowSum,
                    (double) rowSum / jagged[i].length);
        }

        System.out.println("\nTotal elements    : " + totalElements);
        System.out.println("Grand total       : " + grandTotal);
        System.out.printf("Overall average   : %.2f%n", (double) grandTotal / totalElements);

        // Same thing with an enhanced for loop
        int check = 0;
        for (int[] row : jagged) for (int v : row) check += v;
        System.out.println("Verified with enhanced for : " + check);
    }
}
