/* Program 62: Declaring and initializing a jagged (ragged) array */
import java.util.Arrays;

public class P62_DeclareJaggedArray {
    public static void main(String[] args) {
        // Method 1: literal with rows of different lengths
        int[][] jagged = {
            {1},
            {2, 3},
            {4, 5, 6},
            {7, 8, 9, 10}
        };

        // Method 2: leave the second dimension empty, then size each row
        int[][] manual = new int[3][];
        manual[0] = new int[2];
        manual[1] = new int[5];
        manual[2] = new int[1];
        int value = 1;
        for (int i = 0; i < manual.length; i++)
            for (int j = 0; j < manual[i].length; j++)
                manual[i][j] = value++;

        System.out.println("Jagged array (triangle shape):");
        display(jagged);

        System.out.println("\nManually sized jagged array:");
        display(manual);

        System.out.println("\nRow lengths of 'jagged':");
        for (int i = 0; i < jagged.length; i++) {
            System.out.println("  row " + i + " has " + jagged[i].length + " element(s)");
        }

        System.out.println("\ndeepToString : " + Arrays.deepToString(jagged));
        System.out.println("\nA 2D array in Java is really an array of array references,");
        System.out.println("so each row can have its own independent length.");
    }

    static void display(int[][] a) {
        for (int i = 0; i < a.length; i++) {
            System.out.print("  row " + i + ": ");
            for (int j = 0; j < a[i].length; j++) System.out.print(a[i][j] + " ");
            System.out.println();
        }
    }
}
