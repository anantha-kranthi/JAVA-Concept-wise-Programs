/* Program 66: Finding the largest and smallest element in a jagged array */
public class P66_LargestInJagged {
    public static void main(String[] args) {
        int[][] jagged = {
            {45, 12},
            {78, 33, 91, 5},
            {60},
            {8, 27, 99, 14, 50}
        };

        int max = jagged[0][0], min = jagged[0][0];
        int maxRow = 0, maxCol = 0, minRow = 0, minCol = 0;

        for (int i = 0; i < jagged.length; i++) {
            for (int j = 0; j < jagged[i].length; j++) {
                if (jagged[i][j] > max) { max = jagged[i][j]; maxRow = i; maxCol = j; }
                if (jagged[i][j] < min) { min = jagged[i][j]; minRow = i; minCol = j; }
            }
        }

        System.out.println("The jagged array:");
        for (int i = 0; i < jagged.length; i++) {
            System.out.print("  row " + i + ": ");
            for (int v : jagged[i]) System.out.printf("%5d", v);
            System.out.println();
        }

        System.out.println("\nLargest  : " + max + " at [" + maxRow + "][" + maxCol + "]");
        System.out.println("Smallest : " + min + " at [" + minRow + "][" + minCol + "]");
        System.out.println("Range    : " + (max - min));

        System.out.println("\nLargest element of each row:");
        for (int i = 0; i < jagged.length; i++) {
            int rowMax = jagged[i][0];
            for (int v : jagged[i]) if (v > rowMax) rowMax = v;
            System.out.println("  row " + i + " -> " + rowMax);
        }
    }
}
