/* Program 4: Default values of array elements for different data types */
import java.util.Arrays;

public class P04_DefaultValues {
    public static void main(String[] args) {
        int[] intArr = new int[3];
        double[] dblArr = new double[3];
        boolean[] boolArr = new boolean[3];
        char[] charArr = new char[3];
        String[] strArr = new String[3];
        long[] longArr = new long[3];

        System.out.println("int default     : " + Arrays.toString(intArr));
        System.out.println("long default    : " + Arrays.toString(longArr));
        System.out.println("double default  : " + Arrays.toString(dblArr));
        System.out.println("boolean default : " + Arrays.toString(boolArr));
        System.out.println("String default  : " + Arrays.toString(strArr));

        System.out.print("char default    : [");
        for (int i = 0; i < charArr.length; i++) {
            System.out.print((int) charArr[i] + (i < charArr.length - 1 ? ", " : ""));
        }
        System.out.println("]  (shown as numeric codes; '\\u0000' is invisible)");
    }
}
