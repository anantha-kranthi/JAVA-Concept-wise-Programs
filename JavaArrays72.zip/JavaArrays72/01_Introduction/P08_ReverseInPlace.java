/* Program 8: Reversing an array in place without using a second array */
import java.util.Arrays;

public class P08_ReverseInPlace {
    public static void main(String[] args) {
        int[] arr = {10, 20, 30, 40, 50, 60, 70};
        System.out.println("Before reversing : " + Arrays.toString(arr));

        int left = 0, right = arr.length - 1;
        while (left < right) {
            int temp = arr[left];
            arr[left] = arr[right];
            arr[right] = temp;
            left++;
            right--;
        }

        System.out.println("After reversing  : " + Arrays.toString(arr));
        System.out.println("Number of swaps performed = " + arr.length / 2);
    }
}
