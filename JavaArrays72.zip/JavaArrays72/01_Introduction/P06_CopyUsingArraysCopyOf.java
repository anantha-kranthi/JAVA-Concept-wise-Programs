/* Program 6: Copying arrays with Arrays.copyOf, copyOfRange and System.arraycopy */
import java.util.Arrays;

public class P06_CopyUsingArraysCopyOf {
    public static void main(String[] args) {
        int[] original = {5, 10, 15, 20, 25};

        int[] exact = Arrays.copyOf(original, original.length);
        int[] shorter = Arrays.copyOf(original, 3);
        int[] longer = Arrays.copyOf(original, 8);   // padded with 0
        int[] range = Arrays.copyOfRange(original, 1, 4); // index 1,2,3

        int[] viaSystem = new int[original.length];
        System.arraycopy(original, 0, viaSystem, 0, original.length);

        System.out.println("Original            : " + Arrays.toString(original));
        System.out.println("copyOf (same size)  : " + Arrays.toString(exact));
        System.out.println("copyOf (size 3)     : " + Arrays.toString(shorter));
        System.out.println("copyOf (size 8)     : " + Arrays.toString(longer));
        System.out.println("copyOfRange(1,4)    : " + Arrays.toString(range));
        System.out.println("System.arraycopy    : " + Arrays.toString(viaSystem));
    }
}
