/* Program 2: Demonstrating ArrayIndexOutOfBoundsException */
public class P02_IndexOutOfBounds {
    public static void main(String[] args) {
        int[] arr = {10, 20, 30, 40, 50};
        System.out.println("Array length = " + arr.length);
        System.out.println("Valid indices are 0 to " + (arr.length - 1));
        System.out.println("arr[4] = " + arr[4]);

        try {
            System.out.println("Now trying arr[5] ...");
            System.out.println(arr[5]);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Caught exception: " + e);
        }

        try {
            System.out.println("Now trying arr[-1] ...");
            System.out.println(arr[-1]);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Caught exception: " + e);
        }
    }
}
