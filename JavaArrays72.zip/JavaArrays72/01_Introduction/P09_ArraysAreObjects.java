/* Program 9: Demonstrating that arrays in Java are objects */
public class P09_ArraysAreObjects {
    public static void main(String[] args) {
        int[] arr1 = {1, 2, 3};
        int[] arr2 = {1, 2, 3};
        String[] strArr = new String[2];
        int[][] twoD = new int[2][3];

        System.out.println("arr1 printed directly : " + arr1);
        System.out.println("arr2 printed directly : " + arr2);
        System.out.println("(The text before @ is the type; after @ is the hash code.)");
        System.out.println();
        System.out.println("arr1.getClass().getName()      : " + arr1.getClass().getName());
        System.out.println("strArr.getClass().getName()    : " + strArr.getClass().getName());
        System.out.println("twoD.getClass().getName()      : " + twoD.getClass().getName());
        System.out.println("arr1.getClass().getSuperclass(): " + arr1.getClass().getSuperclass());
        System.out.println();
        System.out.println("arr1.hashCode() : " + arr1.hashCode());
        System.out.println("arr2.hashCode() : " + arr2.hashCode());
        System.out.println("Different hash codes => two distinct objects on the heap.");
    }
}
