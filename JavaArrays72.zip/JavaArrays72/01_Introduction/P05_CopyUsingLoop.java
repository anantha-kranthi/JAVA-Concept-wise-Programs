/* Program 5: Copying one array into another using a loop (deep copy) */
public class P05_CopyUsingLoop {
    public static void main(String[] args) {
        int[] source = {11, 22, 33, 44, 55};
        int[] target = new int[source.length];

        for (int i = 0; i < source.length; i++) {
            target[i] = source[i];
        }

        System.out.print("Source : ");
        for (int v : source) System.out.print(v + " ");
        System.out.print("\nTarget : ");
        for (int v : target) System.out.print(v + " ");

        // Prove it is an independent copy
        target[0] = 999;
        System.out.println("\n\nAfter changing target[0] to 999:");
        System.out.println("source[0] = " + source[0] + "  (unchanged)");
        System.out.println("target[0] = " + target[0]);
    }
}
