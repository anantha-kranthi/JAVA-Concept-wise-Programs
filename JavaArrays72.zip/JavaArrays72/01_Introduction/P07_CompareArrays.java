/* Program 7: Comparing two arrays using ==, Arrays.equals and a manual loop */
import java.util.Arrays;

public class P07_CompareArrays {
    public static void main(String[] args) {
        int[] a = {1, 2, 3, 4};
        int[] b = {1, 2, 3, 4};
        int[] c = {1, 2, 9, 4};
        int[] d = a;

        System.out.println("a == b            : " + (a == b) + "  (compares references, not contents)");
        System.out.println("a == d            : " + (a == d) + "  (d points to the same array)");
        System.out.println("Arrays.equals(a,b): " + Arrays.equals(a, b));
        System.out.println("Arrays.equals(a,c): " + Arrays.equals(a, c));
        System.out.println("Manual compare a,b: " + isSame(a, b));
        System.out.println("Manual compare a,c: " + isSame(a, c));
    }

    static boolean isSame(int[] x, int[] y) {
        if (x.length != y.length) return false;
        for (int i = 0; i < x.length; i++) {
            if (x[i] != y[i]) return false;
        }
        return true;
    }
}
