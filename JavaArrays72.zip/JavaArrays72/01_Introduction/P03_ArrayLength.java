/* Program 3: Finding the length of arrays using the length property */
public class P03_ArrayLength {
    public static void main(String[] args) {
        int[] numbers = {1, 2, 3, 4, 5, 6, 7};
        String[] names = {"Anu", "Bala", "Chitra"};
        double[] empty = new double[0];
        char[] letters = new char[26];

        System.out.println("numbers.length = " + numbers.length);
        System.out.println("names.length   = " + names.length);
        System.out.println("empty.length   = " + empty.length);
        System.out.println("letters.length = " + letters.length);

        System.out.println("Note: length is a FIELD for arrays (no brackets),");
        System.out.println("while length() is a METHOD for String: "
                + "\"Hello\".length() = " + "Hello".length());
    }
}
