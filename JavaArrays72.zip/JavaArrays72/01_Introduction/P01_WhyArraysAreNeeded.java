/* Program 1: Why arrays are needed - comparing separate variables with an array */
public class P01_WhyArraysAreNeeded {
    public static void main(String[] args) {
        // Approach 1: separate variables (does not scale)
        int m1 = 78, m2 = 85, m3 = 90, m4 = 66, m5 = 72;
        int total1 = m1 + m2 + m3 + m4 + m5;
        System.out.println("Using 5 separate variables, total = " + total1);

        // Approach 2: one array (scales to any size)
        int[] marks = {78, 85, 90, 66, 72};
        int total2 = 0;
        for (int i = 0; i < marks.length; i++) {
            total2 += marks[i];
        }
        System.out.println("Using an array, total = " + total2);
        System.out.println("Average = " + (double) total2 / marks.length);
        System.out.println("An array holds many values of the same type under one name,");
        System.out.println("so adding a 6th subject needs no new variable name.");
    }
}
