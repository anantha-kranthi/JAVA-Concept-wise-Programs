/* Program 10: Declaring and initializing arrays using array literal syntax */
import java.util.Arrays;

public class P10_ArrayLiteralInit {
    public static void main(String[] args) {
        int[] marks = {88, 76, 92, 65, 79};
        double[] prices = {45.50, 12.75, 99.99};
        String[] cities = {"Visakhapatnam", "Hyderabad", "Chennai"};
        boolean[] flags = {true, false, true};

        System.out.println("marks  : " + Arrays.toString(marks));
        System.out.println("prices : " + Arrays.toString(prices));
        System.out.println("cities : " + Arrays.toString(cities));
        System.out.println("flags  : " + Arrays.toString(flags));

        // The 'new' form of a literal, usable anywhere (e.g. in a method call)
        int[] extra = new int[]{7, 14, 21};
        System.out.println("extra  : " + Arrays.toString(extra));
        System.out.println("Sum of extra = " + sum(new int[]{1, 2, 3, 4}));
    }

    static int sum(int[] a) {
        int s = 0;
        for (int v : a) s += v;
        return s;
    }
}
