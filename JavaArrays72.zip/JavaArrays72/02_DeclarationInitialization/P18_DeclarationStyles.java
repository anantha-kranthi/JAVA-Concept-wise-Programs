/* Program 18: The difference between int[] arr and int arr[] declaration styles */
import java.util.Arrays;

public class P18_DeclarationStyles {
    public static void main(String[] args) {
        int[] style1 = {1, 2, 3};      // preferred Java style
        int style2[] = {4, 5, 6};      // C style, also legal
        int[] style3[] = new int[2][2]; // mixed - this is a 2D array

        System.out.println("int[] style1 : " + Arrays.toString(style1));
        System.out.println("int style2[] : " + Arrays.toString(style2));
        System.out.println("Both produce identical arrays of the same type: "
                + (style1.getClass() == style2.getClass()));

        style3[0][0] = 9;
        System.out.println("int[] style3[] is 2D : " + Arrays.deepToString(style3));

        System.out.println("\nThe difference matters in multi declarations:");
        int[] p = new int[3], q = new int[3];   // BOTH are arrays
        int r[] = new int[3], s = 5;            // r is an array, s is an int
        System.out.println("p.length=" + p.length + ", q.length=" + q.length
                + ", r.length=" + r.length + ", s=" + s);

        System.out.println("\nReturn types may also use either form:");
        System.out.println(Arrays.toString(makeArrayStyleA()));
        System.out.println(Arrays.toString(makeArrayStyleB()));
    }

    static int[] makeArrayStyleA() { return new int[]{10, 20}; }
    static int[] makeArrayStyleB() { return new int[]{30, 40}; }
}
