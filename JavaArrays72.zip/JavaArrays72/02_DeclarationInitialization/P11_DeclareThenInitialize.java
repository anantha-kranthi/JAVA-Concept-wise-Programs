/* Program 11: Declaring an array first and initializing it later using a loop */
import java.util.Arrays;

public class P11_DeclareThenInitialize {
    public static void main(String[] args) {
        int[] squares;                 // declaration only - no memory yet
        squares = new int[10];         // memory allocated, all elements are 0

        System.out.println("Immediately after allocation : " + Arrays.toString(squares));

        for (int i = 0; i < squares.length; i++) {
            squares[i] = (i + 1) * (i + 1);   // initialization inside a loop
        }

        System.out.println("After initialization         : " + Arrays.toString(squares));

        String[] days = new String[7];
        String[] source = {"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"};
        for (int i = 0; i < days.length; i++) {
            days[i] = source[i];
        }
        System.out.println("Days filled in a loop        : " + Arrays.toString(days));
    }
}
