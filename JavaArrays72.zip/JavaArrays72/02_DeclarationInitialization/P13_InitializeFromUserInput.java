/* Program 13: Initializing an array with user input using Scanner
   Sample input:  5
                  10 20 30 40 50                                  */
import java.util.Scanner;

public class P13_InitializeFromUserInput {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the number of elements: ");
        int n = sc.nextInt();

        int[] arr = new int[n];
        System.out.println("Enter " + n + " integers:");
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }

        System.out.println("\nYou entered:");
        int sum = 0;
        for (int i = 0; i < n; i++) {
            System.out.println("arr[" + i + "] = " + arr[i]);
            sum += arr[i];
        }
        System.out.println("Sum     = " + sum);
        System.out.println("Average = " + (double) sum / n);

        sc.close();
    }
}
