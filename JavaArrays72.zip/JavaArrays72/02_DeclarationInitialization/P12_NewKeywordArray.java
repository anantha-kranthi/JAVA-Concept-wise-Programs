/* Program 12: Creating arrays with the new keyword and a specified size */
import java.util.Arrays;

public class P12_NewKeywordArray {
    public static void main(String[] args) {
        int size = 6;
        int[] arr = new int[size];

        for (int i = 0; i < size; i++) {
            arr[i] = (i + 1) * 10;
        }
        System.out.println("Fixed size array of " + size + " : " + Arrays.toString(arr));

        // Size can be decided at run time
        int runtimeSize = 3 + 4;
        double[] dynamic = new double[runtimeSize];
        Arrays.fill(dynamic, 2.5);
        System.out.println("Runtime sized array      : " + Arrays.toString(dynamic));

        // A zero length array is legal
        int[] none = new int[0];
        System.out.println("Zero length array length : " + none.length);

        // A negative size compiles but fails at run time
        try {
            int[] bad = new int[-2];
            System.out.println(bad.length);
        } catch (NegativeArraySizeException e) {
            System.out.println("new int[-2] threw       : " + e);
        }
    }
}
