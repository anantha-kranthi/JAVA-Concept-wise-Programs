/* Program 17: Initializing a String array and printing each element with its index */
public class P17_StringArrayWithIndex {
    public static void main(String[] args) {
        String[] subjects = {"Mathematics", "Physics", "Chemistry",
                             "Computer Science", "English"};

        System.out.println("Index | Subject           | Characters");
        System.out.println("------+-------------------+-----------");
        for (int i = 0; i < subjects.length; i++) {
            System.out.printf("  %-3d | %-17s | %d%n",
                    i, subjects[i], subjects[i].length());
        }

        System.out.println("\nFirst element : " + subjects[0]);
        System.out.println("Last element  : " + subjects[subjects.length - 1]);

        System.out.println("\nUsing an enhanced for loop (no index available):");
        for (String s : subjects) {
            System.out.println("  " + s.toUpperCase());
        }
    }
}
