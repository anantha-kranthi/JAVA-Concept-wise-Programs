/* Program 14: Initializing a character array and printing it as a String */
import java.util.Arrays;

public class P14_CharArrayToString {
    public static void main(String[] args) {
        char[] letters = {'J', 'A', 'V', 'A'};

        System.out.print("Element by element : ");
        for (char c : letters) System.out.print(c + " ");
        System.out.println();

        // println has a special overload for char[]
        System.out.print("Using println      : ");
        System.out.println(letters);

        // Converting to a String
        String s1 = new String(letters);
        String s2 = String.valueOf(letters);
        System.out.println("new String(arr)    : " + s1);
        System.out.println("String.valueOf(arr): " + s2);

        // Going the other way: String to char[]
        char[] back = "ARRAYS".toCharArray();
        System.out.println("toCharArray()      : " + Arrays.toString(back));

        // Careful: concatenating a char[] prints the reference
        System.out.println("Concatenated       : " + letters + "  <-- prints reference, not text");
    }
}
