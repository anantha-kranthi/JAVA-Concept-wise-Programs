/* Program 16: Initializing an array with random numbers using the Random class */
import java.util.Arrays;
import java.util.Random;

public class P16_RandomArrayInit {
    public static void main(String[] args) {
        Random rand = new Random();
        int[] dice = new int[10];
        for (int i = 0; i < dice.length; i++) {
            dice[i] = rand.nextInt(6) + 1;          // 1 to 6
        }
        System.out.println("Ten dice throws  : " + Arrays.toString(dice));

        double[] reals = new double[5];
        for (int i = 0; i < reals.length; i++) {
            reals[i] = Math.round(rand.nextDouble() * 10000) / 100.0;
        }
        System.out.println("Random doubles   : " + Arrays.toString(reals));

        // A seeded Random gives the same sequence every run - handy for testing
        Random seeded = new Random(42);
        int[] repeatable = new int[8];
        for (int i = 0; i < repeatable.length; i++) {
            repeatable[i] = seeded.nextInt(100);
        }
        System.out.println("Seeded (fixed)   : " + Arrays.toString(repeatable));

        // Using Math.random() instead
        int[] viaMath = new int[5];
        for (int i = 0; i < viaMath.length; i++) {
            viaMath[i] = (int) (Math.random() * 50);
        }
        System.out.println("Math.random()    : " + Arrays.toString(viaMath));
    }
}
