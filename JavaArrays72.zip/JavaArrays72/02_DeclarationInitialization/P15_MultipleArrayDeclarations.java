/* Program 15: Declaring multiple arrays in a single statement */
import java.util.Arrays;

public class P15_MultipleArrayDeclarations {
    public static void main(String[] args) {
        // Both a and b are int arrays
        int[] a = {1, 2, 3}, b = {4, 5, 6, 7};

        // Careful: here c is an int ARRAY but d is a plain int
        int[] c = {8, 9};
        int d = 10;

        // Mixed form: e is an array (brackets after the name), f is a plain int
        int e[] = {11, 12, 13}, f = 14;

        System.out.println("a : " + Arrays.toString(a));
        System.out.println("b : " + Arrays.toString(b));
        System.out.println("c : " + Arrays.toString(c));
        System.out.println("d : " + d + "  (a simple int, not an array)");
        System.out.println("e : " + Arrays.toString(e));
        System.out.println("f : " + f + "  (a simple int, not an array)");

        String[] names = {"Ram", "Sita"}, places = {"Ayodhya", "Mithila"};
        System.out.println("names  : " + Arrays.toString(names));
        System.out.println("places : " + Arrays.toString(places));
    }
}
