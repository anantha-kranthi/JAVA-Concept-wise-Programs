# 72 Java Programs on Arrays

A complete, tested set of 72 Java programs covering the Arrays unit:
Introduction, Declaration and Initialization, Storage in Memory, Sorting,
Searching, Two-dimensional Arrays, Arrays of Varying Lengths, and
Three-dimensional Arrays.

Every program is a standalone file with a `main` method. All 72 were
compiled and executed successfully on OpenJDK 21.

## How to run

With a JDK installed (Java 11 or later):

    javac P28_BubbleSort.java
    java P28_BubbleSort

Or, with Java 11+, run the source file directly in one step:

    java P28_BubbleSort.java

The file name must match the public class name exactly.

## Programs needing keyboard input

Four programs read data with `Scanner`. Sample input is written in a
comment at the top of each file.

| File | Sample input |
|------|--------------|
| P13_InitializeFromUserInput.java | `5` then `10 20 30 40 50` |
| P51_Input2DMatrix.java | `2 3` then `1 2 3` and `4 5 6` |
| P63_InputJaggedArray.java | `3`, then `2`/`10 20`, `3`/`30 40 50`, `1`/`60` |
| P69_Input3DArray.java | `2 2 2` then `1 2 3 4 5 6 7 8` |

## Contents

### 01_Introduction
1. P01_WhyArraysAreNeeded - why arrays beat separate variables
2. P02_IndexOutOfBounds - ArrayIndexOutOfBoundsException
3. P03_ArrayLength - the length property
4. P04_DefaultValues - default values by data type
5. P05_CopyUsingLoop - copying with a loop
6. P06_CopyUsingArraysCopyOf - copyOf, copyOfRange, System.arraycopy
7. P07_CompareArrays - == versus Arrays.equals
8. P08_ReverseInPlace - reversing without a second array
9. P09_ArraysAreObjects - arrays as objects on the heap

### 02_DeclarationInitialization
10. P10_ArrayLiteralInit - array literal syntax
11. P11_DeclareThenInitialize - declare first, fill later
12. P12_NewKeywordArray - the new keyword and sizing
13. P13_InitializeFromUserInput - input with Scanner
14. P14_CharArrayToString - char arrays and Strings
15. P15_MultipleArrayDeclarations - several arrays in one statement
16. P16_RandomArrayInit - filling with Random and Math.random
17. P17_StringArrayWithIndex - String array with indices
18. P18_DeclarationStyles - int[] arr versus int arr[]

### 03_MemoryStorage
19. P19_ArrayReferenceAddress - array identity and hash codes
20. P20_ContiguousStorage - contiguous layout and address arithmetic
21. P21_SingleAllocation - one name, one memory block
22. P22_ShallowCopy - shallow versus deep copy
23. P23_ChangeThroughReference - changes seen through both references
24. P24_GarbageCollection - making an array collectable
25. P25_MemorySizeOfArray - estimating memory use
26. P26_PassByReference - arrays passed to methods
27. P27_AliasingAndClone - aliasing bugs and defensive copies

### 04_Sorting
28. P28_BubbleSort
29. P29_SelectionSort
30. P30_InsertionSort
31. P31_QuickSort
32. P32_MergeSort
33. P33_DescendingSort - three approaches
34. P34_BuiltInArraysSort - Arrays.sort and parallelSort
35. P35_SortStringArray - alphabetical and case-insensitive
36. P36_SortObjectsComparator - Comparable and Comparator
37. P37_SortEvenIndexedElements - partial sorting
38. P38_CountingSort - non-comparison sort
39. P39_CheckIfSorted - detecting sorted order

### 05_Searching
40. P40_LinearSearch
41. P41_BinarySearchIterative
42. P42_BinarySearchRecursive
43. P43_FirstOccurrence
44. P44_LastOccurrence
45. P45_FrequencyOfElement
46. P46_FindDuplicates
47. P47_BuiltInBinarySearch - Arrays.binarySearch and insertion points
48. P48_SecondLargestSmallest
49. P49_MissingNumber - sum, XOR and marker methods

### 06_TwoDimensional
50. P50_DeclareDisplay2D
51. P51_Input2DMatrix
52. P52_MatrixAddition
53. P53_MatrixSubtraction
54. P54_MatrixMultiplication
55. P55_MatrixTranspose
56. P56_DiagonalSum
57. P57_SymmetricMatrix
58. P58_Search2DArray
59. P59_RowColumnSums
60. P60_RotateMatrix90
61. P61_SpiralPrint

### 07_JaggedArrays
62. P62_DeclareJaggedArray
63. P63_InputJaggedArray
64. P64_JaggedArraySum
65. P65_LongestRowJagged
66. P66_LargestInJagged
67. P67_SortJaggedRows

### 08_ThreeDimensional
68. P68_Declare3DArray
69. P69_Input3DArray
70. P70_Sum3DArray
71. P71_Max3DArray
72. P72_RubiksCube3D
