/* Program 49: Finding the missing number in an array holding 1..N */
import java.util.Arrays;

public class P49_MissingNumber {
    public static void main(String[] args) {
        // Should contain 1..9 but one number is missing
        int[] arr = {1, 2, 3, 4, 6, 7, 8, 9};
        int n = arr.length + 1;

        System.out.println("Array  : " + Arrays.toString(arr));
        System.out.println("Should contain 1 to " + n);

        // Method 1: sum formula
        int expectedSum = n * (n + 1) / 2;
        int actualSum = 0;
        for (int v : arr) actualSum += v;
        System.out.println("\nMethod 1 (sum formula):");
        System.out.println("  expected sum = " + expectedSum + ", actual sum = " + actualSum);
        System.out.println("  missing number = " + (expectedSum - actualSum));

        // Method 2: XOR - avoids any overflow risk
        int x = 0;
        for (int i = 1; i <= n; i++) x ^= i;
        for (int v : arr) x ^= v;
        System.out.println("\nMethod 2 (XOR): missing number = " + x);

        // Method 3: boolean presence marker
        boolean[] seen = new boolean[n + 1];
        for (int v : arr) seen[v] = true;
        System.out.print("\nMethod 3 (marker array): missing = ");
        for (int i = 1; i <= n; i++) if (!seen[i]) System.out.println(i);

        // Works for more than one missing value too
        int[] arr2 = {1, 2, 5, 7, 8, 10};
        boolean[] seen2 = new boolean[11];
        for (int v : arr2) seen2[v] = true;
        System.out.print("\nFrom " + Arrays.toString(arr2) + " missing 1..10 : ");
        for (int i = 1; i <= 10; i++) if (!seen2[i]) System.out.print(i + " ");
        System.out.println();
    }
}
