/* Program 48: Finding the second largest and second smallest elements */
import java.util.Arrays;

public class P48_SecondLargestSmallest {
    public static void main(String[] args) {
        int[] arr = {45, 12, 89, 33, 89, 7, 56, 7};
        System.out.println("Array : " + Arrays.toString(arr));

        int largest = Integer.MIN_VALUE, secondLargest = Integer.MIN_VALUE;
        int smallest = Integer.MAX_VALUE, secondSmallest = Integer.MAX_VALUE;

        for (int v : arr) {
            if (v > largest) { secondLargest = largest; largest = v; }
            else if (v > secondLargest && v != largest) { secondLargest = v; }

            if (v < smallest) { secondSmallest = smallest; smallest = v; }
            else if (v < secondSmallest && v != smallest) { secondSmallest = v; }
        }

        System.out.println("\nSingle pass, O(n):");
        System.out.println("  Largest        : " + largest);
        System.out.println("  Second largest : " + secondLargest + "  (duplicates of 89 skipped)");
        System.out.println("  Smallest       : " + smallest);
        System.out.println("  Second smallest: " + secondSmallest);

        // Verification by sorting, O(n log n)
        int[] sorted = arr.clone();
        Arrays.sort(sorted);
        System.out.println("\nVerification using sorting: " + Arrays.toString(sorted));
        int i = sorted.length - 1;
        while (i > 0 && sorted[i] == sorted[sorted.length - 1]) i--;
        System.out.println("  Second largest from sorted array : " + sorted[i]);
    }
}
