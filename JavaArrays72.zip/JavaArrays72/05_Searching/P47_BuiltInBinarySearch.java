/* Program 47: Using the built-in Arrays.binarySearch() method */
import java.util.Arrays;

public class P47_BuiltInBinarySearch {
    public static void main(String[] args) {
        int[] arr = {10, 20, 30, 40, 50, 60, 70};
        System.out.println("Array : " + Arrays.toString(arr));

        System.out.println("\nbinarySearch(40) = " + Arrays.binarySearch(arr, 40)
                + "   (found at index 3)");
        System.out.println("binarySearch(10) = " + Arrays.binarySearch(arr, 10));
        System.out.println("binarySearch(45) = " + Arrays.binarySearch(arr, 45)
                + "  (negative = not found)");

        int r = Arrays.binarySearch(arr, 45);
        System.out.println("\nWhen the result is negative, the insertion point is");
        System.out.println("-(result) - 1 = " + (-(r) - 1)
                + ", i.e. 45 belongs at index " + (-(r) - 1) + " to keep the array sorted.");

        // Searching part of the array
        System.out.println("\nbinarySearch(arr, 2, 5, 50) = " + Arrays.binarySearch(arr, 2, 5, 50));

        // Works for Strings too, but the array MUST be sorted first
        String[] names = {"Deepa", "Arjun", "Meera", "Bala"};
        Arrays.sort(names);
        System.out.println("\nSorted names : " + Arrays.toString(names));
        System.out.println("binarySearch(\"Meera\") = " + Arrays.binarySearch(names, "Meera"));

        System.out.println("\nWARNING: on an UNSORTED array the result is undefined.");
        int[] unsorted = {5, 1, 9, 3};
        System.out.println("Unsorted " + Arrays.toString(unsorted)
                + " search for 9 gives " + Arrays.binarySearch(unsorted, 9) + " - unreliable");
    }
}
