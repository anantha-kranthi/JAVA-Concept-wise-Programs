/* Program 42: Binary search using recursion */
import java.util.Arrays;

public class P42_BinarySearchRecursive {
    public static void main(String[] args) {
        int[] arr = {5, 10, 15, 20, 25, 30, 35, 40};
        System.out.println("Sorted array : " + Arrays.toString(arr));

        int[] keys = {25, 5, 40, 17};
        for (int key : keys) {
            System.out.println("\nSearching for " + key + ":");
            int idx = binarySearch(arr, key, 0, arr.length - 1, 1);
            System.out.println(idx == -1 ? "  Not found"
                    : "  Found at index " + idx);
        }
    }

    static int binarySearch(int[] a, int key, int low, int high, int depth) {
        if (low > high) return -1;                       // base case: empty range

        int mid = low + (high - low) / 2;
        System.out.println("  call depth " + depth + ": range [" + low + ".." + high
                + "], mid=" + mid + ", a[mid]=" + a[mid]);

        if (a[mid] == key) return mid;                   // base case: found
        if (a[mid] < key) return binarySearch(a, key, mid + 1, high, depth + 1);
        return binarySearch(a, key, low, mid - 1, depth + 1);
    }
}
