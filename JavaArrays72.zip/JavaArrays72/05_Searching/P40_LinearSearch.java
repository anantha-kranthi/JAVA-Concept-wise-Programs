/* Program 40: Linear (sequential) search */
import java.util.Arrays;

public class P40_LinearSearch {
    public static void main(String[] args) {
        int[] arr = {34, 78, 12, 99, 45, 67, 23};
        System.out.println("Array : " + Arrays.toString(arr));

        search(arr, 99);
        search(arr, 34);
        search(arr, 23);
        search(arr, 55);

        System.out.println("\nLinear search works on unsorted data.");
        System.out.println("Best case O(1), worst case O(n), average O(n/2).");
    }

    static void search(int[] a, int key) {
        int comparisons = 0, position = -1;
        for (int i = 0; i < a.length; i++) {
            comparisons++;
            if (a[i] == key) { position = i; break; }
        }
        if (position != -1) {
            System.out.println("Key " + key + " found at index " + position
                    + " after " + comparisons + " comparison(s)");
        } else {
            System.out.println("Key " + key + " not found after "
                    + comparisons + " comparison(s)");
        }
    }
}
