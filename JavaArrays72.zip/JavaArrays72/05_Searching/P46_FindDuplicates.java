/* Program 46: Finding all duplicate elements in an array */
import java.util.Arrays;

public class P46_FindDuplicates {
    public static void main(String[] args) {
        int[] arr = {4, 9, 2, 4, 7, 9, 1, 2, 4};
        System.out.println("Array : " + Arrays.toString(arr));

        System.out.println("\nMethod 1 - nested loops:");
        boolean[] reported = new boolean[arr.length];
        boolean any = false;
        for (int i = 0; i < arr.length; i++) {
            if (reported[i]) continue;
            int c = 1;
            for (int j = i + 1; j < arr.length; j++) {
                if (arr[i] == arr[j]) { c++; reported[j] = true; }
            }
            if (c > 1) { System.out.println("  " + arr[i] + " repeated " + c + " times"); any = true; }
        }
        if (!any) System.out.println("  no duplicates");

        System.out.println("\nMethod 2 - sort first, then compare neighbours:");
        int[] sorted = arr.clone();
        Arrays.sort(sorted);
        System.out.println("  sorted: " + Arrays.toString(sorted));
        for (int i = 1; i < sorted.length; i++) {
            if (sorted[i] == sorted[i - 1] && (i < 2 || sorted[i] != sorted[i - 2])) {
                System.out.println("  duplicate found: " + sorted[i]);
            }
        }

        System.out.println("\nUnique elements only:");
        for (int i = 0; i < sorted.length; i++) {
            if (i == 0 || sorted[i] != sorted[i - 1]) System.out.print(sorted[i] + " ");
        }
        System.out.println();
    }
}
