/* Program 44: Finding the index of the last occurrence of an element */
import java.util.Arrays;

public class P44_LastOccurrence {
    public static void main(String[] args) {
        int[] arr = {3, 8, 5, 8, 1, 8, 6};
        System.out.println("Array : " + Arrays.toString(arr));

        System.out.println("\nLast occurrence of 8 (scan backwards) : " + lastBackward(arr, 8));
        System.out.println("Last occurrence of 8 (scan forwards)  : " + lastForward(arr, 8));
        System.out.println("Last occurrence of 3                  : " + lastBackward(arr, 3));
        System.out.println("Last occurrence of 99                 : " + lastBackward(arr, 99));

        int[] sorted = {2, 4, 4, 4, 6, 8, 8};
        System.out.println("\nSorted array : " + Arrays.toString(sorted));
        System.out.println("Last occurrence of 4 (binary) : " + lastBinary(sorted, 4));
        System.out.println("Count of 4 = last - first + 1 = "
                + (lastBinary(sorted, 4) - 1 + 1));
    }

    static int lastBackward(int[] a, int key) {
        for (int i = a.length - 1; i >= 0; i--) if (a[i] == key) return i;
        return -1;
    }

    static int lastForward(int[] a, int key) {
        int pos = -1;
        for (int i = 0; i < a.length; i++) if (a[i] == key) pos = i;
        return pos;
    }

    static int lastBinary(int[] a, int key) {
        int low = 0, high = a.length - 1, result = -1;
        while (low <= high) {
            int mid = low + (high - low) / 2;
            if (a[mid] == key) { result = mid; low = mid + 1; }
            else if (a[mid] < key) low = mid + 1;
            else high = mid - 1;
        }
        return result;
    }
}
