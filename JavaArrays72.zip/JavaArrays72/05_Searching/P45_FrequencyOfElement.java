/* Program 45: Counting the frequency of elements in an array */
import java.util.Arrays;

public class P45_FrequencyOfElement {
    public static void main(String[] args) {
        int[] arr = {5, 2, 8, 5, 2, 5, 9, 1, 2, 5};
        System.out.println("Array : " + Arrays.toString(arr));

        int key = 5;
        int count = 0;
        for (int v : arr) if (v == key) count++;
        System.out.println("\nFrequency of " + key + " = " + count);

        System.out.println("\nFrequency of every distinct element:");
        boolean[] counted = new boolean[arr.length];
        for (int i = 0; i < arr.length; i++) {
            if (counted[i]) continue;
            int c = 1;
            for (int j = i + 1; j < arr.length; j++) {
                if (arr[i] == arr[j]) { c++; counted[j] = true; }
            }
            System.out.println("  " + arr[i] + " occurs " + c + " time(s)");
        }

        // Highest frequency element
        int best = arr[0], bestCount = 0;
        for (int i = 0; i < arr.length; i++) {
            int c = 0;
            for (int v : arr) if (v == arr[i]) c++;
            if (c > bestCount) { bestCount = c; best = arr[i]; }
        }
        System.out.println("\nMost frequent element : " + best + " (" + bestCount + " times)");
    }
}
