/* Program 43: Finding the index of the first occurrence of an element */
import java.util.Arrays;

public class P43_FirstOccurrence {
    public static void main(String[] args) {
        int[] arr = {4, 7, 2, 7, 9, 7, 1, 2};
        System.out.println("Array : " + Arrays.toString(arr));

        System.out.println("\nFirst occurrence of 7 (linear) : " + firstLinear(arr, 7));
        System.out.println("First occurrence of 2 (linear) : " + firstLinear(arr, 2));
        System.out.println("First occurrence of 5 (linear) : " + firstLinear(arr, 5));

        int[] sorted = {1, 2, 2, 2, 5, 7, 7, 9};
        System.out.println("\nSorted array : " + Arrays.toString(sorted));
        System.out.println("First occurrence of 2 (binary) : " + firstBinary(sorted, 2));
        System.out.println("First occurrence of 7 (binary) : " + firstBinary(sorted, 7));
    }

    static int firstLinear(int[] a, int key) {
        for (int i = 0; i < a.length; i++) if (a[i] == key) return i;
        return -1;
    }

    /* On sorted data, keep moving left even after a match */
    static int firstBinary(int[] a, int key) {
        int low = 0, high = a.length - 1, result = -1;
        while (low <= high) {
            int mid = low + (high - low) / 2;
            if (a[mid] == key) { result = mid; high = mid - 1; }
            else if (a[mid] < key) low = mid + 1;
            else high = mid - 1;
        }
        return result;
    }
}
