/* Program 41: Binary search on a sorted array - iterative version */
import java.util.Arrays;

public class P41_BinarySearchIterative {
    public static void main(String[] args) {
        int[] arr = {11, 22, 33, 44, 55, 66, 77, 88, 99};
        System.out.println("Sorted array : " + Arrays.toString(arr));

        System.out.println("\nSearching for 66:");
        System.out.println("Result index = " + binarySearch(arr, 66));
        System.out.println("\nSearching for 11:");
        System.out.println("Result index = " + binarySearch(arr, 11));
        System.out.println("\nSearching for 50 (absent):");
        System.out.println("Result index = " + binarySearch(arr, 50));

        System.out.println("\nO(log n): 9 elements need at most 4 comparisons,");
        System.out.println("1,000,000 elements need at most 20.");
    }

    static int binarySearch(int[] a, int key) {
        int low = 0, high = a.length - 1, step = 0;
        while (low <= high) {
            int mid = low + (high - low) / 2;   // avoids integer overflow
            step++;
            System.out.println("  step " + step + ": low=" + low + " mid=" + mid
                    + " high=" + high + " a[mid]=" + a[mid]);
            if (a[mid] == key) return mid;
            if (a[mid] < key) low = mid + 1;
            else high = mid - 1;
        }
        return -1;
    }
}
