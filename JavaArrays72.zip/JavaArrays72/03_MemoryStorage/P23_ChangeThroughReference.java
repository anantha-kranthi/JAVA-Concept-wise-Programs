/* Program 23: Modifying an array through one reference is visible through the other */
import java.util.Arrays;

public class P23_ChangeThroughReference {
    public static void main(String[] args) {
        String[] teamA = {"Ravi", "Kiran", "Meena"};
        String[] teamB = teamA;

        System.out.println("teamA : " + Arrays.toString(teamA));
        System.out.println("teamB : " + Arrays.toString(teamB));

        teamB[1] = "Sneha";
        System.out.println("\nAfter teamB[1] = \"Sneha\":");
        System.out.println("teamA : " + Arrays.toString(teamA) + "  <-- also changed");
        System.out.println("teamB : " + Arrays.toString(teamB));

        teamA[2] = "Gopal";
        System.out.println("\nAfter teamA[2] = \"Gopal\":");
        System.out.println("teamA : " + Arrays.toString(teamA));
        System.out.println("teamB : " + Arrays.toString(teamB) + "  <-- also changed");

        // Re-pointing one reference breaks the link
        teamB = new String[]{"X", "Y", "Z"};
        System.out.println("\nAfter teamB = new String[]{...}:");
        System.out.println("teamA : " + Arrays.toString(teamA) + "  (untouched)");
        System.out.println("teamB : " + Arrays.toString(teamB) + "  (now a separate object)");
    }
}
