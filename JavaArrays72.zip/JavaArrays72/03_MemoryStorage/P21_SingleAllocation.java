/* Program 21: One array name refers to one block of allocated memory */
public class P21_SingleAllocation {
    public static void main(String[] args) {
        int[] arr = new int[5];
        System.out.println("Created arr -> " + arr);

        for (int i = 0; i < arr.length; i++) arr[i] = i * 100;
        System.out.print("Contents : ");
        for (int v : arr) System.out.print(v + " ");
        System.out.println("\nReference after filling -> " + arr
                + "   (unchanged: same block reused)");

        // Re-assigning with new allocates a DIFFERENT block
        arr = new int[5];
        System.out.println("After arr = new int[5] -> " + arr
                + "   (a new block; old values are gone)");
        System.out.print("Contents now : ");
        for (int v : arr) System.out.print(v + " ");

        System.out.println("\n\nArrays cannot grow. Enlarging means allocating a new block");
        System.out.println("and copying the old contents into it:");
        int[] small = {1, 2, 3};
        int[] big = new int[6];
        System.arraycopy(small, 0, big, 0, small.length);
        System.out.print("Enlarged : ");
        for (int v : big) System.out.print(v + " ");
        System.out.println();
    }
}
