/* Program 19: Printing the reference (identity) of an array object */
public class P19_ArrayReferenceAddress {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3};
        int[] other = {1, 2, 3};

        System.out.println("Default toString()      : " + arr);
        System.out.println("Type descriptor          : " + arr.getClass().getName()
                + "   ([I means array of int)");
        System.out.println("hashCode() in decimal    : " + arr.hashCode());
        System.out.println("hashCode() in hex        : " + Integer.toHexString(arr.hashCode()));
        System.out.println("System.identityHashCode  : " + System.identityHashCode(arr));
        System.out.println();
        System.out.println("A second array with the same contents:");
        System.out.println("other                    : " + other);
        System.out.println("Same identity?           : " + (System.identityHashCode(arr)
                == System.identityHashCode(other)));
        System.out.println();
        System.out.println("Java hides real addresses for safety. The hash code is only");
        System.out.println("a stand-in that lets us tell one object from another.");
    }
}
