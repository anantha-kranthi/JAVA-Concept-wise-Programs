/* Program 24: Making an array eligible for garbage collection */
public class P24_GarbageCollection {
    public static void main(String[] args) {
        Runtime rt = Runtime.getRuntime();

        System.out.println("Free memory before  : " + rt.freeMemory() / 1024 + " KB");

        int[] bigArray = new int[5_000_000];      // about 20 MB
        for (int i = 0; i < bigArray.length; i++) bigArray[i] = i;
        System.out.println("Allocated 5,000,000 ints. bigArray[999] = " + bigArray[999]);
        System.out.println("Free memory after   : " + rt.freeMemory() / 1024 + " KB");

        bigArray = null;   // the only reference is dropped -> object is now garbage
        System.out.println("\nbigArray set to null. The array object is now unreachable.");

        System.gc();       // a REQUEST, not a command
        try { Thread.sleep(200); } catch (InterruptedException e) { }

        System.out.println("Free memory after gc: " + rt.freeMemory() / 1024 + " KB");
        System.out.println("\nNote: System.gc() only suggests collection. The JVM decides");
        System.out.println("when to actually reclaim the memory.");
    }
}
