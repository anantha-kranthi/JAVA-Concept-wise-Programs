/* Program 22: Shallow copy - two references pointing at the same array */
import java.util.Arrays;

public class P22_ShallowCopy {
    public static void main(String[] args) {
        int[] original = {1, 2, 3, 4, 5};
        int[] shallow = original;                       // NO new array is created
        int[] deep = Arrays.copyOf(original, original.length); // a real copy

        System.out.println("original reference : " + original);
        System.out.println("shallow reference  : " + shallow + "  <-- same as original");
        System.out.println("deep reference     : " + deep + "  <-- different");
        System.out.println("original == shallow : " + (original == shallow));
        System.out.println("original == deep    : " + (original == deep));

        shallow[0] = 500;
        deep[1] = 900;

        System.out.println("\nAfter shallow[0]=500 and deep[1]=900:");
        System.out.println("original : " + Arrays.toString(original));
        System.out.println("shallow  : " + Arrays.toString(shallow));
        System.out.println("deep     : " + Arrays.toString(deep));
        System.out.println("\nThe change through 'shallow' is visible in 'original'");
        System.out.println("because only one array object exists on the heap.");
    }
}
