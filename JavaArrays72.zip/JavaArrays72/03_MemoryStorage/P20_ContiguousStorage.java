/* Program 20: Contiguous memory storage and address arithmetic of an array */
public class P20_ContiguousStorage {
    public static void main(String[] args) {
        int[] arr = {10, 20, 30, 40, 50};
        int bytesPerInt = 4;                 // an int is always 4 bytes in Java
        long baseAddress = 1000;             // an assumed starting address

        System.out.println("Array elements sit one after another in memory.");
        System.out.println("Formula: address(arr[i]) = base + i * sizeof(element)\n");
        System.out.println("Index |  Value | Assumed address");
        System.out.println("------+--------+----------------");
        for (int i = 0; i < arr.length; i++) {
            long addr = baseAddress + (long) i * bytesPerInt;
            System.out.printf("  %-3d |  %-5d | %d%n", i, arr[i], addr);
        }
        System.out.println("\nTotal element storage = " + (arr.length * bytesPerInt) + " bytes");
        System.out.println("Because addresses are computable, arr[i] is an O(1) operation:");
        System.out.println("the JVM jumps straight to the slot instead of walking the array.");

        long t = System.nanoTime();
        int v = arr[4];
        System.out.println("Reading arr[4] = " + v + " took about "
                + (System.nanoTime() - t) + " ns");
    }
}
