/* Program 27: Array aliasing problems and how clone() avoids them */
import java.util.Arrays;

public class P27_AliasingAndClone {
    public static void main(String[] args) {
        int[] scores = {50, 60, 70, 80};

        // PROBLEM: an alias lets outside code corrupt our data
        int[] alias = scores;
        alias[0] = -1;
        System.out.println("Aliased  : " + Arrays.toString(scores) + "  <-- corrupted");

        // FIX: hand out a clone instead
        int[] scores2 = {50, 60, 70, 80};
        int[] safeCopy = scores2.clone();
        safeCopy[0] = -1;
        System.out.println("Cloned   : " + Arrays.toString(scores2) + "  <-- protected");

        // clone() on a 2D array is still SHALLOW for the inner rows
        int[][] matrix = {{1, 2}, {3, 4}};
        int[][] shallow2D = matrix.clone();
        shallow2D[0][0] = 100;
        System.out.println("\n2D clone()      : " + Arrays.deepToString(matrix)
                + "  <-- inner row shared!");

        int[][] matrix2 = {{1, 2}, {3, 4}};
        int[][] deep2D = new int[matrix2.length][];
        for (int i = 0; i < matrix2.length; i++) deep2D[i] = matrix2[i].clone();
        deep2D[0][0] = 100;
        System.out.println("2D deep copy    : " + Arrays.deepToString(matrix2)
                + "  <-- safe");

        System.out.println("\nSafe getter demo:");
        Marks m = new Marks(new int[]{10, 20, 30});
        int[] got = m.getMarks();
        got[0] = 999;
        System.out.println("Internal data still : " + Arrays.toString(m.getMarks()));
    }
}

class Marks {
    private final int[] marks;
    Marks(int[] marks) { this.marks = marks.clone(); }   // defensive copy in
    int[] getMarks() { return marks.clone(); }           // defensive copy out
}
