/* Program 25: Estimating the memory occupied by an array */
public class P25_MemorySizeOfArray {
    public static void main(String[] args) {
        int n = 100;
        int headerBytes = 16;   // typical object header + length field for a 64-bit JVM

        System.out.println("Bytes per element (Java guarantees these sizes):");
        System.out.println("  byte=1  short=2  char=2  int=4  float=4  long=8  double=8  boolean=1*");
        System.out.println("  (*boolean is typically stored as 1 byte in an array)\n");

        report("byte",    n, 1, headerBytes);
        report("short",   n, 2, headerBytes);
        report("char",    n, 2, headerBytes);
        report("int",     n, 4, headerBytes);
        report("float",   n, 4, headerBytes);
        report("long",    n, 8, headerBytes);
        report("double",  n, 8, headerBytes);
        report("boolean", n, 1, headerBytes);

        System.out.println("\nCross-check with the JVM:");
        Runtime rt = Runtime.getRuntime();
        long before = rt.totalMemory() - rt.freeMemory();
        long[] probe = new long[1_000_000];
        probe[0] = 1;
        long after = rt.totalMemory() - rt.freeMemory();
        System.out.println("long[1000000] expected ~ " + (1_000_000L * 8 / 1024) + " KB");
        System.out.println("measured increase      ~ " + (after - before) / 1024 + " KB");
    }

    static void report(String type, int n, int size, int header) {
        long total = (long) n * size + header;
        System.out.printf("%-8s[%d] : %d * %d = %d bytes of data + %d header = %d bytes (%.2f KB)%n",
                type, n, n, size, (long) n * size, header, total, total / 1024.0);
    }
}
