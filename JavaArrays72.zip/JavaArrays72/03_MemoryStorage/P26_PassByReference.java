/* Program 26: How arrays behave when passed to a method */
import java.util.Arrays;

public class P26_PassByReference {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5};
        System.out.println("Before modifyElements : " + Arrays.toString(arr));
        modifyElements(arr);
        System.out.println("After  modifyElements : " + Arrays.toString(arr)
                + "  <-- caller sees the change");

        System.out.println();
        int[] arr2 = {1, 2, 3};
        System.out.println("Before reassign       : " + Arrays.toString(arr2));
        reassign(arr2);
        System.out.println("After  reassign       : " + Arrays.toString(arr2)
                + "  <-- caller does NOT see it");

        System.out.println();
        int x = 10;
        System.out.println("Before modifyPrimitive: x = " + x);
        modifyPrimitive(x);
        System.out.println("After  modifyPrimitive: x = " + x + "  <-- primitives are copied");

        System.out.println("\nJava is always pass-by-value. For an array, the VALUE copied");
        System.out.println("is the reference, so the method reaches the same object.");
    }

    static void modifyElements(int[] a) {
        for (int i = 0; i < a.length; i++) a[i] *= 10;
    }

    static void reassign(int[] a) {
        a = new int[]{99, 99, 99};   // only the local copy of the reference moves
        System.out.println("  inside reassign     : " + Arrays.toString(a));
    }

    static void modifyPrimitive(int v) {
        v = 999;
    }
}
