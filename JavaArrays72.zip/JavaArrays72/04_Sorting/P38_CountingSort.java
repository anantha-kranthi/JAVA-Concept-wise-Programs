/* Program 38: Counting Sort - a non-comparison sort for small integer ranges */
import java.util.Arrays;

public class P38_CountingSort {
    public static void main(String[] args) {
        int[] arr = {4, 2, 2, 8, 3, 3, 1, 8, 0, 5};
        System.out.println("Original : " + Arrays.toString(arr));

        int max = arr[0], min = arr[0];
        for (int v : arr) {
            if (v > max) max = v;
            if (v < min) min = v;
        }
        System.out.println("Range    : " + min + " to " + max);

        int[] count = new int[max - min + 1];
        for (int v : arr) count[v - min]++;
        System.out.println("Counts   : " + Arrays.toString(count));

        int index = 0;
        for (int i = 0; i < count.length; i++) {
            while (count[i]-- > 0) arr[index++] = i + min;
        }

        System.out.println("Sorted   : " + Arrays.toString(arr));
        System.out.println("Time O(n + k) where k is the value range - beats O(n log n)");
        System.out.println("when k is small, but wastes memory when the range is huge.");
    }
}
