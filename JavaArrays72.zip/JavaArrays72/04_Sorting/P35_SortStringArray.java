/* Program 35: Sorting a String array alphabetically */
import java.util.Arrays;

public class P35_SortStringArray {
    public static void main(String[] args) {
        String[] names = {"banana", "Apple", "cherry", "apple", "Banana", "date"};
        System.out.println("Original            : " + Arrays.toString(names));

        String[] natural = names.clone();
        Arrays.sort(natural);
        System.out.println("Natural (ASCII)     : " + Arrays.toString(natural));
        System.out.println("  Uppercase comes first because 'A'=65 but 'a'=97.");

        String[] ignoreCase = names.clone();
        Arrays.sort(ignoreCase, String.CASE_INSENSITIVE_ORDER);
        System.out.println("Case insensitive    : " + Arrays.toString(ignoreCase));

        String[] byLength = names.clone();
        Arrays.sort(byLength, (x, y) -> x.length() - y.length());
        System.out.println("By length           : " + Arrays.toString(byLength));

        // Manual bubble sort using compareTo, no library sorting
        String[] manual = names.clone();
        for (int i = 0; i < manual.length - 1; i++) {
            for (int j = 0; j < manual.length - 1 - i; j++) {
                if (manual[j].compareToIgnoreCase(manual[j + 1]) > 0) {
                    String t = manual[j]; manual[j] = manual[j + 1]; manual[j + 1] = t;
                }
            }
        }
        System.out.println("Manual compareTo    : " + Arrays.toString(manual));
    }
}
