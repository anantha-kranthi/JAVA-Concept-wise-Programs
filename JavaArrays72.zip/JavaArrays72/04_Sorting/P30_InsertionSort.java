/* Program 30: Insertion Sort */
import java.util.Arrays;

public class P30_InsertionSort {
    public static void main(String[] args) {
        int[] arr = {12, 11, 13, 5, 6};
        System.out.println("Original : " + Arrays.toString(arr));

        for (int i = 1; i < arr.length; i++) {
            int key = arr[i];
            int j = i - 1;
            while (j >= 0 && arr[j] > key) {   // shift larger elements right
                arr[j + 1] = arr[j];
                j--;
            }
            arr[j + 1] = key;
            System.out.println("Insert " + key + " : " + Arrays.toString(arr));
        }
        System.out.println("Sorted   : " + Arrays.toString(arr));
        System.out.println("Time complexity: best O(n) on nearly sorted data, worst O(n^2).");
        System.out.println("This is how most people sort playing cards in hand.");
    }
}
