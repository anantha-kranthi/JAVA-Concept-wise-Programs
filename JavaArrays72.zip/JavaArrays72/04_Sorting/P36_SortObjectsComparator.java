/* Program 36: Sorting an array of objects using Comparable and Comparator */
import java.util.Arrays;
import java.util.Comparator;

public class P36_SortObjectsComparator {
    public static void main(String[] args) {
        Student[] students = {
            new Student(103, "Kiran", 78.5),
            new Student(101, "Anita", 91.0),
            new Student(105, "Bhanu", 78.5),
            new Student(102, "Deepak", 65.25)
        };

        System.out.println("Original order:");
        print(students);

        Student[] byRoll = students.clone();
        Arrays.sort(byRoll);                       // uses Comparable (roll number)
        System.out.println("\nSorted by roll number (Comparable):");
        print(byRoll);

        Student[] byName = students.clone();
        Arrays.sort(byName, Comparator.comparing(s -> s.name));
        System.out.println("\nSorted by name (Comparator):");
        print(byName);

        Student[] byMarks = students.clone();
        Arrays.sort(byMarks, Comparator.comparingDouble((Student s) -> s.marks).reversed()
                                       .thenComparing(s -> s.name));
        System.out.println("\nSorted by marks descending, then name:");
        print(byMarks);
    }

    static void print(Student[] arr) {
        for (Student s : arr) System.out.println("   " + s);
    }
}

class Student implements Comparable<Student> {
    int roll;
    String name;
    double marks;

    Student(int roll, String name, double marks) {
        this.roll = roll; this.name = name; this.marks = marks;
    }

    public int compareTo(Student other) {
        return Integer.compare(this.roll, other.roll);
    }

    public String toString() {
        return String.format("Roll %d | %-7s | %.2f", roll, name, marks);
    }
}
