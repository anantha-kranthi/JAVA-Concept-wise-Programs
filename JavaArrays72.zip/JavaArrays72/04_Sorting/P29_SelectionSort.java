/* Program 29: Selection Sort */
import java.util.Arrays;

public class P29_SelectionSort {
    public static void main(String[] args) {
        int[] arr = {29, 10, 14, 37, 13, 5};
        System.out.println("Original : " + Arrays.toString(arr));

        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < n; j++) {
                if (arr[j] < arr[minIndex]) minIndex = j;
            }
            if (minIndex != i) {
                int t = arr[i];
                arr[i] = arr[minIndex];
                arr[minIndex] = t;
            }
            System.out.println("Step " + (i + 1) + "   : " + Arrays.toString(arr)
                    + "   (placed " + arr[i] + " at index " + i + ")");
        }
        System.out.println("Sorted   : " + Arrays.toString(arr));
        System.out.println("Time complexity: O(n^2) always. Minimum number of swaps: n-1.");
    }
}
