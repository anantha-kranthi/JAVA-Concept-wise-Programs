/* Program 31: Quick Sort (Lomuto partition scheme) */
import java.util.Arrays;

public class P31_QuickSort {
    public static void main(String[] args) {
        int[] arr = {10, 7, 8, 9, 1, 5, 33, 2};
        System.out.println("Original : " + Arrays.toString(arr));
        quickSort(arr, 0, arr.length - 1);
        System.out.println("Sorted   : " + Arrays.toString(arr));
        System.out.println("Average O(n log n), worst O(n^2). In-place, not stable.");
    }

    static void quickSort(int[] a, int low, int high) {
        if (low < high) {
            int p = partition(a, low, high);
            System.out.println("  pivot " + a[p] + " fixed at index " + p
                    + " -> " + Arrays.toString(a));
            quickSort(a, low, p - 1);
            quickSort(a, p + 1, high);
        }
    }

    static int partition(int[] a, int low, int high) {
        int pivot = a[high];
        int i = low - 1;
        for (int j = low; j < high; j++) {
            if (a[j] <= pivot) {
                i++;
                int t = a[i]; a[i] = a[j]; a[j] = t;
            }
        }
        int t = a[i + 1]; a[i + 1] = a[high]; a[high] = t;
        return i + 1;
    }
}
