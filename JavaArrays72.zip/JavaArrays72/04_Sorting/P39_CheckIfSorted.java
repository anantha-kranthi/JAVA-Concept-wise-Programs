/* Program 39: Checking whether an array is already sorted */
import java.util.Arrays;

public class P39_CheckIfSorted {
    public static void main(String[] args) {
        int[] a = {1, 2, 3, 4, 5};
        int[] b = {5, 4, 3, 2, 1};
        int[] c = {1, 3, 2, 4, 5};
        int[] d = {7, 7, 7, 7};
        int[] e = {42};

        test(a); test(b); test(c); test(d); test(e);
    }

    static void test(int[] arr) {
        System.out.printf("%-18s ascending=%-5s descending=%-5s verdict: %s%n",
                Arrays.toString(arr), isAscending(arr), isDescending(arr), verdict(arr));
    }

    static boolean isAscending(int[] a) {
        for (int i = 1; i < a.length; i++) if (a[i] < a[i - 1]) return false;
        return true;
    }

    static boolean isDescending(int[] a) {
        for (int i = 1; i < a.length; i++) if (a[i] > a[i - 1]) return false;
        return true;
    }

    static String verdict(int[] a) {
        boolean up = isAscending(a), down = isDescending(a);
        if (up && down) return "all elements equal / single element";
        if (up) return "sorted ascending";
        if (down) return "sorted descending";
        return "not sorted";
    }
}
