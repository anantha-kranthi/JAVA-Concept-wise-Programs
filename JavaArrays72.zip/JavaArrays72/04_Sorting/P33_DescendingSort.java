/* Program 33: Sorting an array in descending order (three different ways) */
import java.util.Arrays;
import java.util.Collections;

public class P33_DescendingSort {
    public static void main(String[] args) {
        int[] a = {45, 12, 78, 3, 56, 29};
        System.out.println("Original            : " + Arrays.toString(a));

        // Method 1: modified bubble sort with the comparison flipped
        int[] m1 = a.clone();
        for (int i = 0; i < m1.length - 1; i++) {
            for (int j = 0; j < m1.length - 1 - i; j++) {
                if (m1[j] < m1[j + 1]) {
                    int t = m1[j]; m1[j] = m1[j + 1]; m1[j + 1] = t;
                }
            }
        }
        System.out.println("Bubble descending   : " + Arrays.toString(m1));

        // Method 2: sort ascending then reverse
        int[] m2 = a.clone();
        Arrays.sort(m2);
        for (int i = 0, j = m2.length - 1; i < j; i++, j--) {
            int t = m2[i]; m2[i] = m2[j]; m2[j] = t;
        }
        System.out.println("Sort then reverse   : " + Arrays.toString(m2));

        // Method 3: Integer[] with Collections.reverseOrder()
        Integer[] boxed = {45, 12, 78, 3, 56, 29};
        Arrays.sort(boxed, Collections.reverseOrder());
        System.out.println("reverseOrder()      : " + Arrays.toString(boxed));
        System.out.println("(A Comparator needs objects, so int[] will not work directly.)");
    }
}
