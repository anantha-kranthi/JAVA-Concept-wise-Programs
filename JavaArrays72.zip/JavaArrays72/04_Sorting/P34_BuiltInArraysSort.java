/* Program 34: Using the built-in Arrays.sort() method */
import java.util.Arrays;

public class P34_BuiltInArraysSort {
    public static void main(String[] args) {
        int[] nums = {50, 20, 80, 10, 60, 30};
        Arrays.sort(nums);
        System.out.println("Full sort        : " + Arrays.toString(nums));

        // Sorting only part of an array: [fromIndex, toIndex)
        int[] partial = {9, 8, 7, 6, 5, 4, 3};
        Arrays.sort(partial, 1, 5);
        System.out.println("Sort index 1 to 4: " + Arrays.toString(partial));

        double[] prices = {12.5, 3.75, 99.9, 0.5};
        Arrays.sort(prices);
        System.out.println("Doubles          : " + Arrays.toString(prices));

        char[] chars = {'d', 'a', 'z', 'm'};
        Arrays.sort(chars);
        System.out.println("Chars            : " + Arrays.toString(chars));

        // Parallel sort helps on very large arrays
        int[] big = new int[20];
        for (int i = 0; i < big.length; i++) big[i] = (i * 37) % 20;
        Arrays.parallelSort(big);
        System.out.println("parallelSort     : " + Arrays.toString(big));

        System.out.println("\nArrays.sort uses dual-pivot quicksort for primitives");
        System.out.println("and TimSort (a stable merge sort) for objects.");
    }
}
