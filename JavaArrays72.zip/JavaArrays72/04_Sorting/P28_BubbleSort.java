/* Program 28: Bubble Sort */
import java.util.Arrays;

public class P28_BubbleSort {
    public static void main(String[] args) {
        int[] arr = {64, 34, 25, 12, 22, 11, 90};
        System.out.println("Original : " + Arrays.toString(arr));

        int n = arr.length;
        for (int pass = 0; pass < n - 1; pass++) {
            boolean swapped = false;
            for (int j = 0; j < n - 1 - pass; j++) {
                if (arr[j] > arr[j + 1]) {
                    int t = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = t;
                    swapped = true;
                }
            }
            System.out.println("Pass " + (pass + 1) + "   : " + Arrays.toString(arr));
            if (!swapped) {                 // already sorted, stop early
                System.out.println("No swaps in this pass - array is sorted.");
                break;
            }
        }
        System.out.println("Sorted   : " + Arrays.toString(arr));
        System.out.println("Time complexity: best O(n), average/worst O(n^2). Stable.");
    }
}
