/* Program 32: Merge Sort */
import java.util.Arrays;

public class P32_MergeSort {
    public static void main(String[] args) {
        int[] arr = {38, 27, 43, 3, 9, 82, 10};
        System.out.println("Original : " + Arrays.toString(arr));
        mergeSort(arr, 0, arr.length - 1);
        System.out.println("Sorted   : " + Arrays.toString(arr));
        System.out.println("Always O(n log n). Stable, but needs O(n) extra space.");
    }

    static void mergeSort(int[] a, int left, int right) {
        if (left < right) {
            int mid = left + (right - left) / 2;
            mergeSort(a, left, mid);
            mergeSort(a, mid + 1, right);
            merge(a, left, mid, right);
        }
    }

    static void merge(int[] a, int left, int mid, int right) {
        int[] leftPart = Arrays.copyOfRange(a, left, mid + 1);
        int[] rightPart = Arrays.copyOfRange(a, mid + 1, right + 1);

        int i = 0, j = 0, k = left;
        while (i < leftPart.length && j < rightPart.length) {
            a[k++] = (leftPart[i] <= rightPart[j]) ? leftPart[i++] : rightPart[j++];
        }
        while (i < leftPart.length) a[k++] = leftPart[i++];
        while (j < rightPart.length) a[k++] = rightPart[j++];

        System.out.println("  merged " + Arrays.toString(leftPart) + " + "
                + Arrays.toString(rightPart) + " -> "
                + Arrays.toString(Arrays.copyOfRange(a, left, right + 1)));
    }
}
