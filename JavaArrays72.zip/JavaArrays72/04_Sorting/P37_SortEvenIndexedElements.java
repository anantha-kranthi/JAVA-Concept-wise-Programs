/* Program 37: Sorting only the even-indexed elements, leaving odd indices untouched */
import java.util.Arrays;

public class P37_SortEvenIndexedElements {
    public static void main(String[] args) {
        int[] arr = {50, 3, 20, 9, 70, 1, 10, 7, 40};
        System.out.println("Original          : " + Arrays.toString(arr));
        System.out.println("Even-index values : positions 0,2,4,6,8");

        // Extract even-indexed values
        int count = (arr.length + 1) / 2;
        int[] evens = new int[count];
        int k = 0;
        for (int i = 0; i < arr.length; i += 2) evens[k++] = arr[i];
        System.out.println("Extracted         : " + Arrays.toString(evens));

        Arrays.sort(evens);
        System.out.println("Sorted            : " + Arrays.toString(evens));

        // Put them back
        k = 0;
        for (int i = 0; i < arr.length; i += 2) arr[i] = evens[k++];
        System.out.println("Result            : " + Arrays.toString(arr));
        System.out.println("Odd-index values (3, 9, 1, 7) kept their original positions.");
    }
}
