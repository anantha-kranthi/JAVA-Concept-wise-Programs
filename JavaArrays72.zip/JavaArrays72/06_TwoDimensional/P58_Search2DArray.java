/* Program 58: Searching for an element in a 2D array */
public class P58_Search2DArray {
    public static void main(String[] args) {
        int[][] m = {
            {10, 20, 30},
            {40, 50, 60},
            {70, 80, 90}
        };

        System.out.println("Matrix:");
        for (int[] row : m) {
            for (int v : row) System.out.printf("%5d", v);
            System.out.println();
        }

        search(m, 50);
        search(m, 10);
        search(m, 90);
        search(m, 55);

        // Count how many times a value appears
        int[][] repeats = {{1, 2, 1}, {3, 1, 4}, {1, 5, 1}};
        int count = 0;
        for (int[] row : repeats) for (int v : row) if (v == 1) count++;
        System.out.println("\nIn the second matrix, 1 appears " + count + " times.");
    }

    static void search(int[][] m, int key) {
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[i].length; j++) {
                if (m[i][j] == key) {
                    System.out.println("\n" + key + " found at row " + i + ", column " + j
                            + "  (m[" + i + "][" + j + "])");
                    return;
                }
            }
        }
        System.out.println("\n" + key + " is not present in the matrix.");
    }
}
