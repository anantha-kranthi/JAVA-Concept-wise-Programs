/* Program 55: Transpose of a matrix */
public class P55_MatrixTranspose {
    public static void main(String[] args) {
        int[][] m = {{1, 2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11, 12}};

        System.out.println("Original (" + m.length + "x" + m[0].length + "):");
        print(m);

        int[][] t = new int[m[0].length][m.length];
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                t[j][i] = m[i][j];
            }
        }

        System.out.println("\nTranspose (" + t.length + "x" + t[0].length + "):");
        print(t);

        // In-place transpose is possible only for a square matrix
        int[][] sq = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
        System.out.println("\nSquare matrix before in-place transpose:");
        print(sq);
        for (int i = 0; i < sq.length; i++) {
            for (int j = i + 1; j < sq.length; j++) {   // upper triangle only
                int tmp = sq[i][j]; sq[i][j] = sq[j][i]; sq[j][i] = tmp;
            }
        }
        System.out.println("\nAfter in-place transpose:");
        print(sq);
    }

    static void print(int[][] m) {
        for (int[] row : m) {
            for (int v : row) System.out.printf("%5d", v);
            System.out.println();
        }
    }
}
