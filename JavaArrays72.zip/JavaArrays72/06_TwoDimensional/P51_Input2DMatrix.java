/* Program 51: Reading a matrix from the user
   Sample input:  2 3
                  1 2 3
                  4 5 6                                   */
import java.util.Scanner;

public class P51_Input2DMatrix {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of rows: ");
        int rows = sc.nextInt();
        System.out.print("Enter number of columns: ");
        int cols = sc.nextInt();

        int[][] matrix = new int[rows][cols];

        System.out.println("Enter " + (rows * cols) + " elements row by row:");
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                matrix[i][j] = sc.nextInt();
            }
        }

        System.out.println("\nThe matrix you entered:");
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                System.out.printf("%5d", matrix[i][j]);
            }
            System.out.println();
        }

        int sum = 0, max = matrix[0][0];
        for (int[] row : matrix)
            for (int v : row) { sum += v; if (v > max) max = v; }

        System.out.println("\nSum of all elements : " + sum);
        System.out.println("Largest element     : " + max);

        sc.close();
    }
}
