/* Program 56: Sum of the diagonals of a square matrix */
public class P56_DiagonalSum {
    public static void main(String[] args) {
        int[][] m = {
            {1,  2,  3,  4},
            {5,  6,  7,  8},
            {9, 10, 11, 12},
            {13,14, 15, 16}
        };
        int n = m.length;

        System.out.println("Matrix:");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) System.out.printf("%5d", m[i][j]);
            System.out.println();
        }

        int principal = 0, secondary = 0;
        StringBuilder p = new StringBuilder(), s = new StringBuilder();
        for (int i = 0; i < n; i++) {
            principal += m[i][i];                  // where row index == column index
            secondary += m[i][n - 1 - i];          // where row + column == n-1
            p.append(m[i][i]).append(i < n - 1 ? " + " : "");
            s.append(m[i][n - 1 - i]).append(i < n - 1 ? " + " : "");
        }

        System.out.println("\nPrincipal diagonal : " + p + " = " + principal);
        System.out.println("Secondary diagonal : " + s + " = " + secondary);
        System.out.println("Total of both      : " + (principal + secondary));

        int diff = Math.abs(principal - secondary);
        System.out.println("Absolute difference: " + diff);

        // For an odd-sized matrix the centre element is counted twice
        if (n % 2 != 0) {
            System.out.println("Note: odd size, centre element " + m[n / 2][n / 2]
                    + " belongs to both diagonals.");
        }
    }
}
