/* Program 61: Printing a matrix in spiral order */
public class P61_SpiralPrint {
    public static void main(String[] args) {
        int[][] m = {
            { 1,  2,  3,  4},
            { 5,  6,  7,  8},
            { 9, 10, 11, 12},
            {13, 14, 15, 16}
        };

        System.out.println("Matrix:");
        for (int[] row : m) {
            for (int v : row) System.out.printf("%5d", v);
            System.out.println();
        }

        System.out.print("\nSpiral order : ");
        spiral(m);

        int[][] rect = {{1, 2, 3, 4, 5}, {6, 7, 8, 9, 10}, {11, 12, 13, 14, 15}};
        System.out.println("\n\nA 3x5 matrix:");
        for (int[] row : rect) {
            for (int v : row) System.out.printf("%5d", v);
            System.out.println();
        }
        System.out.print("\nSpiral order : ");
        spiral(rect);
        System.out.println();
    }

    static void spiral(int[][] m) {
        int top = 0, bottom = m.length - 1;
        int left = 0, right = m[0].length - 1;

        while (top <= bottom && left <= right) {
            for (int j = left; j <= right; j++) System.out.print(m[top][j] + " ");
            top++;

            for (int i = top; i <= bottom; i++) System.out.print(m[i][right] + " ");
            right--;

            if (top <= bottom) {
                for (int j = right; j >= left; j--) System.out.print(m[bottom][j] + " ");
                bottom--;
            }
            if (left <= right) {
                for (int i = bottom; i >= top; i--) System.out.print(m[i][left] + " ");
                left++;
            }
        }
    }
}
