/* Program 54: Multiplying two matrices */
public class P54_MatrixMultiplication {
    public static void main(String[] args) {
        int[][] a = {{1, 2, 3}, {4, 5, 6}};          // 2 x 3
        int[][] b = {{7, 8}, {9, 10}, {11, 12}};     // 3 x 2

        int aRows = a.length, aCols = a[0].length;
        int bRows = b.length, bCols = b[0].length;

        System.out.println("Matrix A (" + aRows + "x" + aCols + "):"); print(a);
        System.out.println("\nMatrix B (" + bRows + "x" + bCols + "):"); print(b);

        if (aCols != bRows) {
            System.out.println("\nCannot multiply: columns of A must equal rows of B.");
            return;
        }

        int[][] product = new int[aRows][bCols];
        for (int i = 0; i < aRows; i++) {
            for (int j = 0; j < bCols; j++) {
                for (int k = 0; k < aCols; k++) {
                    product[i][j] += a[i][k] * b[k][j];
                }
            }
        }

        System.out.println("\nA x B (" + aRows + "x" + bCols + "):");
        print(product);
        System.out.println("\nC[i][j] = sum over k of A[i][k] * B[k][j]");
        System.out.println("For example C[0][0] = 1*7 + 2*9 + 3*11 = " + product[0][0]);
        System.out.println("Time complexity: O(n^3) for n x n matrices.");
    }

    static void print(int[][] m) {
        for (int[] row : m) {
            for (int v : row) System.out.printf("%6d", v);
            System.out.println();
        }
    }
}
