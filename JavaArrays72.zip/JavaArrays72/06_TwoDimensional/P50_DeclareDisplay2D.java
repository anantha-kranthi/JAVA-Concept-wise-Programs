/* Program 50: Declaring, initializing and displaying a 2D array */
import java.util.Arrays;

public class P50_DeclareDisplay2D {
    public static void main(String[] args) {
        // Literal initialization
        int[][] matrix = {
            {1, 2, 3},
            {4, 5, 6},
            {7, 8, 9}
        };

        // Declaration with new, filled in a loop
        int[][] table = new int[3][4];
        for (int i = 0; i < table.length; i++) {
            for (int j = 0; j < table[i].length; j++) {
                table[i][j] = (i + 1) * (j + 1);
            }
        }

        System.out.println("Matrix (" + matrix.length + " rows x "
                + matrix[0].length + " columns):");
        display(matrix);

        System.out.println("\nMultiplication table:");
        display(table);

        System.out.println("\nUsing Arrays.deepToString : " + Arrays.deepToString(matrix));
        System.out.println("matrix.length    = " + matrix.length + " (number of rows)");
        System.out.println("matrix[0].length = " + matrix[0].length + " (columns in row 0)");
        System.out.println("matrix[1][2]     = " + matrix[1][2]);

        System.out.println("\nEnhanced for loop:");
        for (int[] row : matrix) {
            for (int value : row) System.out.print(value + " ");
            System.out.println();
        }
    }

    static void display(int[][] m) {
        for (int[] row : m) {
            for (int v : row) System.out.printf("%4d", v);
            System.out.println();
        }
    }
}
