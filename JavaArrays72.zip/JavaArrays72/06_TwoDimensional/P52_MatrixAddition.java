/* Program 52: Adding two matrices */
public class P52_MatrixAddition {
    public static void main(String[] args) {
        int[][] a = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
        int[][] b = {{9, 8, 7}, {6, 5, 4}, {3, 2, 1}};

        if (a.length != b.length || a[0].length != b[0].length) {
            System.out.println("Addition needs matrices of the same order.");
            return;
        }

        int rows = a.length, cols = a[0].length;
        int[][] sum = new int[rows][cols];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                sum[i][j] = a[i][j] + b[i][j];
            }
        }

        System.out.println("Matrix A:");      print(a);
        System.out.println("\nMatrix B:");    print(b);
        System.out.println("\nA + B:");       print(sum);
        System.out.println("\nAddition is element-wise: C[i][j] = A[i][j] + B[i][j]");
    }

    static void print(int[][] m) {
        for (int[] row : m) {
            for (int v : row) System.out.printf("%5d", v);
            System.out.println();
        }
    }
}
