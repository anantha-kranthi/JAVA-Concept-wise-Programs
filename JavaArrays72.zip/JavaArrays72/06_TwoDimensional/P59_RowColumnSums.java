/* Program 59: Sum of each row and each column of a matrix */
public class P59_RowColumnSums {
    public static void main(String[] args) {
        int[][] m = {
            {5, 3, 8, 1},
            {9, 2, 4, 7},
            {6, 0, 3, 5}
        };
        int rows = m.length, cols = m[0].length;

        int[] rowSum = new int[rows];
        int[] colSum = new int[cols];
        int grandTotal = 0;

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                rowSum[i] += m[i][j];
                colSum[j] += m[i][j];
                grandTotal += m[i][j];
            }
        }

        System.out.println("Matrix with row and column totals:\n");
        for (int j = 0; j < cols; j++) System.out.printf("%6s", "C" + j);
        System.out.printf("%9s%n", "RowSum");
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) System.out.printf("%6d", m[i][j]);
            System.out.printf("%9d%n", rowSum[i]);
        }
        System.out.print("------".repeat(cols) + "---------\n");
        for (int j = 0; j < cols; j++) System.out.printf("%6d", colSum[j]);
        System.out.printf("%9d  <- grand total%n", grandTotal);

        // Largest row and column
        int maxRow = 0, maxCol = 0;
        for (int i = 1; i < rows; i++) if (rowSum[i] > rowSum[maxRow]) maxRow = i;
        for (int j = 1; j < cols; j++) if (colSum[j] > colSum[maxCol]) maxCol = j;
        System.out.println("\nRow with the largest sum    : row " + maxRow
                + " (" + rowSum[maxRow] + ")");
        System.out.println("Column with the largest sum : column " + maxCol
                + " (" + colSum[maxCol] + ")");
    }
}
