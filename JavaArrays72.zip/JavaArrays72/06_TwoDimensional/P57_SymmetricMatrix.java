/* Program 57: Checking whether a matrix is symmetric */
public class P57_SymmetricMatrix {
    public static void main(String[] args) {
        int[][] symmetric = {
            {1, 7, 3},
            {7, 4, 5},
            {3, 5, 6}
        };
        int[][] notSymmetric = {
            {1, 2, 3},
            {4, 5, 6},
            {7, 8, 9}
        };
        int[][] skew = {
            {0, 2, -3},
            {-2, 0, 4},
            {3, -4, 0}
        };

        check(symmetric, "Matrix 1");
        check(notSymmetric, "Matrix 2");
        check(skew, "Matrix 3");
    }

    static void check(int[][] m, String label) {
        System.out.println(label + ":");
        for (int[] row : m) {
            for (int v : row) System.out.printf("%5d", v);
            System.out.println();
        }

        if (m.length != m[0].length) {
            System.out.println("  Not square, so symmetry does not apply.\n");
            return;
        }

        boolean sym = true, skewSym = true;
        for (int i = 0; i < m.length && (sym || skewSym); i++) {
            for (int j = 0; j < m.length; j++) {
                if (m[i][j] != m[j][i]) sym = false;
                if (m[i][j] != -m[j][i]) skewSym = false;
            }
        }
        System.out.println("  Symmetric (A = A-transpose)      : " + sym);
        System.out.println("  Skew symmetric (A = -A-transpose): " + skewSym + "\n");
    }
}
