/* Program 53: Subtracting two matrices */
public class P53_MatrixSubtraction {
    public static void main(String[] args) {
        int[][] a = {{10, 20, 30}, {40, 50, 60}};
        int[][] b = {{1, 2, 3}, {4, 5, 6}};

        if (a.length != b.length || a[0].length != b[0].length) {
            System.out.println("Subtraction needs matrices of the same order.");
            return;
        }

        int[][] diff = new int[a.length][a[0].length];
        int[][] reverse = new int[a.length][a[0].length];
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[0].length; j++) {
                diff[i][j] = a[i][j] - b[i][j];
                reverse[i][j] = b[i][j] - a[i][j];
            }
        }

        System.out.println("Matrix A:");   print(a);
        System.out.println("\nMatrix B:"); print(b);
        System.out.println("\nA - B:");    print(diff);
        System.out.println("\nB - A:");    print(reverse);
        System.out.println("\nUnlike addition, subtraction is not commutative.");
    }

    static void print(int[][] m) {
        for (int[] row : m) {
            for (int v : row) System.out.printf("%6d", v);
            System.out.println();
        }
    }
}
