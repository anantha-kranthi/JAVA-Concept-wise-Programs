/* Program 60: Rotating a square matrix by 90 degrees */
public class P60_RotateMatrix90 {
    public static void main(String[] args) {
        int[][] m = {
            {1, 2, 3},
            {4, 5, 6},
            {7, 8, 9}
        };

        System.out.println("Original:");           print(m);

        int[][] cw = rotateClockwise(m);
        System.out.println("\nRotated 90 degrees clockwise:");
        print(cw);

        int[][] ccw = rotateAntiClockwise(m);
        System.out.println("\nRotated 90 degrees anti-clockwise:");
        print(ccw);

        System.out.println("\nRotated 180 degrees:");
        print(rotateClockwise(rotateClockwise(m)));

        // In-place clockwise rotation: transpose, then reverse each row
        int[][] inPlace = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
        int n = inPlace.length;
        for (int i = 0; i < n; i++)
            for (int j = i + 1; j < n; j++) {
                int t = inPlace[i][j]; inPlace[i][j] = inPlace[j][i]; inPlace[j][i] = t;
            }
        for (int[] row : inPlace)
            for (int i = 0, j = n - 1; i < j; i++, j--) {
                int t = row[i]; row[i] = row[j]; row[j] = t;
            }
        System.out.println("\nIn-place clockwise (transpose + reverse rows):");
        print(inPlace);
    }

    static int[][] rotateClockwise(int[][] m) {
        int n = m.length;
        int[][] r = new int[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                r[j][n - 1 - i] = m[i][j];
        return r;
    }

    static int[][] rotateAntiClockwise(int[][] m) {
        int n = m.length;
        int[][] r = new int[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                r[n - 1 - j][i] = m[i][j];
        return r;
    }

    static void print(int[][] m) {
        for (int[] row : m) {
            for (int v : row) System.out.printf("%4d", v);
            System.out.println();
        }
    }
}
